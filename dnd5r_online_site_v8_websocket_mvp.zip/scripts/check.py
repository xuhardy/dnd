from pathlib import Path
import re,subprocess,sys
root=Path(__file__).resolve().parent.parent
html=(root/'index.html').read_text()
refs=re.findall(r'(?:src|href)="([^"]+)"',html)
missing=[x for x in refs if not x.startswith(('http:','https:','#','data:')) and not (root/x).exists()]
js=list(root.rglob('*.js'))
errors=[]
for f in js:
 p=subprocess.run(['node','--check',str(f)],capture_output=True,text=True)
 if p.returncode: errors.append((str(f.relative_to(root)),p.stderr))
print(f'Checked {len(refs)} references, {len(js)} scripts')
if missing: print('Missing references:',missing)
for x in errors: print('Syntax error:',x)
sys.exit(bool(missing or errors))
