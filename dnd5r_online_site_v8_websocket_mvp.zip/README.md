# D&D 5R V8 · WebSocket + Durable Objects

此版本保留 V7 的角色/地图/升级页面，新增**独立的 WebSocket 联机大厅**，首页创建/加入房间入口已接到 V8 大厅。旧版 PeerJS 游戏同步代码仍保留在旧模块，**V8 大厅尚未接通地图、Token、战斗、HP 的同步**。不要将大厅连接成功误认为游戏状态同步完成。

## 部署（Cloudflare Workers）

需要 Cloudflare Workers + Durable Objects，**不能只把 ZIP 拖到 Pages 静态上传**。使用 Node.js 与 Wrangler：

```bash
npm install -g wrangler
wrangler login
wrangler deploy
```

在项目根目录运行。`wrangler.toml` 默认 Worker 名称 `dndforhardy`，如果同名已有 Worker，请先备份或更改名称。部署前建议先在 Cloudflare Dashboard 查看该 Worker 当前代码/绑定。Cloudflare 账户需支持 Durable Objects（SQLite 后端），可能需要启用相应服务。

## 测试

1. DM 访问网站，点击“创建房间”，确认显示 6 位房间码和“已连接大厅”。
2. 玩家在另一台设备/移动数据网络访问相同网址，点击“加入已有房间”，输入房间码。
3. 测试准备/取消、锁定/解锁、开始/返回大厅、关闭房间、刷新重连。

此版 WebSocket 不依赖 P2P 穿透或 TURN，但仍依赖公网和 Cloudflare。房间码不是密码；此版仅是联机大厅 MVP，缺少身份验证、持久玩家身份、DM 重连权限保护、房间过期与游戏数据同步，**不建议作为公开生产游戏服务**。
