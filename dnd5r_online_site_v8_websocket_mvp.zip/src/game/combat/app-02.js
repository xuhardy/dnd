
/* ==================== V9 战术网格 · DM 自由桌面 ==================== */
COMBAT.editMode='select'; COMBAT.paintTerrain='wall'; COMBAT.dragUnitId=null; COMBAT.dragMoved=false;
function v9EnsureEncounter(){
  var e=COMBAT.encounter;if(!e)return;
  if(!e.terrain)e.terrain={}; if(!e.grid)e.grid={w:20,h:20,cellSize:5};
  e.grid.w=e.grid.w||20;e.grid.h=e.grid.h||20;e.grid.cellSize=e.grid.cellSize||5;
}
function v9TerrainColor(t){return {wall:'rgba(100,92,82,.82)',door:'rgba(201,162,39,.68)',doorOpen:'rgba(115,170,105,.38)',difficult:'rgba(115,86,52,.52)',water:'rgba(70,130,180,.45)',fire:'rgba(224,82,82,.55)',trap:'rgba(163,122,201,.48)'}[t]||null}
function v9GridPoint(px,py){var c=COMBAT.cellPx*COMBAT.zoom;return {x:Math.floor((px-COMBAT.panX)/c),y:Math.floor((py-COMBAT.panY)/c)}}
function v9Valid(g){var e=COMBAT.encounter;return e&&g.x>=0&&g.y>=0&&g.x<e.grid.w&&g.y<e.grid.h}
function v9Sync(){syncEncounterToPlayers();saveEncounter();drawMap()}
window.v9Mode=function(m){COMBAT.editMode=m;initMapCanvas()}
window.v9Terrain=function(t){COMBAT.paintTerrain=t;COMBAT.editMode='terrain';initMapCanvas()}
window.v9Resize=function(){v9EnsureEncounter();var e=COMBAT.encounter;var w=prompt('地图宽度（格）',e.grid.w),h=prompt('地图高度（格）',e.grid.h);if(w===null||h===null)return;e.grid.w=Math.max(5,Math.min(60,parseInt(w)||20));e.grid.h=Math.max(5,Math.min(60,parseInt(h)||20));v9Sync();initMapCanvas()}
window.v9AddAt=function(gx,gy){var name=prompt('单位名称','新怪物');if(!name)return;var hp=parseInt(prompt('HP','10'))||10,ac=parseInt(prompt('AC','12'))||12;var u=newUnit({name:name,type:'enemy',hp:hp,maxHP:hp,ac:ac,x:gx,y:gy});COMBAT.encounter.units.push(u);COMBAT.selectedUnitId=u.id;v9Sync();initMapCanvas()}
window.v9Duplicate=function(id){var e=COMBAT.encounter,u=e&&e.units.find(x=>x.id===id);if(!u)return;var n=JSON.parse(JSON.stringify(u));n.id='u_'+Date.now().toString(36)+Math.random().toString(36).slice(2,6);n.name=u.name+' 复制';n.x=Math.min(e.grid.w-n.size,u.x+1);n.y=Math.min(e.grid.h-n.size,u.y+1);e.units.push(n);COMBAT.selectedUnitId=n.id;v9Sync();initMapCanvas()}
window.v9Delete=function(id){var e=COMBAT.encounter;if(!e)return;var u=e.units.find(x=>x.id===id);if(!u||!confirm('移除「'+u.name+'」？'))return;e.units=e.units.filter(x=>x.id!==id);if(e.currentUnitId===id)e.currentUnitId='';COMBAT.selectedUnitId=null;v9Sync();initMapCanvas()}
window.v9ToggleHidden=function(id){var u=COMBAT.encounter.units.find(x=>x.id===id);if(!u)return;u.hidden=!u.hidden;v9Sync();initMapCanvas()}
window.v9SetTurn=function(id){COMBAT.encounter.currentUnitId=id;COMBAT.encounter.started=true;COMBAT.encounter.active=true;v9Sync();initMapCanvas()}
window.v9InitDelta=function(id,d){var u=COMBAT.encounter.units.find(x=>x.id===id);if(!u)return;u.init=(u.init||0)+d;sortInitOrder();v9Sync();initMapCanvas()}
window.v9ClearTerrain=function(){if(!confirm('清空全部地形标记？'))return;COMBAT.encounter.terrain={};v9Sync();initMapCanvas()}

var _v8InitMapCanvas=initMapCanvas;
initMapCanvas=function(){
  v9EnsureEncounter();var host=$('mapMain'),enc=COMBAT.encounter;if(!host||!enc)return;var isDM=DM.role==='dm',h='';
  h+='<div class="map-wrap" id="mapWrap"><canvas id="mapCanvas" class="map-canvas"></canvas><div class="map-overlay"><button class="map-btn'+(COMBAT.showGrid?' on':'')+'" onclick="toggleMapGrid()">⊞</button><button class="map-btn" onclick="mapZoom(1.25)">+</button><button class="map-btn" onclick="mapZoom(.8)">−</button><button class="map-btn" onclick="mapCenter()">◎</button></div><div class="map-info" id="mapInfo"></div></div>';
  if(isDM){
    h+='<div class="map-modebar"><button class="'+(COMBAT.editMode==='select'?'on':'')+'" onclick="v9Mode(\'select\')">☝ 选择/拖动</button><button class="'+(COMBAT.editMode==='pan'?'on':'')+'" onclick="v9Mode(\'pan\')">✋ 移动画布</button><button class="'+(COMBAT.editMode==='add'?'on':'')+'" onclick="v9Mode(\'add\')">＋ 点格加单位</button><button class="'+(COMBAT.editMode==='terrain'?'on':'')+'" onclick="v9Terrain(\'wall\')">▦ 画地形</button></div>';
    if(COMBAT.editMode==='terrain')h+='<div class="map-modebar"><button onclick="v9Terrain(\'wall\')" class="'+(COMBAT.paintTerrain==='wall'?'on':'')+'">墙</button><button onclick="v9Terrain(\'door\')" class="'+(COMBAT.paintTerrain==='door'?'on':'')+'">门</button><button onclick="v9Terrain(\'difficult\')" class="'+(COMBAT.paintTerrain==='difficult'?'on':'')+'">困难</button><button onclick="v9Terrain(\'water\')" class="'+(COMBAT.paintTerrain==='water'?'on':'')+'">水</button><button onclick="v9Terrain(\'fire\')" class="'+(COMBAT.paintTerrain==='fire'?'on':'')+'">火</button><button onclick="v9Terrain(\'trap\')" class="'+(COMBAT.paintTerrain==='trap'?'on':'')+'">陷阱</button><button onclick="v9Terrain(\'erase\')">橡皮</button></div>';
    h+='<div class="map-help"><b>DM 自由桌面：</b>选择模式可直接拖棋子；空白拖动请切到“移动画布”。地形模式点格涂画。所有改动实时同步给玩家。</div>';
    h+='<div class="dm-map-tools"><button onclick="v9Resize()">地图尺寸</button><button onclick="combatRollAllInit();initMapCanvas()">全体先攻</button><button onclick="combatNextTurn();initMapCanvas()">下一回合</button><button class="danger" onclick="v9ClearTerrain()">清地形</button></div>';
    var su=enc.units.find(x=>x.id===COMBAT.selectedUnitId);if(su)h+='<div class="map-selbar"><span class="nm">'+esc(su.name)+'</span><button onclick="v9SetTurn(\''+su.id+'\')">轮到TA</button><button onclick="v9ToggleHidden(\''+su.id+'\')">'+(su.hidden?'显示':'隐藏')+'</button><button onclick="v9Duplicate(\''+su.id+'\')">复制</button><button onclick="combatEditUnit(\''+su.id+'\')">编辑</button><button class="d" onclick="v9Delete(\''+su.id+'\')">删除</button></div>';
    h+='<div class="terrain-key"><span style="--k:rgba(100,92,82,.82)">墙</span><span style="--k:rgba(201,162,39,.68)">门</span><span style="--k:rgba(115,86,52,.52)">困难地形</span><span style="--k:rgba(70,130,180,.45)">水</span><span style="--k:rgba(224,82,82,.55)">火</span><span style="--k:rgba(163,122,201,.48)">陷阱</span></div>';
    h+='<div class="combat-toolbar">'+(enc.started?'<button class="pri" onclick="combatNextTurn();initMapCanvas()">下一回合</button>':'<button class="pri" onclick="combatStart();initMapCanvas()">开始战斗</button>')+'<button onclick="combatAddCustom();setTimeout(initMapCanvas,30)">自定义单位</button><button class="dan" onclick="combatEnd();initMapCanvas()">结束战斗</button></div>';
    h+='<div class="tb"><div class="tt">单位 / 自由先攻</div>'+renderUnitList(enc,true)+'</div>';
  }else h+='<div class="tb"><div class="tt">战斗视图</div><div style="font-size:12px;color:#9a8f7d;text-align:center;margin-bottom:8px">第 '+enc.round+' 轮</div>'+renderUnitList(enc,false)+'</div>';
  host.innerHTML=h;var canvas=$('mapCanvas');COMBAT.canvas=canvas;COMBAT.ctx=canvas.getContext('2d');var wrap=$('mapWrap'),w=wrap.clientWidth,viewSize=Math.min(w,560);canvas.width=viewSize;canvas.height=Math.min(viewSize,Math.max(360,window.innerHeight*.58));drawMap();bindMapEvents();
};

var _v8DrawMap=drawMap;
drawMap=function(){
  var canvas=COMBAT.canvas;if(!canvas)return;var ctx=canvas.getContext('2d'),enc=COMBAT.encounter;if(!enc)return;v9EnsureEncounter();var W=canvas.width,H=canvas.height,cell=COMBAT.cellPx*COMBAT.zoom,px=COMBAT.panX,py=COMBAT.panY;ctx.fillStyle='#0a0805';ctx.fillRect(0,0,W,H);
  /* V15 background image, aligned to the logical grid */
  if(enc.background&&enc.background.dataUrl){
    var bg=enc.background,img=v15GetBgImage(bg.dataUrl);
    if(img&&img.complete&&img.naturalWidth){
      ctx.save();ctx.globalAlpha=(bg.opacity==null?.88:bg.opacity);
      var bx=px+(Number(bg.offsetX)||0)*cell,by=py+(Number(bg.offsetY)||0)*cell;
      var bw=enc.grid.w*cell*(Number(bg.scaleX)||1),bh=enc.grid.h*cell*(Number(bg.scaleY)||1);
      ctx.drawImage(img,bx,by,bw,bh);ctx.restore();
    }
  }
  Object.keys(enc.terrain||{}).forEach(function(k){var p=k.split(','),gx=+p[0],gy=+p[1],t=enc.terrain[k],c=v9TerrainColor(t);if(!c)return;ctx.fillStyle=c;ctx.fillRect(px+gx*cell,py+gy*cell,cell,cell);if(t==='trap'&&DM.role!=='dm'){ctx.fillStyle='#0a0805';ctx.fillRect(px+gx*cell,py+gy*cell,cell,cell)}});
  if(COMBAT.showGrid){ctx.strokeStyle='rgba(58,49,40,.55)';ctx.lineWidth=1;for(var x=px;x<=px+enc.grid.w*cell;x+=cell){ctx.beginPath();ctx.moveTo(x,py);ctx.lineTo(x,py+enc.grid.h*cell);ctx.stroke()}for(var y=py;y<=py+enc.grid.h*cell;y+=cell){ctx.beginPath();ctx.moveTo(px,y);ctx.lineTo(px+enc.grid.w*cell,y);ctx.stroke()}}
  ctx.strokeStyle='rgba(201,162,39,.35)';ctx.lineWidth=2;ctx.strokeRect(px,py,enc.grid.w*cell,enc.grid.h*cell);
  enc.units.forEach(function(u){if(u.hidden&&DM.role!=='dm')return;var cx=px+(u.x+u.size/2)*cell,cy=py+(u.y+u.size/2)*cell,r=u.size*cell*.40;ctx.globalAlpha=(u.hidden&&DM.role==='dm')?.42:1;ctx.fillStyle=u.color||UNIT_COLORS[u.type]||'#666';ctx.beginPath();ctx.arc(cx,cy,r,0,Math.PI*2);ctx.fill();ctx.strokeStyle=u.id===COMBAT.selectedUnitId?'#fff':(u.id===enc.currentUnitId?'#e8c95a':'rgba(20,17,14,.8)');ctx.lineWidth=(u.id===enc.currentUnitId||u.id===COMBAT.selectedUnitId)?3:1.5;ctx.stroke();ctx.fillStyle='#e8e0d0';ctx.font=Math.max(9,Math.min(13,cell*.3))+'px -apple-system,sans-serif';ctx.textAlign='center';ctx.textBaseline='middle';ctx.fillText((u.name||'?').substring(0,4),cx,cy);ctx.globalAlpha=1});
};

bindMapEvents=function(){
 var c=COMBAT.canvas;if(!c)return;var down=false,last=null;
 function pt(e){var r=c.getBoundingClientRect(),q=e.touches?e.touches[0]:e;return{x:q.clientX-r.left,y:q.clientY-r.top}}
 function hit(p){var e=COMBAT.encounter,cell=COMBAT.cellPx*COMBAT.zoom;for(var i=e.units.length-1;i>=0;i--){var u=e.units[i];if(u.hidden&&DM.role!=='dm')continue;var cx=COMBAT.panX+(u.x+u.size/2)*cell,cy=COMBAT.panY+(u.y+u.size/2)*cell;if(Math.hypot(p.x-cx,p.y-cy)<=u.size*cell*.5)return u}return null}
 c.onpointerdown=function(e){e.preventDefault();down=true;last=pt(e);COMBAT.dragMoved=false;var u=hit(last);if(DM.role==='dm'&&COMBAT.editMode==='select'&&u){COMBAT.dragUnitId=u.id;COMBAT.selectedUnitId=u.id;showUnitInfo();drawMap()}else COMBAT.dragUnitId=null};
 c.onpointermove=function(e){if(!down)return;e.preventDefault();var p=pt(e),dx=p.x-last.x,dy=p.y-last.y;if(Math.abs(dx)+Math.abs(dy)>2)COMBAT.dragMoved=true;if(DM.role==='dm'&&COMBAT.dragUnitId){var u=COMBAT.encounter.units.find(x=>x.id===COMBAT.dragUnitId),g=v9GridPoint(p.x,p.y);if(u&&v9Valid(g)){u.x=Math.max(0,Math.min(COMBAT.encounter.grid.w-u.size,g.x));u.y=Math.max(0,Math.min(COMBAT.encounter.grid.h-u.size,g.y));drawMap()}}else if(COMBAT.editMode==='pan'||DM.role!=='dm'){COMBAT.panX+=dx;COMBAT.panY+=dy;drawMap()}last=p};
 c.onpointerup=function(e){if(!down)return;e.preventDefault();var p=pt(e),u=hit(p);down=false;if(COMBAT.dragUnitId){COMBAT.dragUnitId=null;v9Sync();return}if(DM.role==='dm'){var g=v9GridPoint(p.x,p.y);if(COMBAT.editMode==='add'&&v9Valid(g)){v9AddAt(g.x,g.y);return}if(COMBAT.editMode==='terrain'&&v9Valid(g)){var k=g.x+','+g.y;if(COMBAT.paintTerrain==='erase')delete COMBAT.encounter.terrain[k];else COMBAT.encounter.terrain[k]=COMBAT.paintTerrain;v9Sync();return}}if(u)mapSelectUnit(u.id);else{COMBAT.selectedUnitId=null;drawMap();showUnitInfo()}};
 c.onpointercancel=function(){down=false;COMBAT.dragUnitId=null};
};

/* 玩家不应收到 DM 隐藏陷阱：覆写同步数据 */
var _v8SyncEncounter=syncEncounterToPlayers;
syncEncounterToPlayers=function(){
 if(!COMBAT.encounter||!P2P.ready||DM.role!=='dm')return;v9EnsureEncounter();var e=COMBAT.encounter,terrain={};Object.keys(e.terrain||{}).forEach(function(k){if(e.terrain[k]!=='trap')terrain[k]=e.terrain[k]});
 var visible={id:e.id,name:e.name,active:e.active,started:e.started,grid:e.grid,terrain:terrain,round:e.round,currentUnitId:e.currentUnitId,units:e.units.filter(function(u){return !u.hidden}).map(function(u){return{id:u.id,name:u.name,type:u.type,x:u.x,y:u.y,size:u.size,hidden:false,hp:u.hp,maxHP:u.maxHP,ac:u.ac,init:u.init,conditions:u.conditions,ownerId:u.ownerId,color:u.color}})};P2P.broadcast({type:'encounter-update',data:visible});
};


/* ==================== V10 · Persistent exploration/combat tabletop ==================== */
function v10EnsureTable(){
  if(!COMBAT.encounter){ COMBAT.encounter=newEncounter('冒险地图'); }
  var e=COMBAT.encounter;
  if(!e.phase) e.phase=e.started?'combat':'explore';
  if(!e.terrain) e.terrain={};
  if(!e.grid) e.grid={w:20,h:20,cellSize:5};
  if(!Array.isArray(e.units)) e.units=[];
  /* active now means a shared tabletop exists; started alone means combat */
  e.active=true;
  if(e.phase==='explore'){e.started=false;e.currentUnitId='';}
  return e;
}
function v10SaveSync(){saveEncounter();syncEncounterToPlayers();}
window.v10OpenTable=function(){v10EnsureTable();v10SaveSync();openMap();};
window.v10Explore=function(){
  var e=v10EnsureTable();e.phase='explore';e.started=false;e.currentUnitId='';e.round=1;
  CHARS.forEach(function(c){if(c.game){c.game.inCombat=false;c.game.combatUnitId='';}});saveAll();dmLog('回到探索模式','sys');v10SaveSync();initMapCanvas();
};
window.v10Combat=function(){
  var e=v10EnsureTable();
  if(!e.units.length){alert('地图上还没有单位。先在探索模式摆好玩家或怪物。');return;}
  e.phase='combat';sortInitOrder();e.started=true;e.active=true;e.round=Math.max(1,e.round||1);
  if(!e.currentUnitId || !e.units.some(function(u){return u.id===e.currentUnitId;})) e.currentUnitId=e.units[0].id;
  e.units.forEach(function(u){if(u.ownerId){var c=CHARS.find(function(x){return x.id===u.ownerId;});if(c&&c.game){c.game.inCombat=true;c.game.combatUnitId=u.id;}}});saveAll();dmLog('进入战斗模式','sys');v10SaveSync();initMapCanvas();
};
window.v10ResetTable=function(){if(!confirm('清空地图上的单位、地形和战斗状态？角色资料不会删除。'))return;COMBAT.encounter=newEncounter('冒险地图');COMBAT.encounter.phase='explore';COMBAT.encounter.active=true;COMBAT.encounter.terrain={};COMBAT.selectedUnitId=null;v10SaveSync();initMapCanvas();};
window.v10AddConnectedPlayers=function(){
  var e=v10EnsureTable(),added=0;
  (DM.players||[]).forEach(function(p,i){var ch=p.char||p.character||p.data||p;if(!ch||!ch.id)return;if(e.units.some(function(u){return u.ownerId===ch.id;}))return;var hp=(ch.game&&ch.game.hp)||ch.hp||10,max=(ch.game&&ch.game.maxHP)||ch.maxHP||hp; e.units.push(newUnit({name:ch.name||p.name||'玩家',type:'player',hp:hp,maxHP:max,ac:ch.ac||10,ownerId:ch.id,x:1+(i%5)*2,y:1+Math.floor(i/5)*2}));added++;});
  if(!added) alert('没有发现尚未放上地图的已连接角色。');v10SaveSync();initMapCanvas();
};
/* End combat now returns to exploration and preserves the tabletop. */
window.combatEnd=function(){
  if(!COMBAT.encounter)return;dlg('结束战斗','结束先攻与回合，但保留当前地图、棋子位置和地形，回到探索模式。',[{l:'取消'},{l:'回到探索',c:'p',f:function(){v10Explore();renderDMHome();}}]);
};
/* Start combat uses the new phase transition. */
window.combatStart=function(){v10Combat();};

/* Shared payload carries phase + terrain. Hidden DM information remains filtered. */
syncEncounterToPlayers=function(){
 if(!COMBAT.encounter||!P2P.ready||DM.role!=='dm')return;var e=v10EnsureTable(),terrain={};Object.keys(e.terrain||{}).forEach(function(k){if(e.terrain[k]!=='trap')terrain[k]=e.terrain[k]});
 var visible={id:e.id,name:e.name,active:true,started:e.phase==='combat',phase:e.phase,grid:e.grid,terrain:terrain,round:e.round,currentUnitId:e.phase==='combat'?e.currentUnitId:'',units:e.units.filter(function(u){return !u.hidden}).map(function(u){return{id:u.id,name:u.name,type:u.type,x:u.x,y:u.y,size:u.size,hidden:false,hp:u.hp,maxHP:u.maxHP,ac:u.ac,init:u.init,conditions:u.conditions,ownerId:u.ownerId,color:u.color}})};P2P.broadcast({type:'encounter-update',data:visible});
};

/* DM room: tabletop is always available, not only after creating an encounter. */
var _v10OldRenderDMRoom=renderDMRoom;
renderDMRoom=function(){
  var h=_v10OldRenderDMRoom();
  var e=COMBAT.encounter,phase=e&&e.phase?e.phase:(e&&e.started?'combat':'explore');
  var card='<div class="tb"><div class="tt">共享桌面</div><div style="font-size:12px;color:#9a8f7d;margin-bottom:10px">'+(phase==='combat'?'⚔ 战斗模式 · 第 '+((e&&e.round)||1)+' 轮':'🕯 探索模式 · 地图持续保留')+'</div><button class="hbt p" style="width:100%" onclick="v10OpenTable()">🗺 打开探索 / 战斗地图</button></div>';
  return card+h;
};

/* Fully rebuilt grid screen. One map, two phases. */
initMapCanvas=function(){
  var host=$('mapMain');if(!host)return;var enc=v10EnsureTable(),isDM=DM.role==='dm',combat=enc.phase==='combat'||enc.started,h='';
  $('mapTitle').textContent=combat?'战斗地图':'探索地图';
  h+='<div class="v10-phase">'+(isDM?'<button class="'+(!combat?'on explore':'')+'" onclick="v10Explore()">🕯 探索</button><button class="'+(combat?'on combat':'')+'" onclick="v10Combat()">⚔ 战斗</button>':'<button class="'+(!combat?'on explore':'')+'">🕯 探索</button><button class="'+(combat?'on combat':'')+'">⚔ 战斗</button>')+'</div>';
  h+='<div class="v10-status '+(combat?'combat':'')+'"><div class="ico">'+(combat?'⚔':'🕯')+'</div><div class="copy"><b>'+(combat?'战斗模式':'探索模式')+'</b><small>'+(combat?'启用先攻、轮次和当前行动单位。地图位置继续沿用探索阶段。':'自由移动棋子、布置场景和隐藏信息。没有先攻压力，适合调查、潜行和剧情移动。')+'</small></div></div>';
  h+='<div class="v10-layout"><div><div class="v10-map-shell"><div class="map-wrap" id="mapWrap"><canvas id="mapCanvas" class="map-canvas"></canvas><div class="map-overlay"><button class="map-btn'+(COMBAT.showGrid?' on':'')+'" onclick="toggleMapGrid()">⊞</button><button class="map-btn" onclick="mapZoom(1.25)">＋</button><button class="map-btn" onclick="mapZoom(.8)">−</button><button class="map-btn" onclick="mapCenter()">◎</button></div><div class="map-info" id="mapInfo"></div></div></div>';
  if(isDM){
    h+='<div class="map-modebar"><button class="'+(COMBAT.editMode==='select'?'on':'')+'" onclick="v9Mode(\'select\')">☝ 棋子</button><button class="'+(COMBAT.editMode==='pan'?'on':'')+'" onclick="v9Mode(\'pan\')">✋ 画布</button><button class="'+(COMBAT.editMode==='add'?'on':'')+'" onclick="v9Mode(\'add\')">＋ 单位</button><button class="'+(COMBAT.editMode==='terrain'?'on':'')+'" onclick="v9Terrain(\'wall\')">▦ 地形</button></div>';
    if(COMBAT.editMode==='terrain')h+='<div class="map-modebar"><button onclick="v9Terrain(\'wall\')" class="'+(COMBAT.paintTerrain==='wall'?'on':'')+'">墙</button><button onclick="v9Terrain(\'door\')" class="'+(COMBAT.paintTerrain==='door'?'on':'')+'">门</button><button onclick="v9Terrain(\'difficult\')" class="'+(COMBAT.paintTerrain==='difficult'?'on':'')+'">困难</button><button onclick="v9Terrain(\'water\')" class="'+(COMBAT.paintTerrain==='water'?'on':'')+'">水</button><button onclick="v9Terrain(\'fire\')" class="'+(COMBAT.paintTerrain==='fire'?'on':'')+'">火</button><button onclick="v9Terrain(\'trap\')" class="'+(COMBAT.paintTerrain==='trap'?'on':'')+'">陷阱</button><button onclick="v9Terrain(\'erase\')">橡皮</button></div>';
    h+='<div class="v10-legend"><b>DM：</b>拖棋子直接移动。探索时可以提前布置隐藏怪物和陷阱，切到战斗后位置不会重置。</div>';
  }
  h+='</div><div class="v10-side">';
  if(isDM){
    h+='<div class="v10-primary">'+(combat?'<button onclick="combatPrevTurn();initMapCanvas()">上一位</button><button class="go" onclick="combatNextTurn();initMapCanvas()">下一位</button><button class="stop" onclick="combatEnd()">结束战斗</button>':'<button onclick="v10AddConnectedPlayers()">放入玩家</button><button onclick="combatAddCustom();setTimeout(initMapCanvas,30)">添加单位</button><button class="go" onclick="v10Combat()">进入战斗</button>')+'</div>';
    h+='<div class="dm-map-tools"><button onclick="v9Resize()">地图尺寸</button><button onclick="v9Mode(\'terrain\')">编辑地形</button><button onclick="mapCenter()">地图居中</button><button class="danger" onclick="v10ResetTable()">清空桌面</button></div>';
    if(combat)h+='<div class="dm-map-tools"><button onclick="combatRollAllInit();initMapCanvas()">全体先攻</button><button onclick="combatPrevTurn();initMapCanvas()">上一回合</button><button onclick="combatNextTurn();initMapCanvas()">下一回合</button><button onclick="v10Explore()">转探索</button></div>';
    var su=enc.units.find(function(x){return x.id===COMBAT.selectedUnitId;});if(su)h+='<div class="map-selbar"><span class="nm">'+esc(su.name)+'</span>'+(combat?'<button onclick="v9SetTurn(\''+su.id+'\')">轮到TA</button>':'')+'<button onclick="v9ToggleHidden(\''+su.id+'\')">'+(su.hidden?'显示':'隐藏')+'</button><button onclick="v9Duplicate(\''+su.id+'\')">复制</button><button onclick="combatEditUnit(\''+su.id+'\')">编辑</button><button class="d" onclick="v9Delete(\''+su.id+'\')">删除</button></div>';
    h+='<div class="tb v10-unitdrawer"><div class="tt">'+(combat?'先攻 / 单位':'场景单位')+'</div>'+renderUnitList(enc,true)+'</div>';
  }else{
    h+='<div class="tb"><div class="tt">'+(combat?'先攻顺序':'场景')+'</div><div style="font-size:12px;color:#9a8f7d;text-align:center;margin-bottom:8px">'+(combat?'第 '+enc.round+' 轮':'跟随 DM 探索地图')+'</div>'+renderUnitList(enc,false)+'</div>';
  }
  h+='</div></div>';host.innerHTML=h;
  var canvas=$('mapCanvas');COMBAT.canvas=canvas;COMBAT.ctx=canvas.getContext('2d');var wrap=$('mapWrap'),w=wrap.clientWidth;canvas.width=Math.max(300,Math.min(w,700));canvas.height=Math.max(390,Math.min(650,window.innerHeight*.64));drawMap();bindMapEvents();
};

/* Exploration shares the map with players but does not put characters in combat. */
var _v10RenderDMPlayerRoom=renderDMPlayerRoom;
renderDMPlayerRoom=function(){var h=_v10RenderDMPlayerRoom();if(COMBAT.encounter&&COMBAT.encounter.active&&!COMBAT.encounter.started){h='<div class="tb"><div class="tt">探索地图</div><button class="rsb l" style="width:100%" onclick="openMap()">🕯 打开共享地图</button></div>'+h;}return h;};


/* ==================== V11 · Direct exploration / combat table ==================== */
window.v11RenameScene=function(){var e=v10EnsureTable(),n=prompt('场景名称',e.name||'冒险地图');if(n&&n.trim()){e.name=n.trim();v10SaveSync();initMapCanvas();}};
window.v11QuickUnit=function(kind){var e=v10EnsureTable(),defs={enemy:['怪物',10,12],npc:['NPC',10,10],object:['物件',1,10]},d=defs[kind]||defs.enemy,n=prompt('名称',d[0]);if(!n)return;var hp=parseInt(prompt('HP',String(d[1])))||d[1],ac=parseInt(prompt('AC',String(d[2])))||d[2];var u=newUnit({name:n,type:kind,hp:hp,maxHP:hp,ac:ac,x:Math.max(0,Math.floor(e.grid.w/2)-1),y:Math.max(0,Math.floor(e.grid.h/2)-1)});e.units.push(u);COMBAT.selectedUnitId=u.id;v10SaveSync();initMapCanvas();};
window.v11Mode=function(m){COMBAT.editMode=m;initMapCanvas();};
window.v11Terrain=function(t){COMBAT.paintTerrain=t;COMBAT.editMode='terrain';initMapCanvas();};
window.v11CombatToggle=function(){var e=v10EnsureTable();if((e.phase||'explore')==='combat')combatEnd();else v10Combat();};

initMapCanvas=function(){
 var host=$('mapMain');if(!host)return;var e=v10EnsureTable(),isDM=DM.role==='dm',combat=(e.phase==='combat'||e.started),h='';
 $('mapTitle').textContent=combat?'战斗':'探索';
 h+='<div class="v11-shell">';
 h+='<div class="v11-top">'+(isDM?'<button class="'+(!combat?'on explore':'')+'" onclick="v10Explore()">🕯 探索</button><button class="'+(combat?'on combat':'')+'" onclick="v10Combat()">⚔ 战斗</button>':'<button class="'+(!combat?'on explore':'')+'">🕯 探索</button><button class="'+(combat?'on combat':'')+'">⚔ 战斗</button>')+'</div>';
 h+='<div class="v11-head"><div class="v11-scene" '+(isDM?'onclick="v11RenameScene()"':'')+'><b>'+esc(e.name||'冒险地图')+'</b><small>'+(isDM?'点名称可修改 · ':'')+(combat?'按先攻行动':'自由探索，不受回合限制')+'</small></div>'+(combat?'<div class="v11-round"><small>ROUND</small>'+Math.max(1,e.round||1)+'</div>':'')+'</div>';
 h+='<div class="v11-map"><div class="map-wrap" id="mapWrap"><canvas id="mapCanvas" class="map-canvas"></canvas><div class="map-overlay"><button class="map-btn'+(COMBAT.showGrid?' on':'')+'" onclick="toggleMapGrid()">⊞</button><button class="map-btn" onclick="mapZoom(1.2)">＋</button><button class="map-btn" onclick="mapZoom(.84)">−</button><button class="map-btn" onclick="mapCenter()">◎</button></div><div class="map-info" id="mapInfo"></div></div>';
 if(isDM)h+='<div class="v11-tools"><button class="'+(COMBAT.editMode==='select'?'on':'')+'" onclick="v11Mode(\'select\')">☝ 拖棋子</button><button class="'+(COMBAT.editMode==='pan'?'on':'')+'" onclick="v11Mode(\'pan\')">✋ 拖地图</button><button class="'+(COMBAT.editMode==='add'?'on':'')+'" onclick="v11Mode(\'add\')">＋ 放单位</button><button class="'+(COMBAT.editMode==='terrain'?'on':'')+'" onclick="v11Terrain(\'wall\')">▦ 地形</button></div>';
 h+='</div>';
 if(isDM){
   if(combat){var cur=e.units.find(function(u){return u.id===e.currentUnitId;});h+='<div class="v11-turn"><div class="who"><small>当前行动</small><b>'+(cur?esc(cur.name):'尚未指定')+'</b></div><button onclick="combatPrevTurn();initMapCanvas()">上一位</button><button class="next" onclick="combatNextTurn();initMapCanvas()">下一位</button></div>';h+='<div class="v11-mainact"><button onclick="combatRollAllInit();initMapCanvas()">🎲 全体先攻</button><button class="red" onclick="combatEnd()">结束战斗 · 回到探索</button></div>';
   }else h+='<div class="v11-mainact"><button onclick="v10AddConnectedPlayers()">＋ 放入玩家</button><button class="go" onclick="v10Combat()">⚔ 进入战斗</button></div>';
   var su=e.units.find(function(u){return u.id===COMBAT.selectedUnitId;});if(su){h+='<div class="v11-selected"><b>'+esc(su.name)+'</b> · HP '+su.hp+'/'+su.maxHP+' · AC '+su.ac+'<div class="row">'+(combat?'<button onclick="v9SetTurn(\''+su.id+'\')">轮到 TA</button>':'')+'<button onclick="v9ToggleHidden(\''+su.id+'\')">'+(su.hidden?'显示':'隐藏')+'</button><button onclick="v9Duplicate(\''+su.id+'\')">复制</button><button onclick="combatEditUnit(\''+su.id+'\')">编辑</button><button class="d" onclick="v9Delete(\''+su.id+'\')">移除</button></div></div>';}
   h+='<div class="v11-drawer"><details '+(COMBAT.editMode==='terrain'?'open':'')+'><summary>场景工具</summary><div class="inside"><div class="v11-quick"><button onclick="v11QuickUnit(\'enemy\')">👹 怪物</button><button onclick="v11QuickUnit(\'npc\')">🧑 NPC</button><button onclick="v11QuickUnit(\'object\')">◈ 物件</button><button onclick="v9Resize()">↔ 地图尺寸</button></div><div style="height:8px"></div><div class="v11-terrain"><button onclick="v11Terrain(\'wall\')">墙</button><button onclick="v11Terrain(\'door\')">门</button><button onclick="v11Terrain(\'difficult\')">困难</button><button onclick="v11Terrain(\'water\')">水</button><button onclick="v11Terrain(\'fire\')">火</button><button onclick="v11Terrain(\'trap\')">陷阱</button><button onclick="v11Terrain(\'erase\')">橡皮</button><button onclick="v9ClearTerrain()">清地形</button></div></div></details><details><summary>全部单位 · '+e.units.length+'</summary><div class="inside">'+renderUnitList(e,true)+'</div></details></div>';
 }else{
   if(combat){var pc=e.units.find(function(u){return u.id===e.currentUnitId;});h+='<div class="v11-turn"><div class="who"><small>现在轮到</small><b>'+(pc?esc(pc.name):'等待 DM')+'</b></div></div>';}
   h+='<div class="v11-drawer"><details><summary>'+(combat?'先攻顺序':'场景中的角色')+'</summary><div class="inside">'+renderUnitList(e,false)+'</div></details></div>';
 }
 h+='</div>';host.innerHTML=h;
 var canvas=$('mapCanvas');COMBAT.canvas=canvas;COMBAT.ctx=canvas.getContext('2d');var wrap=$('mapWrap'),w=wrap.clientWidth;canvas.width=Math.max(300,Math.min(w,760));canvas.height=Math.max(400,Math.min(680,window.innerHeight*.62));drawMap();bindMapEvents();
};
