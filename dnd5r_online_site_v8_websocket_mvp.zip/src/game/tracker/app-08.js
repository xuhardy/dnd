
/* V20 · DM-authoritative P2P lobby */
(function(){
  var RECENT='dnd5r_v20_recent_rooms';
  DM.phase=DM.phase||'lobby'; DM.locked=!!DM.locked;
  function recent(){try{return JSON.parse(localStorage.getItem(RECENT)||'[]')}catch(e){return[]}}
  function saveRecent(code){try{var a=recent().filter(function(x){return x.code!==code});a.unshift({code:code,t:Date.now()});localStorage.setItem(RECENT,JSON.stringify(a.slice(0,5)))}catch(e){}}
  function seatId(){return S&&S.id?S.id:''}
  function meta(d){var cn=d.cls&&CLASSES[d.cls]?CLASSES[d.cls].n:(d.cls||'');return [cn,'Lv.'+(d.level||1),'HP '+(d.currentHP||0)+'/'+(d.maxHP||0)].filter(Boolean).join(' · ')}
  window.v20CreateFromHome=function(){openDMHome();setTimeout(function(){dmCreateRoom();},0)};
  window.v20JoinFromHome=function(){openDMHome();setTimeout(function(){dmShowJoinDialog();},0)};
  window.v20ToggleReady=function(){if(DM.role!=='player')return;DM.myReady=!DM.myReady;P2P.send({type:'lobby-ready',ready:DM.myReady,charId:seatId()});renderDMHome()};
  window.v20ToggleLock=function(){if(DM.role!=='dm')return;DM.locked=!DM.locked;P2P.broadcast({type:'lobby-state',locked:DM.locked,phase:DM.phase});renderDMHome()};
  window.v20StartGame=function(){
    if(DM.role!=='dm')return;
    var online=DM.players.filter(function(p){return p.online!==false});
    if(!online.length){alert('至少需要 1 名在线玩家');return}
    var unready=online.filter(function(p){return !p.ready});
    if(unready.length && !confirm('还有 '+unready.length+' 名玩家未准备，仍然开始吗？'))return;
    DM.phase='game'; DM.locked=true; dmLog('DM 开始冒险','sys');
    P2P.broadcast({type:'game-start',roomCode:DM.roomCode}); renderDMHome();
  };
  window.v20BackLobby=function(){if(DM.role!=='dm')return;DM.phase='lobby';P2P.broadcast({type:'lobby-return'});renderDMHome()};
  window.v20SwitchChar=function(){dmShowJoinDialog()};

  var oldCreate=window.dmCreateRoom;
  window.dmCreateRoom=function(){oldCreate();DM.phase='lobby';DM.locked=false;DM.players=[];renderDMHome()};
  var oldJoin=window.dmJoinRoom;
  window.dmJoinRoom=function(code,charId){DM.phase='lobby';DM.myReady=false;saveRecent(code);oldJoin(code,charId)};

  // Keep seats on transient disconnects instead of deleting them.
  var oldInit=P2P.init;
  P2P.init=function(role,code){oldInit.call(P2P,role,code);if(role==='dm'){
    P2P.onPlayerLeave=function(conn){var p=DM.players.find(function(x){return x.conn===conn});if(p){p.online=false;p.conn=null;dmLog('「'+((p.data&&p.data.name)||'玩家')+'」掉线，席位保留','sys');broadcastParty();renderDMHome()}}
  }};

  var oldHandle=window.dmHandlePlayerData;
  window.dmHandlePlayerData=function(data,conn){
    if(data&&data.type==='join'){
      if(DM.locked && DM.phase==='game') {P2P.sendTo({type:'join-denied',reason:'冒险已经开始，大厅目前锁定'},conn);try{conn.close()}catch(e){}return}
      var cd=data.charData||{};var ex=DM.players.find(function(p){return cd.id&&p.data&&p.data.id===cd.id});
      if(ex){ex.conn=conn;ex.data=cd;ex.online=true;P2P.sendTo({type:'welcome',roomCode:DM.roomCode,lobby:true,locked:DM.locked,phase:DM.phase},conn);broadcastParty();renderDMHome();return}
      oldHandle(data,conn);var p=DM.players.find(function(x){return x.conn===conn});if(p){p.ready=false;p.online=true}P2P.sendTo({type:'lobby-state',locked:DM.locked,phase:DM.phase},conn);renderDMHome();return
    }
    if(data&&data.type==='lobby-ready'){var p=DM.players.find(function(x){return x.conn===conn || (x.data&&x.data.id===data.charId)});if(p){p.ready=!!data.ready;p.online=true;dmLog('「'+(p.data.name||'玩家')+'」'+(p.ready?'已准备':'取消准备'),'sys');P2P.broadcast({type:'lobby-roster',members:DM.players.map(function(q){return{id:q.data.id,name:q.data.name,cls:q.data.cls,level:q.data.level,ready:!!q.ready,online:q.online!==false}})});renderDMHome()}return}
    oldHandle(data,conn)
  };

  var oldRender=window.renderDMHome||renderDMHome;
  renderDMHome=function(){
    if(!DM.active){return oldRender()}
    if(DM.phase==='game'){return oldRender()}
    var h='';
    if(DM.role==='dm'){
      h+='<div class="v20-lobby-head"><div class="v20-state">P2P 大厅 · DM 主机</div><div class="v20-code">'+esc(DM.roomCode||'------')+'</div><div class="v20-state">'+(DM.locked?'🔒 大厅已锁定':'🟢 可加入')+' · '+DM.players.filter(function(p){return p.online!==false}).length+' 人在线</div></div>';
      h+='<div class="v20-banner">玩家输入房间码后会先进入大厅。DM 是权威主机，只有点击「开始冒险」后才进入正式桌面。</div>';
      h+='<div class="tb"><div class="tt">大厅成员</div><div class="v20-seat"><div class="v20-av">DM</div><div class="v20-seatcopy"><b>地下城主</b><small>本机主机 · 房间状态由这里维护</small></div><span class="v20-pill host">HOST</span></div>';
      if(!DM.players.length)h+='<div class="empty-tip">等待玩家加入…</div>';
      DM.players.forEach(function(p,i){var d=p.data||{};h+='<div class="v20-seat '+(p.online===false?'offline':'')+'"><div class="v20-av">'+esc((d.name||'?').charAt(0))+'</div><div class="v20-seatcopy"><b>'+esc(d.name||'无名冒险者')+'</b><small>'+esc(meta(d))+' · '+(p.online===false?'掉线，席位保留':'在线')+'</small></div><span class="v20-pill '+(p.ready?'ready':'')+'">'+(p.ready?'✓ 已准备':'未准备')+'</span></div>'});
      h+='</div><div class="v20-actions"><button onclick="v20ToggleLock()">'+(DM.locked?'🔓 开放大厅':'🔒 锁定大厅')+'</button><button class="primary" onclick="v20StartGame()">▶ 开始冒险</button><button onclick="dmPing()">连接测试</button><button class="danger" onclick="dmCloseRoom()">关闭房间</button></div>';
    } else {
      var d=packCharData()||{};h+='<div class="v20-lobby-head"><div class="v20-state">已加入 P2P 大厅</div><div class="v20-code">'+esc(DM.roomCode||'------')+'</div><div class="v20-state">'+esc(dmStatusText())+'</div></div>';
      h+='<div class="tb"><div class="tt">我的席位</div><div class="v20-seat"><div class="v20-av">'+esc((d.name||'?').charAt(0))+'</div><div class="v20-seatcopy"><b>'+esc(d.name||'无名冒险者')+'</b><small>'+esc(meta(d))+'</small></div><span class="v20-pill '+(DM.myReady?'ready':'')+'">'+(DM.myReady?'✓ 已准备':'未准备')+'</span></div></div>';
      h+='<div class="v20-actions"><button class="primary" onclick="v20ToggleReady()">'+(DM.myReady?'取消准备':'✓ 准备')+'</button><button onclick="v20SwitchChar()">切换角色</button><button onclick="dmPing()">连接测试</button><button class="danger" onclick="dmLeaveRoom()">离开大厅</button></div><div class="v20-banner" style="margin-top:10px">等待 DM 开始冒险。掉线后会自动重连，同一角色 ID 会恢复原席位，不会生成重复玩家。</div>';
    }
    $('dmMain').innerHTML=h;
  };

  // Replace player connection callbacks after original join installs them.
  var baseJoin=window.dmJoinRoom;
  window.dmJoinRoom=function(code,charId){
    baseJoin(code,charId);
    var baseData=P2P.onData;
    P2P.onData=function(data,conn){
      if(data&&data.type==='welcome'){DM.phase='lobby';DM.statusState='ok';DM.statusText='已进入大厅 · '+code;saveRecent(code);showPage('pgDM');renderDMHome();return}
      if(data&&data.type==='lobby-state'){DM.phase=data.phase||'lobby';renderDMHome();return}
      if(data&&data.type==='lobby-roster'){DM.roster=data.members||[];renderDMHome();return}
      if(data&&data.type==='join-denied'){alert(data.reason||'无法加入房间');P2P.destroy();DM.active=false;DM.role=null;showPage('pgHome');renderHome();return}
      if(data&&data.type==='game-start'){DM.phase='game';$('trkTitle').textContent=(S&&S.name)||'角色卡';showPage('pgTrk');renderTrk();mountVoiceBar();return}
      if(data&&data.type==='lobby-return'){DM.phase='lobby';showPage('pgDM');renderDMHome();return}
      if(baseData)baseData(data,conn)
    };
    // Original callback jumps to tracker on transport connection. Pull player back into lobby shortly after handshake.
    setTimeout(function(){if(DM.role==='player'&&DM.phase==='lobby'){showPage('pgDM');renderDMHome()}},700);
  };

  // Make the DM page title match the new concept.
  var oldOpen=window.openDMHome;
  window.openDMHome=function(){oldOpen();if($('dmTitle'))$('dmTitle').textContent='P2P 跑团大厅'};
})();
