
// ==================== 基础属性 ====================
var AB=[
  {k:'str',n:'力量',e:'STR'},{k:'dex',n:'敏捷',e:'DEX'},{k:'con',n:'体质',e:'CON'},
  {k:'int',n:'智力',e:'INT'},{k:'wis',n:'感知',e:'WIS'},{k:'cha',n:'魅力',e:'CHA'}
];
var ABM={};AB.forEach(function(a){ABM[a.k]=a;});

// ==================== 物种 ====================
var SPECIES={
  human:{n:'人类',sp:30,dv:0,d:'全能，额外技能熟练'},
  elf:{n:'精灵',sp:30,dv:60,d:'黑暗视觉 60 尺，敏锐感官，妖精血统'},
  dwarf:{n:'矮人',sp:30,dv:120,d:'黑暗视觉 120 尺，矮人韧性，毒素抗性'},
  halfling:{n:'半身人',sp:30,dv:0,d:'幸运，勇敢，半身人敏捷'},
  dragonborn:{n:'龙裔',sp:30,dv:60,d:'龙血，吐息武器，能量抗性'},
  gnome:{n:'侏儒',sp:30,dv:60,d:'黑暗视觉 60 尺，侏儒狡黠'},
  tiefling:{n:'提夫林',sp:30,dv:60,d:'黑暗视觉 60 尺，火焰抗性，地狱遗赠'},
  orc:{n:'兽人',sp:30,dv:120,d:'黑暗视觉 120 尺，凶蛮冲锋，不屈耐力'}
};

// ==================== 职业 ====================
var CLASSES={
  fighter:{n:'战士',hd:10,sv:['str','con'],sc:2,gold:155,sk:['acrobatics','animal','athletics','history','insight','intimidation','perception','survival']},
  wizard:{n:'法师',hd:6,sv:['int','wis'],sc:2,gold:55,sk:['arcana','history','insight','investigation','medicine','religion']},
  rogue:{n:'盗贼',hd:8,sv:['dex','int'],sc:4,gold:100,sk:['acrobatics','athletics','deception','insight','intimidation','investigation','perception','performance','persuasion','sleight','stealth']},
  cleric:{n:'牧师',hd:8,sv:['wis','cha'],sc:2,gold:110,sk:['history','insight','medicine','persuasion','religion']},
  bard:{n:'吟游诗人',hd:8,sv:['dex','cha'],sc:3,gold:125,any:true},
  barbarian:{n:'野蛮人',hd:12,sv:['str','con'],sc:2,gold:75,sk:['animal','athletics','intimidation','nature','perception','survival']},
  ranger:{n:'游侠',hd:10,sv:['str','dex'],sc:3,gold:150,sk:['animal','athletics','insight','investigation','nature','perception','stealth','survival']},
  paladin:{n:'圣骑士',hd:10,sv:['wis','cha'],sc:2,gold:150,sk:['athletics','insight','intimidation','medicine','persuasion','religion']},
  druid:{n:'德鲁伊',hd:8,sv:['int','wis'],sc:2,gold:50,sk:['arcana','animal','insight','medicine','nature','perception','religion','survival']},
  monk:{n:'武僧',hd:8,sv:['str','dex'],sc:2,gold:50,sk:['acrobatics','athletics','history','insight','religion','stealth']},
  sorcerer:{n:'术士',hd:6,sv:['con','cha'],sc:2,gold:50,sk:['arcana','deception','intimidation','insight','persuasion','religion']},
  warlock:{n:'邪术师',hd:8,sv:['wis','cha'],sc:2,gold:100,sk:['arcana','deception','history','intimidation','investigation','nature','religion']}
};

// ==================== 施法者 ====================
var SPELLCASTER={
  wizard:{ab:'int',ct:3,sp:6},cleric:{ab:'wis',ct:3,sp:4},bard:{ab:'cha',ct:2,sp:4},
  druid:{ab:'wis',ct:2,sp:4},sorcerer:{ab:'cha',ct:4,sp:2},warlock:{ab:'cha',ct:2,sp:2},
  paladin:{ab:'cha',ct:0,sp:2},ranger:{ab:'wis',ct:0,sp:2}
};

// ==================== 法术位表 ====================
var FCS={1:[2],2:[3],3:[4,2],4:[4,3],5:[4,3,2],6:[4,3,3],7:[4,3,3,1],8:[4,3,3,2],9:[4,3,3,3,1],10:[4,3,3,3,2],11:[4,3,3,3,2,1],12:[4,3,3,3,2,1],13:[4,3,3,3,2,1,1],14:[4,3,3,3,2,1,1],15:[4,3,3,3,2,1,1,1],16:[4,3,3,3,2,1,1,1],17:[4,3,3,3,2,1,1,1,1],18:[4,3,3,3,3,1,1,1,1],19:[4,3,3,3,3,2,1,1,1],20:[4,3,3,3,3,2,2,1,1]};
var HCS={1:[],2:[2],3:[3],4:[3],5:[4,2],6:[4,2],7:[4,3],8:[4,3],9:[4,3,2],10:[4,3,2],11:[4,3,3],12:[4,3,3],13:[4,3,3,1],14:[4,3,3,1],15:[4,3,3,2],16:[4,3,3,2],17:[4,3,3,3,1],18:[4,3,3,3,1],19:[4,3,3,3,2],20:[4,3,3,3,2]};
var WLS={1:1,2:2,3:2,4:2,5:2,6:2,7:2,8:2,9:2,10:2,11:3,12:3,13:3,14:3,15:3,16:3,17:4,18:4,19:4,20:4};
var WLL={1:1,2:1,3:2,4:2,5:3,6:3,7:4,8:4,9:5,10:5,11:5,12:5,13:5,14:5,15:5,16:5,17:5,18:5,19:5,20:5};
var EXP_T=[0,300,900,2700,6500,14000,23000,34000,48000,64000,85000,100000,120000,140000,165000,195000,225000,265000,305000,355000];
function getSlots(cls,lv){
  if(!cls||!SPELLCASTER[cls])return[];
  lv=Math.max(1,Math.min(20,Number(lv)||1));
  if(cls==='warlock'){var s=WLS[lv]||0,l=WLL[lv]||0;var a=[];for(var i=1;i<=l;i++)a.push(i===l?s:0);return a;}
  if(cls==='paladin'||cls==='ranger')return HCS[lv]||[];
  return FCS[lv]||[];
}

// ==================== 戏法 ====================
var CANTRIPS=[
  {k:'acid_splash',n:'酸液飞溅',d:'1d6 强酸伤害',cl:['wizard','sorcerer'],t:'1 动作',r:'60 尺',c:'V, S',cn:0,du:'立即'},
  {k:'fire_bolt',n:'火焰箭',d:'远程攻击 1d10 火焰',cl:['wizard','sorcerer'],t:'1 动作',r:'120 尺',c:'V, S',cn:0,du:'立即'},
  {k:'ray_of_frost',n:'冰霜射线',d:'远程攻击 1d8 冷冻，减速 10 尺',cl:['wizard','sorcerer'],t:'1 动作',r:'60 尺',c:'V, S',cn:0,du:'立即'},
  {k:'shocking_grasp',n:'电爪',d:'近战攻击 1d8 闪电',cl:['wizard','sorcerer'],t:'1 动作',r:'触及',c:'V, S',cn:0,du:'立即'},
  {k:'poison_spray',n:'毒气喷射',d:'体质豁免 1d12 毒素',cl:['wizard','sorcerer','druid'],t:'1 动作',r:'10 尺',c:'V, S',cn:0,du:'立即'},
  {k:'eldritch_blast',n:'魔能爆',d:'远程攻击 1d10 力场',cl:['warlock'],t:'1 动作',r:'120 尺',c:'V, S',cn:0,du:'立即'},
  {k:'sacred_flame',n:'圣火',d:'敏捷豁免 1d8 光耀',cl:['cleric'],t:'1 动作',r:'60 尺',c:'V, S',cn:0,du:'立即'},
  {k:'vicious_mockery',n:'恶毒嘲笑',d:'感知豁免 1d6 心灵，劣势',cl:['bard'],t:'1 动作',r:'60 尺',c:'V',cn:0,du:'立即'},
  {k:'druidcraft',n:'德鲁伊工艺',d:'小型自然效果',cl:['druid'],t:'1 动作',r:'30 尺',c:'V, S',cn:0,du:'立即'},
  {k:'guidance',n:'神导术',d:'接触，属性检定 +1d4',cl:['cleric','druid'],t:'1 动作',r:'触及',c:'V, S',cn:1,du:'1 分钟'},
  {k:'light',n:'光亮术',d:'物体发光 20 尺半径',cl:['cleric','wizard','sorcerer','bard','druid'],t:'1 动作',r:'触及',c:'V, M',cn:0,du:'1 小时'},
  {k:'mage_hand',n:'法师之手',d:'操控 30 尺内物体',cl:['wizard','sorcerer','bard','warlock'],t:'1 动作',r:'30 尺',c:'V, S',cn:0,du:'1 分钟'},
  {k:'minor_illusion',n:'次级幻象',d:'制造声音或图像',cl:['wizard','sorcerer','bard','warlock'],t:'1 动作',r:'30 尺',c:'S, M',cn:0,du:'1 分钟'},
  {k:'prestidigitation',n:'奇术',d:'小型魔法效果',cl:['wizard','sorcerer','bard','warlock'],t:'1 动作',r:'10 尺',c:'V, S',cn:0,du:'1 小时'},
  {k:'spare_the_dying',n:'稳定伤势',d:'稳定濒死生物',cl:['cleric','druid'],t:'1 动作',r:'触及',c:'V, S',cn:0,du:'立即'},
  {k:'thaumaturgy',n:'奇术',d:'小型奇迹',cl:['cleric'],t:'1 动作',r:'30 尺',c:'V',cn:0,du:'1 分钟'},
  {k:'true_strike',n:'真实打击',d:'下次攻击有优势',cl:['wizard','sorcerer','bard','warlock'],t:'1 动作',r:'30 尺',c:'S',cn:0,du:'1 回合'},
  {k:'thorn_whip',n:'荆棘之鞭',d:'近战攻击 1d6 穿刺',cl:['druid'],t:'1 动作',r:'30 尺',c:'V, S, M',cn:0,du:'立即'},
  {k:'produce_flame',n:'烈焰',d:'投掷火焰 1d8',cl:['druid'],t:'1 动作',r:'自身',c:'V, S',cn:0,du:'10 分钟'},
  {k:'friends',n:'友善术',d:'对非敌对生物有优势',cl:['wizard','sorcerer','bard','warlock'],t:'1 动作',r:'自身',c:'S, M',cn:1,du:'1 分钟'}
];

// ==================== 一环法术 ====================
var LEVEL1_SPELLS=[
  {k:'magic_missile',n:'魔法飞弹',d:'自动命中 3×1d4+1 力场',cl:['wizard','sorcerer'],t:'1 动作',r:'120 尺',c:'V, S',cn:0,du:'立即',up:'每升 1 环多 1 枚飞弹'},
  {k:'shield',n:'护盾术',d:'反应，AC +5 到下一回合',cl:['wizard','sorcerer'],t:'1 反应',r:'自身',c:'V, S',cn:0,du:'1 回合'},
  {k:'mage_armor',n:'法师护甲',d:'AC 13+敏捷 8 小时',cl:['wizard','sorcerer'],t:'1 动作',r:'触及',c:'V, S, M',cn:0,du:'8 小时'},
  {k:'burning_hands',n:'燃烧之手',d:'15 尺锥形 3d6 火焰',cl:['wizard','sorcerer'],t:'1 动作',r:'自身 15 尺锥',c:'V, S',cn:0,du:'立即',up:'每升 1 环 +1d6 火焰'},
  {k:'sleep',n:'睡眠术',d:'5d8 HP 沉睡',cl:['wizard','sorcerer','bard'],t:'1 动作',r:'90 尺',c:'V, S, M',cn:0,du:'1 分钟',up:'每升 1 环 +2d8 HP'},
  {k:'thunderwave',n:'雷鸣波',d:'15 尺立方 2d8 雷鸣',cl:['wizard','sorcerer','bard','druid'],t:'1 动作',r:'自身 15 尺立方',c:'V, S',cn:0,du:'立即',up:'每升 1 环 +1d8 雷鸣'},
  {k:'feather_fall',n:'羽落术',d:'反应，减缓坠落',cl:['wizard','sorcerer','bard'],t:'1 反应',r:'60 尺',c:'V, M',cn:0,du:'1 分钟'},
  {k:'detect_magic',n:'侦测魔法',d:'感知 30 尺魔法',cl:['wizard','sorcerer','bard','cleric','druid','paladin','ranger','warlock'],t:'1 动作',r:'自身 30 尺',c:'V, S',cn:1,du:'10 分钟'},
  {k:'disguise_self',n:'伪装自我',d:'改变外观 1 小时',cl:['wizard','sorcerer','bard','warlock'],t:'1 动作',r:'自身',c:'V, S',cn:0,du:'1 小时'},
  {k:'silent_image',n:'无声幻影',d:'15 尺立方幻象',cl:['wizard','sorcerer','bard'],t:'1 动作',r:'60 尺',c:'V, S, M',cn:1,du:'10 分钟'},
  {k:'false_life',n:'假死',d:'1d4+4 临时 HP',cl:['wizard','sorcerer'],t:'1 动作',r:'自身',c:'V, S, M',cn:0,du:'1 小时'},
  {k:'charm_person',n:'魅惑人类',d:'感知豁免，魅惑 1 小时',cl:['wizard','sorcerer','bard','warlock','druid'],t:'1 动作',r:'30 尺',c:'V, S',cn:0,du:'1 小时',up:'每升 1 环多 1 个目标'},
  {k:'fog_cloud',n:'云雾术',d:'20 尺半径重度遮蔽',cl:['wizard','sorcerer','druid','ranger'],t:'1 动作',r:'120 尺',c:'V, S',cn:1,du:'1 小时',up:'每升 1 环半径 +20 尺'},
  {k:'jump',n:'跳跃',d:'跳跃距离 ×3',cl:['wizard','sorcerer','druid','ranger'],t:'1 动作',r:'触及',c:'V, S, M',cn:0,du:'1 分钟'},
  {k:'longstrider',n:'长跃',d:'速度 +10 尺 1 小时',cl:['wizard','sorcerer','bard','druid','ranger'],t:'1 动作',r:'触及',c:'V, S, M',cn:0,du:'1 小时',up:'每升 1 环多 1 个目标'},
  {k:'cure_wounds',n:'治疗真言',d:'接触治疗 1d8+施法属性',cl:['cleric','druid','bard','paladin','ranger'],t:'1 动作',r:'触及',c:'V, S',cn:0,du:'立即',up:'每升 1 环 +1d8 治疗'},
  {k:'healing_word',n:'治疗字',d:'附赠动作 1d4+施法属性',cl:['cleric','bard','druid'],t:'1 附赠',r:'60 尺',c:'V',cn:0,du:'立即',up:'每升 1 环 +1d4 治疗'},
  {k:'bless',n:'祝福术',d:'3 个生物攻击/豁免 +1d4',cl:['cleric','paladin'],t:'1 动作',r:'30 尺',c:'V, S, M',cn:1,du:'1 分钟',up:'每升 1 环多影响 1 个目标'},
  {k:'bane',n:'灾祸术',d:'3 个生物攻击/豁免 -1d4',cl:['cleric','bard','warlock'],t:'1 动作',r:'30 尺',c:'V, S, M',cn:1,du:'1 分钟',up:'每升 1 环多影响 1 个目标'},
  {k:'command',n:'命令术',d:'感知豁免，服从一个字命令',cl:['cleric','paladin','bard'],t:'1 动作',r:'60 尺',c:'V',cn:0,du:'1 回合',up:'每升 1 环多 1 个目标'},
  {k:'guiding_bolt',n:'指引之箭',d:'远程攻击 4d6 光耀',cl:['cleric'],t:'1 动作',r:'120 尺',c:'V, S',cn:0,du:'1 回合',up:'每升 1 环 +1d6 光耀'},
  {k:'shield_of_faith',n:'信仰护盾',d:'AC +2 10 分钟',cl:['cleric','paladin'],t:'1 动作',r:'60 尺',c:'V, S, M',cn:1,du:'10 分钟'},
  {k:'protection_evil',n:'防护善恶',d:'防护六类生物',cl:['cleric','paladin','wizard','warlock'],t:'1 动作',r:'触及',c:'V, S, M',cn:1,du:'10 分钟'},
  {k:'entangle',n:'缠绕',d:'20 尺方形，力量豁免或束缚',cl:['druid','ranger'],t:'1 动作',r:'90 尺',c:'V, S',cn:1,du:'1 分钟'},
  {k:'faerie_fire',n:'妖火',d:'20 尺立方，敏捷豁免或显形',cl:['druid','bard'],t:'1 动作',r:'60 尺',c:'V',cn:1,du:'1 分钟'},
  {k:'hunters_mark',n:'猎人印记',d:'标记目标，+1d6 伤害',cl:['ranger'],t:'1 附赠',r:'90 尺',c:'V',cn:1,du:'1 小时',up:'每升 1 环持续更久'},
  {k:'goodberry',n:'神莓',d:'10 个浆果，每个恢复 1 HP',cl:['druid','ranger'],t:'1 动作',r:'触及',c:'V, S, M',cn:0,du:'立即'},
  {k:'divine_favor',n:'神恩',d:'武器攻击 +1d4 光耀',cl:['paladin'],t:'1 附赠',r:'自身',c:'V, S',cn:1,du:'1 分钟'},
  {k:'searing_smite',n:'灼热斩',d:'武器攻击 +1d6 火焰',cl:['paladin'],t:'1 附赠',r:'自身',c:'V',cn:1,du:'1 分钟',up:'每升 1 环 +1d6 火焰'},
  {k:'thunderous_smite',n:'雷鸣斩',d:'武器攻击 +2d6 雷鸣',cl:['paladin'],t:'1 附赠',r:'自身',c:'V',cn:1,du:'1 分钟',up:'每升 1 环 +1d6 雷鸣'},
  {k:'hex',n:'诅咒',d:'标记目标，+1d6 暗蚀',cl:['warlock'],t:'1 附赠',r:'90 尺',c:'V, S, M',cn:1,du:'1 小时',up:'每升 1 环持续更久'},
  {k:'arms_of_hadar',n:'哈达之臂',d:'10 尺半径 2d6 冷冻',cl:['warlock'],t:'1 动作',r:'自身 10 尺',c:'V, S',cn:0,du:'立即',up:'每升 1 环 +1d6 冷冻'},
  {k:'dissonant_whispers',n:'不协之语',d:'感知豁免 3d6 心灵',cl:['bard'],t:'1 动作',r:'60 尺',c:'V',cn:0,du:'立即',up:'每升 1 环 +1d6 心灵'}
];

// ==================== 二环法术 ====================
var LEVEL2_SPELLS=[
  {k:'scorching_ray',n:'灼热射线',d:'3 道射线，每道远程攻击 2d6 火焰',cl:['wizard','sorcerer'],t:'1 动作',r:'120 尺',c:'V, S',cn:0,du:'立即',up:'每升 1 环多 1 道射线'},
  {k:'invisibility',n:'隐形术',d:'目标隐形直到攻击或施法',cl:['wizard','sorcerer','bard','warlock'],t:'1 动作',r:'触及',c:'V, S, M',cn:1,du:'1 小时',up:'每升 1 环多 1 个目标'},
  {k:'mirror_image',n:'镜像术',d:'创造 3 个幻影分身',cl:['wizard','sorcerer','warlock'],t:'1 动作',r:'自身',c:'V, S',cn:0,du:'1 分钟'},
  {k:'misty_step',n:'迷踪步',d:'附赠动作传送 30 尺',cl:['wizard','sorcerer','warlock'],t:'1 附赠',r:'自身',c:'V',cn:0,du:'立即'},
  {k:'spiritual_weapon',n:'灵能武器',d:'召唤浮空武器，附赠攻击 1d8+施法属性',cl:['cleric'],t:'1 附赠',r:'60 尺',c:'V, S',cn:0,du:'1 分钟',up:'每升 2 环 +1d8 伤害'},
  {k:'lesser_restoration',n:'次级复原',d:'结束疾病或一种状态',cl:['cleric','druid','bard','paladin','ranger'],t:'1 动作',r:'触及',c:'V, S',cn:0,du:'立即'},
  {k:'aid',n:'援助',d:'3 个生物 HP 上限 +5',cl:['cleric','paladin','bard'],t:'1 动作',r:'30 尺',c:'V, S, M',cn:0,du:'8 小时',up:'每升 1 环 +5 HP 上限'},
  {k:'web',n:'蛛网术',d:'20 尺立方，敏捷豁免或束缚',cl:['wizard','sorcerer'],t:'1 动作',r:'60 尺',c:'V, S, M',cn:1,du:'1 小时'}
];

// ==================== 三环法术 ====================
var LEVEL3_SPELLS=[
  {k:'fireball',n:'火球术',d:'20 尺半径 8d6 火焰',cl:['wizard','sorcerer'],t:'1 动作',r:'150 尺',c:'V, S, M',cn:0,du:'立即',up:'每升 1 环 +1d6 火焰'},
  {k:'lightning_bolt',n:'闪电束',d:'100 尺长线 8d6 闪电',cl:['wizard','sorcerer'],t:'1 动作',r:'自身 100 尺线',c:'V, S, M',cn:0,du:'立即',up:'每升 1 环 +1d6 闪电'},
  {k:'counterspell',n:'反制法术',d:'反应，中断一个法术',cl:['wizard','sorcerer','warlock'],t:'1 反应',r:'60 尺',c:'S',cn:0,du:'立即'},
  {k:'dispel_magic',n:'解除魔法',d:'结束 3 环及以下法术效果',cl:['wizard','sorcerer','bard','cleric','druid','paladin','warlock'],t:'1 动作',r:'120 尺',c:'V, S',cn:0,du:'立即',up:'自动解除更高环法术需检定'},
  {k:'fly',n:'飞行',d:'目标获得 60 尺飞行速度',cl:['wizard','sorcerer','warlock'],t:'1 动作',r:'触及',c:'V, S, M',cn:1,du:'10 分钟',up:'每升 1 环多 1 个目标'},
  {k:'revivify',n:'回生术',d:'复活 1 分钟内死亡的生物',cl:['cleric','paladin','ranger'],t:'1 动作',r:'触及',c:'V, S, M',cn:0,du:'立即'}
];

// ==================== 起源专长 ====================
var FEATS={
  mi_cleric:{n:'魔法学徒（牧师）',d:'习得两个牧师戏法和一个一环法术。'},
  mi_druid:{n:'魔法学徒（德鲁伊）',d:'习得两个德鲁伊戏法和一个一环法术。'},
  mi_wizard:{n:'魔法学徒（法师）',d:'习得两个法师戏法和一个一环法术。'},
  crafter:{n:'工匠',d:'获得三种工匠工具熟练。'},
  skilled:{n:'技能娴熟',d:'获得任意三项技能或工具熟练。'},
  alert:{n:'警觉',d:'先攻获得熟练加值。'},
  musician:{n:'乐师',d:'获得三种乐器熟练。'},
  tough:{n:'坚韧',d:'HP 每级额外 +2。'},
  healer:{n:'医者',d:'使用医疗包额外恢复 1d6+熟练 HP。'},
  lucky:{n:'幸运',d:'获得幸运点（每长休 = 熟练加值）。'},
  brawler:{n:'酒馆殴斗者',d:'徒手打击造成 1d4 + 力量伤害。'},
  savage:{n:'凶蛮攻击者',d:'每回合一次可重掷武器伤害骰。'}
};

// ==================== 背景 ====================
var BACKGROUNDS={
  acolyte:{n:'侍僧',ab:['int','wis','cha'],f:'mi_cleric',sk:['insight','religion']},
  artisan:{n:'工匠',ab:['str','dex','int'],f:'crafter',sk:['investigation','persuasion']},
  charlatan:{n:'骗子',ab:['dex','con','cha'],f:'skilled',sk:['deception','sleight']},
  criminal:{n:'罪犯',ab:['dex','con','int'],f:'alert',sk:['sleight','stealth']},
  entertainer:{n:'艺人',ab:['str','dex','cha'],f:'musician',sk:['acrobatics','performance']},
  farmer:{n:'农夫',ab:['str','con','wis'],f:'tough',sk:['animal','nature']},
  guard:{n:'守卫',ab:['str','int','wis'],f:'alert',sk:['athletics','perception']},
  sage:{n:'贤者',ab:['con','int','wis'],f:'mi_wizard',sk:['arcana','history']},
  soldier:{n:'士兵',ab:['str','dex','con'],f:'savage',sk:['athletics','intimidation']},
  noble:{n:'贵族',ab:['str','int','cha'],f:'skilled',sk:['history','persuasion']}
};

// ==================== 技能 ====================
var SKILLS=[
  {k:'acrobatics',n:'杂技',a:'dex'},{k:'animal',n:'动物驯养',a:'wis'},{k:'arcana',n:'奥秘',a:'int'},
  {k:'athletics',n:'运动',a:'str'},{k:'deception',n:'欺瞒',a:'cha'},{k:'history',n:'历史',a:'int'},
  {k:'insight',n:'洞悉',a:'wis'},{k:'intimidation',n:'威吓',a:'cha'},{k:'investigation',n:'调查',a:'int'},
  {k:'medicine',n:'医药',a:'wis'},{k:'nature',n:'自然',a:'int'},{k:'perception',n:'察觉',a:'wis'},
  {k:'performance',n:'表演',a:'cha'},{k:'persuasion',n:'说服',a:'cha'},{k:'religion',n:'宗教',a:'int'},
  {k:'sleight',n:'巧手',a:'dex'},{k:'stealth',n:'隐匿',a:'dex'},{k:'survival',n:'生存',a:'wis'}
];
var SKM={};SKILLS.forEach(function(s){SKM[s.k]=s;});

// ==================== 护甲 ====================
var ARMORS={
  none:{n:'无甲',b:10,c:Infinity,p:0},leather:{n:'皮甲',b:11,c:Infinity,p:10},
  studded:{n:'镶钉皮甲',b:12,c:Infinity,p:45},hide:{n:'兽皮甲',b:12,c:2,p:10},
  chain:{n:'链甲衫',b:13,c:2,p:50},scale:{n:'鳞甲',b:14,c:2,p:50},
  breastplate:{n:'胸甲',b:14,c:2,p:400},chainmail:{n:'链甲',b:16,c:0,p:75},plate:{n:'板甲',b:18,c:0,p:1500}
};

// ==================== 武器 ====================
var WEAPONS={
  club:{n:'木棒',d:'1d4',dt:'钝击',pr:['轻型'],p:0.1},
  dagger:{n:'匕首',d:'1d4',dt:'穿刺',pr:['灵巧','轻型','投掷'],p:2},
  handaxe:{n:'手斧',d:'1d6',dt:'挥砍',pr:['轻型','投掷'],p:5},
  javelin:{n:'标枪',d:'1d6',dt:'穿刺',pr:['投掷'],p:0.5},
  mace:{n:'钉头锤',d:'1d6',dt:'钝击',pr:[],p:5},
  quarterstaff:{n:'长棍',d:'1d6',dt:'钝击',pr:['两用'],p:0.2},
  spear:{n:'长矛',d:'1d6',dt:'穿刺',pr:['投掷','两用'],p:1},
  shortbow:{n:'短弓',d:'1d6',dt:'穿刺',pr:['弹药','双手'],p:25},
  light_crossbow:{n:'轻弩',d:'1d8',dt:'穿刺',pr:['弹药','双手','装填'],p:25},
  battleaxe:{n:'战斧',d:'1d8',dt:'挥砍',pr:['两用'],p:10},
  greataxe:{n:'巨斧',d:'1d12',dt:'挥砍',pr:['重型','双手'],p:30},
  greatsword:{n:'巨剑',d:'2d6',dt:'挥砍',pr:['重型','双手'],p:50},
  longsword:{n:'长剑',d:'1d8',dt:'挥砍',pr:['两用'],p:15},
  rapier:{n:'刺剑',d:'1d8',dt:'穿刺',pr:['灵巧'],p:25},
  scimitar:{n:'弯刀',d:'1d6',dt:'挥砍',pr:['灵巧','轻型'],p:25},
  shortsword:{n:'短剑',d:'1d6',dt:'穿刺',pr:['灵巧','轻型'],p:10},
  warhammer:{n:'战锤',d:'1d8',dt:'钝击',pr:['两用'],p:15},
  longbow:{n:'长弓',d:'1d8',dt:'穿刺',pr:['弹药','重型','双手'],p:50}
};

// ==================== 装备 ====================
var GEAR={
  survival:{n:'生存物资',it:{
    backpack:{n:'背包',p:2},bedroll:{n:'铺盖卷',p:1},torch:{n:'火把',p:0.01},
    rations:{n:'干粮',p:0.5},waterskin:{n:'水袋',p:0.2},tinderbox:{n:'燧石',p:0.5}
  }},
  tools:{n:'工具',it:{
    rope:{n:'麻绳50尺',p:1},lantern:{n:'提灯',p:5},crowbar:{n:'撬棍',p:2},
    thieves:{n:'盗贼工具',p:25},healers:{n:'医药包',p:5},spellbook:{n:'法术书',p:50}
  }},
  ammo:{n:'弹药',it:{
    arrows:{n:'箭矢（20 支/组）',p:1,ammoType:'箭矢',ammoQty:20},
    bolts:{n:'弩矢（20 支/组）',p:1,ammoType:'弩矢',ammoQty:20},
    needles:{n:'吹箭（50 支/组）',p:1,ammoType:'吹箭',ammoQty:50},
    bullets:{n:'投石索弹（20 颗/组）',p:0.04,ammoType:'投石索弹',ammoQty:20},
    darts:{n:'飞镖（20 支/组）',p:0.1,ammoType:'飞镖',ammoQty:20},
    firearm_bullets:{n:'火器子弹（10 颗/组）',p:3,ammoType:'子弹',ammoQty:10}
  }},
  consumable:{n:'消耗品',it:{
    potion:{n:'治疗药水',p:50},antitoxin:{n:'解毒剂',p:50},acid:{n:'强酸瓶',p:25}
  }}
};

// ==================== 消耗品效果 ====================
var CONSUMABLE_EFFECTS={
  '治疗药水':   {dice:'2d4+2', eff:'heal',   d:'恢复 2d4+2 HP'},
  '高等治疗药水':{dice:'4d4+4', eff:'heal',   d:'恢复 4d4+4 HP'},
  '超等治疗药水':{dice:'8d4+8', eff:'heal',   d:'恢复 8d4+8 HP'},
  '解毒剂':     {eff:'buff',  d:'1 小时内对抗中毒的豁免有优势'},
  '强酸瓶':     {dice:'2d6',  eff:'attack', d:'投掷造成 2d6 强酸伤害'},
  '圣水':       {dice:'2d6',  eff:'attack', d:'对邪魔/亡灵造成 2d6 光耀伤害'},
  '炽火胶':     {dice:'1d4',  eff:'attack', d:'投掷造成 1d4 火焰伤害并点燃'},
  '干粮':       {eff:'flavor', d:'恢复 1 天食物'},
  '水袋':       {eff:'flavor', d:'恢复 1 天饮水'},
  '医疗包':     {eff:'heal',   dice:'1d6', d:'稳定伤势 / 恢复 1d6 HP'},
  '热食':       {eff:'flavor', d:'恢复 1 天食物'},
  '麦酒':       {eff:'flavor', d:'一杯提神麦酒'},
  '红酒':       {eff:'flavor', d:'一瓶上等红酒'}
};

// ==================== 状态 ====================
var COND=[
  ['blinded','目盲'],['charmed','魅惑'],['deafened','耳聋'],['frightened','恐慌'],
  ['grappled','擒抱'],['incapacitated','失能'],['invisible','隐形'],['paralyzed','麻痹'],
  ['petrified','石化'],['poisoned','中毒'],['prone','倒地'],['restrained','束缚'],
  ['stunned','昏迷'],['unconscious','失去意识']
];

// ==================== 2024 力竭 ====================
var EXH=[
  ['exh1','力竭 1','D20 检定 −2 · 速度 −5 尺'],['exh2','力竭 2','D20 检定 −4 · 速度 −10 尺'],
  ['exh3','力竭 3','D20 检定 −6 · 速度 −15 尺'],['exh4','力竭 4','D20 检定 −8 · 速度 −20 尺'],
  ['exh5','力竭 5','D20 检定 −10 · 速度 −25 尺'],['exh6','力竭 6','死亡']
];

// ==================== 点数购买 ====================
var PBC={8:0,9:1,10:2,11:3,12:4,13:5,14:7,15:9};
var PBT=27,SA=[15,14,13,12,10,8],TSTEPS=11;
var KEY='dnd5r_v19';
var DM_KEY='dnd5r_dm_v1';

// ==================== 职业资源 ====================
var CLASS_RESOURCES = {
  barbarian: [{ k:'rage', n:'狂暴', max:function(lv){return lv>=3?3:2;}, reset:'long', lv:1, d:'进入狂暴：近战伤害 +2，抗性，优势力量检定' }],
  bard: [{ k:'inspiration', n:'吟唱激励', max:function(lv,cha){return Math.max(1,cha);}, reset:'short', lv:1, d:'附赠动作给予盟友 1d6 激励骰' }],
  cleric: [{ k:'channel', n:'引导神力', max:function(lv){return lv>=6?2:1;}, reset:'short', lv:2, d:'驱散亡灵 / 神圣干预' }],
  druid: [{ k:'wildshape', n:'野性形态', max:function(lv){return 2;}, reset:'short', lv:2, d:'变形为已知野兽' }],
  fighter: [
    { k:'secondwind', n:'回气', max:function(lv){return 1;}, reset:'short', lv:1, d:'附赠动作恢复 1d10+等级 HP' },
    { k:'action', n:'动作如潮', max:function(lv){return lv>=17?2:1;}, reset:'short', lv:2, d:'本回合额外一个动作' }
  ],
  monk: [{ k:'ki', n:'气', max:function(lv){return lv;}, reset:'short', lv:2, d:'疾风连击 / 闪避 / 撤步' }],
  paladin: [
    { k:'lay', n:'圣疗池', max:function(lv){return 5*lv;}, reset:'long', lv:1, d:'每点恢复 1 HP（可消耗任意点数）', pool:true },
    { k:'channel', n:'引导神力', max:function(lv){return 1;}, reset:'short', lv:3, d:'神圣感知 / 誓言' }
  ],
  ranger: [], rogue: [],
  sorcerer: [{ k:'sorcery', n:'术法点', max:function(lv){return lv;}, reset:'long', lv:2, d:'超魔法' }],
  warlock: [{ k:'pact', n:'契约魔法', max:function(lv){return lv>=11?3:2;}, reset:'short', lv:1, d:'短休/长休恢复全部法术位' }],
  wizard: [{ k:'arcane', n:'奥术恢复', max:function(lv){return 1;}, reset:'long', lv:1, d:'短休恢复部分法术位' }]
};

// ==================== 弹药 ====================
var AMMO_TYPES = ['箭矢','弩矢','子弹','投石索弹','飞镖','吹箭'];
var AMMO_WEAPON_MAP = {
  '箭矢': ['shortbow','longbow'], '弩矢': ['light_crossbow'],
  '吹箭': [], '投石索弹': [], '飞镖': [], '子弹': []
};
var AMMO_GP_RATE = { '箭矢':20, '弩矢':20, '吹箭':50, '投石索弹':500, '飞镖':200, '子弹':3 };
function getAmmoForWeapon(k){
  if(!k || !WEAPONS[k]) return null;
  for(var an in AMMO_WEAPON_MAP){
    if(AMMO_WEAPON_MAP[an].indexOf(k) >= 0) return an;
  }
  return null;
}

// ==================== 货币 ====================
var CURRENCY_META = [
  {k:'pp', n:'铂金', e:'PP', toCp:1000},
  {k:'gp', n:'金币', e:'GP', toCp:100},
  {k:'ep', n:'银金', e:'EP', toCp:50},
  {k:'sp', n:'银币', e:'SP', toCp:10},
  {k:'cp', n:'铜币', e:'CP', toCp:1}
];
function currencyToCp(cur){ var t=0; CURRENCY_META.forEach(function(m){ t += (cur[m.k]||0)*m.toCp; }); return t; }
function currencyGpValue(cur){ return currencyToCp(cur)/100; }
function cpToCurrency(cp){
  var c = {pp:0, gp:0, ep:0, sp:0, cp:0};
  if (cp <= 0) return c;
  c.pp = Math.floor(cp/1000); cp -= c.pp*1000;
  c.gp = Math.floor(cp/100); cp -= c.gp*100;
  c.ep = Math.floor(cp/50); cp -= c.ep*50;
  c.sp = Math.floor(cp/10); cp -= c.sp*10;
  c.cp = cp;
  return c;
}

// ==================== 商店 ====================
var SHOPS = {
  smith:{n:'铁匠铺',icon:'⚔',desc:'近战武器',items:[
    {n:'匕首',p:2,cat:'weapon',k:'dagger',d:'1d4 穿刺，灵巧/轻型/投掷'},
    {n:'手斧',p:5,cat:'weapon',k:'handaxe',d:'1d6 挥砍，轻型/投掷'},
    {n:'钉头锤',p:5,cat:'weapon',k:'mace',d:'1d6 钝击'},
    {n:'长棍',p:0.2,cat:'weapon',k:'quarterstaff',d:'1d6 钝击，两用'},
    {n:'长矛',p:1,cat:'weapon',k:'spear',d:'1d6 穿刺，投掷/两用'},
    {n:'战斧',p:10,cat:'weapon',k:'battleaxe',d:'1d8 挥砍，两用'},
    {n:'长剑',p:15,cat:'weapon',k:'longsword',d:'1d8 挥砍，两用'},
    {n:'战锤',p:15,cat:'weapon',k:'warhammer',d:'1d8 钝击，两用'},
    {n:'刺剑',p:25,cat:'weapon',k:'rapier',d:'1d8 穿刺，灵巧'},
    {n:'弯刀',p:25,cat:'weapon',k:'scimitar',d:'1d6 挥砍，灵巧/轻型'},
    {n:'短剑',p:10,cat:'weapon',k:'shortsword',d:'1d6 穿刺，灵巧/轻型'},
    {n:'巨斧',p:30,cat:'weapon',k:'greataxe',d:'1d12 挥砍，重型/双手'},
    {n:'巨剑',p:50,cat:'weapon',k:'greatsword',d:'2d6 挥砍，重型/双手'}
  ]},
  fletcher:{n:'弓箭坊',icon:'🏹',desc:'远程武器与弹药',items:[
    {n:'短弓',p:25,cat:'weapon',k:'shortbow',d:'1d6 穿刺，弹药/双手'},
    {n:'长弓',p:50,cat:'weapon',k:'longbow',d:'1d8 穿刺，弹药/重型/双手'},
    {n:'轻弩',p:25,cat:'weapon',k:'light_crossbow',d:'1d8 穿刺，弹药/装填'},
    {n:'标枪',p:0.5,cat:'weapon',k:'javelin',d:'1d6 穿刺，投掷'},
    {n:'箭矢 ×20',p:1,cat:'ammo',an:'箭矢',qty:20,d:'20 支箭矢'},
    {n:'弩矢 ×20',p:1,cat:'ammo',an:'弩矢',qty:20,d:'20 支弩矢'}
  ]},
  armorer:{n:'护甲铺',icon:'🛡',desc:'护甲与盾牌',items:[
    {n:'皮甲',p:10,cat:'armor',k:'leather',d:'AC 11 + 敏捷'},
    {n:'镶钉皮甲',p:45,cat:'armor',k:'studded',d:'AC 12 + 敏捷'},
    {n:'兽皮甲',p:10,cat:'armor',k:'hide',d:'AC 12 + 敏捷（上限2）'},
    {n:'链甲衫',p:50,cat:'armor',k:'chain',d:'AC 13 + 敏捷（上限2）'},
    {n:'鳞甲',p:50,cat:'armor',k:'scale',d:'AC 14 + 敏捷（上限2）'},
    {n:'胸甲',p:400,cat:'armor',k:'breastplate',d:'AC 14 + 敏捷（上限2）'},
    {n:'链甲',p:75,cat:'armor',k:'chainmail',d:'AC 16'},
    {n:'板甲',p:1500,cat:'armor',k:'plate',d:'AC 18'},
    {n:'盾牌',p:10,cat:'shield',d:'+2 AC'}
  ]},
  general:{n:'杂货铺',icon:'🎒',desc:'冒险必备',items:[
    {n:'背包',p:2,cat:'gear',d:'容纳装备'},
    {n:'铺盖卷',p:1,cat:'gear',d:'露营用'},
    {n:'火把',p:0.01,cat:'gear',d:'照亮 20 尺'},
    {n:'干粮',p:0.5,cat:'consumable',cn:'干粮',d:'1 天份'},
    {n:'水袋',p:0.2,cat:'consumable',cn:'水袋',d:'1 天份'},
    {n:'燧石',p:0.5,cat:'gear',d:'点火'},
    {n:'麻绳 50 尺',p:1,cat:'gear',d:'承重 500 磅'},
    {n:'提灯',p:5,cat:'gear',d:'照亮 30 尺'},
    {n:'撬棍',p:2,cat:'gear',d:'撬门'},
    {n:'盗贼工具',p:25,cat:'gear',d:'开锁'},
    {n:'医药包',p:5,cat:'consumable',cn:'医疗包',d:'稳定伤势'},
    {n:'法术书',p:50,cat:'gear',d:'法师用'}
  ]},
  alchemist:{n:'药剂铺',icon:'⚗',desc:'药剂与炼金',items:[
    {n:'治疗药水',p:50,cat:'consumable',cn:'治疗药水',d:'恢复 2d4+2 HP'},
    {n:'解毒剂',p:50,cat:'consumable',cn:'解毒剂',d:'1 小时抗中毒优势'},
    {n:'强酸瓶',p:25,cat:'consumable',cn:'强酸瓶',d:'投掷 2d6 强酸'},
    {n:'圣水',p:25,cat:'consumable',cn:'圣水',d:'投掷 2d6 光耀'},
    {n:'炽火胶',p:50,cat:'consumable',cn:'炽火胶',d:'投掷 1d4 火焰并点燃'}
  ]},
  magic:{n:'法师塔',icon:'🔮',desc:'魔法物品',items:[
    {n:'法术书',p:50,cat:'gear',d:'法术记录'},
    {n:'高等治疗药水',p:150,cat:'consumable',cn:'高等治疗药水',d:'恢复 4d4+4 HP'},
    {n:'超等治疗药水',p:500,cat:'consumable',cn:'超等治疗药水',d:'恢复 8d4+8 HP'}
  ]},
  tavern:{n:'酒馆',icon:'🍺',desc:'饮食与住宿',items:[
    {n:'一顿饭',p:0.1,cat:'consumable',cn:'热食',d:'恢复 1 天食物'},
    {n:'一杯麦酒',p:0.04,cat:'consumable',cn:'麦酒',d:'提神'},
    {n:'一瓶红酒',p:1,cat:'consumable',cn:'红酒',d:'社交'},
    {n:'一晚住宿',p:0.5,cat:'gear',d:'恢复体力'}
  ]}
};

// ==================== 怪物库 ====================
var MONSTER_LIBRARY = {
  goblin:    { n:'哥布林',   hp:7,  ac:15, init:2, size:1, d:'1d6+2 弯刀',      cr:'1/4' },
  orc:       { n:'兽人',     hp:15, ac:13, init:1, size:1, d:'1d12+3 巨斧',     cr:'1/2' },
  wolf:      { n:'狼',       hp:11, ac:13, init:2, size:1, d:'1d6+2 咬，击倒',  cr:'1/4' },
  bandit:    { n:'强盗',     hp:11, ac:12, init:1, size:1, d:'1d6+1 弯刀',      cr:'1/8' },
  skeleton:  { n:'骷髅',     hp:13, ac:13, init:2, size:1, d:'1d6+2 短剑',      cr:'1/4' },
  zombie:    { n:'僵尸',     hp:22, ac:8,  init:-2,size:1, d:'1d6+1 猛击，坚韧',cr:'1/4' },
  ogre:      { n:'食人魔',   hp:59, ac:11, init:-1,size:2, d:'2d8+4 巨棒',      cr:'2' },
  troll:     { n:'巨魔',     hp:84, ac:15, init:1, size:2, d:'2d6+4 爪，再生',  cr:'5' },
  dragon_wyrmling:{ n:'幼龙',hp:33, ac:17, init:0, size:2, d:'2d6 咬 + 吐息',   cr:'3' },
  cultist:   { n:'邪教徒',   hp:9,  ac:12, init:1, size:1, d:'1d6+1 弯刀',      cr:'1/8' },
  guard:     { n:'守卫',     hp:11, ac:16, init:1, size:1, d:'1d6+1 矛',        cr:'1/8' },
  knight:    { n:'骑士',     hp:52, ac:18, init:0, size:1, d:'2d6+3 巨剑',      cr:'3' },
  mage:      { n:'法师',     hp:40, ac:12, init:2, size:1, d:'法术',            cr:'6' },
  spider:    { n:'巨蜘蛛',   hp:26, ac:14, init:3, size:1, d:'1d8+3 咬 + 毒',   cr:'1' },
  rat:       { n:'巨鼠',     hp:7,  ac:12, init:2, size:1, d:'1d4 咬',          cr:'1/8' },
  cult_fanatic:{n:'狂热信徒',hp:33, ac:13, init:1, size:1, d:'2d6+3 弯刀',      cr:'2' },
  bugbear:   { n:'熊地精',   hp:27, ac:16, init:2, size:1, d:'2d8+2 巨棒',      cr:'1' },
  hobgoblin: { n:'大地精',   hp:11, ac:18, init:1, size:1, d:'1d8+1 长剑',      cr:'1/2' },
  kobold:    { n:'狗头人',   hp:5,  ac:12, init:2, size:1, d:'1d4+2 匕首',      cr:'1/8' },
  stirge:    { n:'吸血虫',   hp:5,  ac:14, init:3, size:1, d:'1d4+3 吸血',      cr:'1/8' }
};

// 战斗状态
var COMBAT = {
  active: false,
  encounter: null,
  selectedUnitId: null,
  viewMode: 'list',
  showGrid: true,
  showHidden: false,
  zoom: 1,
  panX: 0,
  panY: 0,
  aoeShape: null,
  aoeSize: 2,
  aoeOriginUnitId: null,
  canvas: null,
  ctx: null,
  cellPx: 32,
  touchStartX: 0,
  touchStartY: 0,
  touchDragging: false,
  lastTapTime: 0,
  lastTapUnit: null,
  pinchStartDist: 0,
  pinchStartZoom: 1
};

var UNIT_COLORS = {
  player: '#c9a227',
  enemy: '#e05252',
  npc: '#7fb0e0',
  object: '#6d6252'
};

function newEncounter(name){
  return {
    id: 'enc_' + Date.now().toString(36),
    name: name || '新遭遇',
    active: false,
    grid: { w: 20, h: 20, cellSize: 5 },
    units: [],
    round: 1,
    currentUnitId: '',
    started: false,
    log: [],
    created: Date.now()
  };
}

function newUnit(opts){
  opts = opts || {};
  var t = opts.type || 'enemy';
  return {
    id: 'u_' + Date.now().toString(36) + Math.random().toString(36).substr(2,4),
    name: opts.name || '新单位',
    type: t,
    x: typeof opts.x === 'number' ? opts.x : 0,
    y: typeof opts.y === 'number' ? opts.y : 0,
    size: opts.size || 1,
    hp: typeof opts.hp === 'number' ? opts.hp : 10,
    maxHP: typeof opts.maxHP === 'number' ? opts.maxHP : (typeof opts.hp === 'number' ? opts.hp : 10),
    ac: opts.ac || 10,
    init: opts.init || 0,
    initRolled: opts.initRolled || false,
    conditions: [],
    hidden: false,
    ownerId: opts.ownerId || '',
    color: opts.color || UNIT_COLORS[t],
    notes: opts.notes || '',
    moveUsed: 0,
    moveMax: opts.moveMax || 30,
    actionUsed: false,
    bonusUsed: false,
    reactionUsed: false
  };
}

// ==================== P2P 状态 ====================
var P2P = {
  peer: null,
  role: null,
  roomCode: null,
  conns: [],
  hostConn: null,
  ready: false,
  onOpen: null,
  onPlayerJoin: null,
  onPlayerLeave: null,
  onData: null,
  onStatus: null,
  onError: null,
  msgCount: 0,
  lastLatency: null,
  lastPingSent: 0,
  reconnectTimer: null,
  reconnectAttempt: 0,
  heartbeatTimer: null,
  manualClose: false
};

// ==================== DM 状态 ====================
var DM = {
  active: false,
  role: null,
  roomCode: null,
  players: [],
  statusText: '未启动',
  statusState: 'off',
  log: [],
  note: '',
  myRole: null
};

// ==================== 语音状态 ====================
var VOICE = {
  enabled: false,        // 用户是否已经加入语音
  micOn: false,          // 麦克风是否开启
  localStream: null,     // 本地媒体流
  audioCtx: null,
  analyser: null,
  micAnalyser: null,
  peerConns: {},         // peerId -> {call, stream}
  remoteStreams: {},     // peerId -> MediaStream
  speaking: {},          // peerId -> bool
  localVolume: 0,
  remoteVolume: {},
  // 音频元素
  audioEls: {},
  // 音量检测循环
  rafId: null,
  // 多方：每个玩家的 peerId
  participants: []       // [{peerId, name, muted}]
};

// ==================== 玩家队伍 ====================
var PARTY = {
  members: []   // [{id, name, hp, maxHP, ac, conditions, online}]
};

var S = null;
var CHARS = [];
var curStep = 1;
var curShopId = null;
var diceAdvMode = 'normal';
// ==================== 基础工具 ====================
function $(id){ return document.getElementById(id); }
function qa(s){ return document.querySelectorAll(s); }
function mod(v){ return Math.floor((v-10)/2); }
function fmt(v){ return v>=0?'+'+v:''+v; }
function esc(s){ return String(s==null?'':s).replace(/[&<>"']/g,function(c){return{'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c];}); }
function price(v){
  if(v===0) return '免费';
  if(v>=1){ var n=Math.round(v*100)/100; if(Math.abs(n-Math.round(n))<0.001) return Math.round(n)+' gp'; return n.toFixed(1)+' gp'; }
  if(v>=0.1) return Math.round(v*10)+' sp';
  return Math.round(v*100)+' cp';
}
function gold(v){
  if(Math.abs(v)<0.001) return '0 gp';
  var s=v<0?'-':''; v=Math.abs(v);
  var g=Math.floor(v), r=v-g, sp=Math.floor(r*10+0.0001), cp=Math.round((r*100)-sp*10);
  var a=[]; if(g>0)a.push(g+' gp'); if(sp>0)a.push(sp+' sp'); if(cp>0&&a.length<2)a.push(cp+' cp');
  if(a.length===0)a.push('0 gp');
  return s+a.join(' ');
}
function uid(){ return 'c_'+Date.now().toString(36)+Math.random().toString(36).substr(2,6); }
function rollDice(expr){
  var m = String(expr).match(/^(\d+)d(\d+)([+-]\d+)?$/i);
  if(!m) return 0;
  var n=parseInt(m[1]), d=parseInt(m[2]), b=m[3]?parseInt(m[3]):0;
  var total=0;
  for(var i=0;i<n;i++) total += Math.floor(Math.random()*d)+1;
  return total + b;
}
function findGearItem(k){
  for(var g in GEAR){ if(GEAR[g].it[k]) return {group:g, def:GEAR[g].it[k]}; }
  return null;
}
function genRoomCode(){
  var chars = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789';
  var out = '';
  for(var i=0;i<6;i++) out += chars[Math.floor(Math.random()*chars.length)];
  return out;
}
function showPage(id){
  qa('.page').forEach(function(p){ p.classList.remove('on'); });
  var el=$(id); if(el) el.classList.add('on');
  window.scrollTo(0,0);
}
function dlg(t,x,btns,raw){
  $('dgT').textContent=t;
  if(raw) $('dgX').innerHTML=x;
  else $('dgX').innerHTML=x.replace(/\n/g,'<br>');
  var a=$('dgA'); a.innerHTML='';
  (btns||[]).forEach(function(b){
    var btn=document.createElement('button');
    btn.className='dgb '+(b.c||'');
    btn.textContent=b.l;
    btn.onclick=function(){ closeDlg(); if(b.f) b.f(); };
    a.appendChild(btn);
  });
  $('dbd').classList.add('on');
}
function closeDlg(){ $('dbd').classList.remove('on'); }

// ==================== 存档 ====================
function loadAll(){ try{ var r=localStorage.getItem(KEY); if(!r)return[]; var a=JSON.parse(r); return Array.isArray(a)?a:[]; }catch(e){ return []; } }
function saveAll(){ try{ localStorage.setItem(KEY, JSON.stringify(CHARS)); }catch(e){} }
function norm(c){
  if(!c) return null;
  if(!Array.isArray(c.skills)) c.skills=[];
  if(!Array.isArray(c.bgSkills)) c.bgSkills=[];
  if(!Array.isArray(c.cantrips)) c.cantrips=[];
  if(!Array.isArray(c.spells1)) c.spells1=[];
  if(!c.gear || typeof c.gear!=='object') c.gear={};
  if(!c.id) c.id=uid();
  if(!c.base) c.base={str:8,dex:8,con:8,int:8,wis:8,cha:8};
  if(!c.assign) c.assign={str:0,dex:1,con:2,int:3,wis:4,cha:5};
  if(!c.pool) c.pool=SA.slice();
  if(!c.bgAlloc) c.bgAlloc={plus2:'',plus1:'',plus1a:'',plus1b:'',plus1c:''};
  if(typeof c.weapon!=='string') c.weapon='';
  if(typeof c.offhand!=='string') c.offhand='';
  if(typeof c.armor!=='string') c.armor='none';
  if(typeof c.shield!=='number') c.shield=0;
  if(typeof c.level!=='number') c.level=1;
  if(typeof c.mode!=='string') c.mode='pointbuy';
  if(typeof c.bgAllocMode!=='string') c.bgAllocMode='2_1';
  if(typeof c.feat!=='string') c.feat='';
  if(typeof c.species!=='string') c.species='';
  if(typeof c.cls!=='string') c.cls='';
  if(typeof c.bg!=='string') c.bg='';
  if(typeof c.name!=='string') c.name='';
  if(typeof c.player!=='string') c.player='';
  if(c.game){
    var g=c.game;
    if(!g.currency) g.currency={pp:0,gp:(typeof g.gold==='number'?g.gold:0),ep:0,sp:0,cp:0};
    if(typeof g.inspiration==='number') g.inspiration = g.inspiration>0;
    if(typeof g.inspiration!=='boolean') g.inspiration=false;
    if(!g.ammo || typeof g.ammo!=='object') g.ammo={};
    if(!g.resources || typeof g.resources!=='object') g.resources={};
    if(!g.consumables || typeof g.consumables!=='object') g.consumables={};
    if(!Array.isArray(g.inventory)) g.inventory=[];
    if(typeof g.notes!=='string') g.notes='';
    if(!Array.isArray(g.hpLevelGains)) g.hpLevelGains=[];
    if(!Array.isArray(g.levelUpHistory)) g.levelUpHistory=[];
    if(!Array.isArray(g.advancementFeats)) g.advancementFeats=[];
    if(!g.masteries || typeof g.masteries!=='object') g.masteries={};
    if(!g.hitDice) g.hitDice={total:Number(c.level)||1, used:0, die:(CLASSES[c.cls]||{hd:8}).hd};
    if(typeof g.hitDice.die!=='number') g.hitDice.die=(CLASSES[c.cls]||{hd:8}).hd;
    g.version=2;
  }
  return c;
}
function saveCur(){
  if(!S||!S.id) return;
  S.updatedAt=Date.now();
  var found=false;
  for(var i=0;i<CHARS.length;i++){
    if(CHARS[i].id===S.id){ CHARS[i]=JSON.parse(JSON.stringify(S)); found=true; break; }
  }
  if(!found) CHARS.push(JSON.parse(JSON.stringify(S)));
  saveAll();
}
function newCharData(){
  return norm({
    id:uid(), createdAt:Date.now(), updatedAt:Date.now(),
    name:'', player:'', level:1, species:'', cls:'', bg:'',
    bgAllocMode:'2_1', bgAlloc:{plus2:'',plus1:'',plus1a:'',plus1b:'',plus1c:''},
    feat:'', mode:'pointbuy', base:{str:8,dex:8,con:8,int:8,wis:8,cha:8},
    pool:SA.slice(), assign:{str:0,dex:1,con:2,int:3,wis:4,cha:5},
    skills:[], bgSkills:[], cantrips:[], spells1:[],
    armor:'none', shield:0, weapon:'', offhand:'', gear:{}, game:null
  });
}

// ==================== 角色计算 ====================
function base(ab){
  if(S.mode==='pointbuy'||S.mode==='manual') return S.base[ab];
  var i=S.assign[ab];
  return (i==null||S.pool[i]==null)?10:S.pool[i];
}
function bgB(ab){
  if(!BACKGROUNDS[S.bg]) return 0;
  if(S.bgAllocMode==='2_1'){
    var v=0;
    if(S.bgAlloc.plus2===ab) v+=2;
    if(S.bgAlloc.plus1===ab && S.bgAlloc.plus2!==ab) v+=1;
    return v;
  }
  var a=[S.bgAlloc.plus1a, S.bgAlloc.plus1b, S.bgAlloc.plus1c];
  return a.indexOf(ab)>=0?1:0;
}
function total(ab){ return Math.min(20, base(ab) + bgB(ab)); }
function modOf(ab){ return mod(total(ab)); }
function pb(){ return 2 + Math.floor((Number(S.level)-1)/4); }
function pointsUsed(){ var s=0; AB.forEach(function(a){ s += (PBC[S.base[a.k]]||0); }); return s; }
function calcHP(){
  var c=CLASSES[S.cls]; if(!c) return 10;
  var lv=Number(S.level)||1, co=modOf('con'), d=c.hd;
  var hp=d+co;
  // V18: 升级向导记录每一级“不含 CON”的生命值骰/固定值，避免掷骰升级被旧公式覆盖。
  var gains=(S.game&&Array.isArray(S.game.hpLevelGains))?S.game.hpLevelGains:null;
  if(gains && gains.length){
    for(var gl=2;gl<=lv;gl++){
      var raw=(typeof gains[gl-2]==='number')?gains[gl-2]:(Math.floor(d/2)+1);
      hp += Math.max(1, raw+co);
    }
  } else {
    var pl=Math.max(1, Math.floor(d/2)+1+co);
    hp += (lv-1)*pl;
  }
  if(S.feat==='tough') hp += 2*lv;
  return Math.max(1, hp);
}
function calcAC(){
  var a=ARMORS[S.armor]||ARMORS.none;
  var dx=modOf('dex');
  var ud=Math.min(dx, a.c);
  return a.b + ud + (S.shield ? 2 : 0);
}
function skillB(k){ var s=SKM[k]; if(!s) return 0; return modOf(s.a) + (S.skills.indexOf(k)>=0 ? pb() : 0); }
function clsSkillN(){ var n=0; S.skills.forEach(function(k){ if(S.bgSkills.indexOf(k)<0) n++; }); return n; }
function allowedByCls(k){ var c=CLASSES[S.cls]; if(!c) return true; if(c.any) return true; return c.sk.indexOf(k)>=0; }
function is2h(w){ return w && w.pr.indexOf('双手')>=0; }
function isFin(w){ return w && w.pr.indexOf('灵巧')>=0; }
function isRange(w){ return w && w.pr.indexOf('弹药')>=0; }
function wDmgM(k){
  var w=WEAPONS[k]; if(!w) return 0;
  if(isRange(w)) return modOf('dex');
  if(isFin(w)) return Math.max(modOf('str'), modOf('dex'));
  return modOf('str');
}
function wDmg(k){
  var w=WEAPONS[k]; if(!w) return '';
  var m=wDmgM(k);
  if(m===0) return w.d+' '+w.dt;
  return w.d+' '+fmt(m)+' '+w.dt;
}
function wAtk(k){
  var w=WEAPONS[k]; if(!w) return 0;
  if(isRange(w)) return modOf('dex')+pb();
  if(isFin(w)) return Math.max(modOf('str'), modOf('dex'))+pb();
  return modOf('str')+pb();
}
function startG(){ var c=CLASSES[S.cls]; return c?(c.gold||0):0; }
function spent(){
  var t=0;
  if(S.armor && ARMORS[S.armor]) t += ARMORS[S.armor].p||0;
  if(S.shield) t += 10;
  if(S.weapon && WEAPONS[S.weapon]) t += WEAPONS[S.weapon].p||0;
  if(S.offhand && WEAPONS[S.offhand]) t += WEAPONS[S.offhand].p||0;
  for(var gk in S.gear){
    var c=S.gear[gk]||0;
    if(c>0){
      var f=findGearItem(gk);
      if(f) t += (f.def.p||0) * c;
    }
  }
  return t;
}
function remainG(){ return startG() - spent(); }

// ==================== 主页 ====================
function renderHome(){
  var list=$('charList'); if(!list) return;
  if(CHARS.length===0){
    list.innerHTML='<div class="eh">还没有角色<br>点击上方按钮创建</div>';
    return;
  }
  var sorted = CHARS.slice().sort(function(a,b){ return (b.updatedAt||0)-(a.updatedAt||0); });
  var h='';
  sorted.forEach(function(c){
    var cn = c.cls && CLASSES[c.cls] ? CLASSES[c.cls].n : '';
    var sp = c.species && SPECIES[c.species] ? SPECIES[c.species].n : '';
    var bg = c.bg && BACKGROUNDS[c.bg] ? BACKGROUNDS[c.bg].n : '';
    var meta = [sp, cn, '等级 '+(c.level||1), bg].filter(Boolean).join(' · ');
    var init = (c.name||'?').trim().charAt(0)||'?';
    var hpInfo;
    if(c.game){
      var pct = c.game.maxHP>0 ? c.game.currentHP/c.game.maxHP : 0;
      var hc = pct<=0.25?'c':(pct<=0.5?'w':'');
      var w = Math.max(0, Math.min(100, pct*100));
      hpInfo = '<div class="chr"><div class="chb"><i class="'+hc+'" style="width:'+w+'%"></i></div><span class="cht">'+c.game.currentHP+'/'+c.game.maxHP+'</span></div>';
    } else {
      hpInfo = '<div class="chr"><span class="cht" style="color:#5b5245">未开始冒险</span></div>';
    }
    h += '<div class="cc" onclick="openTrk(\''+c.id+'\')">'
      +'<div class="ca">'+esc(init)+'</div>'
      +'<div class="ci"><div class="cn">'+esc(c.name||'无名冒险者')+'</div>'
      +'<div class="cm">'+esc(meta)+'</div>'+hpInfo+'</div>'
      +'<div class="cac" onclick="event.stopPropagation()">'
      +'<button class="cab e" onclick="editChar(\''+c.id+'\')">✎</button>'
      +'<button class="cab d" onclick="delChar(\''+c.id+'\')">✕</button>'
      +'</div></div>';
  });
  list.innerHTML=h;
}

window.startNewChar = function(){
  try { S=newCharData(); curStep=1; showPage('pgWiz'); showStep(1); }
  catch(e){ alert('出错：'+e.message); }
};
window.editChar = function(id){
  var c=null;
  for(var i=0;i<CHARS.length;i++) if(CHARS[i].id===id) c=CHARS[i];
  if(!c) return;
  S=norm(JSON.parse(JSON.stringify(c)));
  curStep=1; showPage('pgWiz'); showStep(1);
};
window.delChar = function(id){
  var c=null;
  for(var i=0;i<CHARS.length;i++) if(CHARS[i].id===id) c=CHARS[i];
  if(!c) return;
  dlg('删除角色','确定删除「'+(c.name||'无名冒险者')+'」？',[
    {l:'取消'},
    {l:'删除', c:'d', f:function(){
      CHARS = CHARS.filter(function(x){ return x.id!==id; });
      saveAll(); renderHome();
    }}
  ]);
};
window.exitWiz = function(){
  dlg('返回主页','未保存的修改会丢失。',[
    {l:'继续编辑'},
    {l:'返回主页', c:'p', f:function(){ S=null; renderHome(); showPage('pgHome'); }}
  ]);
};

// ==================== 创建向导 ====================
function showStep(n){
  if(n<1) n=1;
  if(n>TSTEPS) n=TSTEPS;
  curStep=n;
  if(S) S.step=n;
  qa('#pgWiz .step').forEach(function(s){ s.classList.remove('on'); });
  var el=$('wz'+n); if(el) el.classList.add('on');
  $('progBar').style.width = (n/TSTEPS)*100+'%';
  $('progText').textContent = n+'/'+TSTEPS;
  $('btnPrev').disabled = (n===1);
  $('btnNext').textContent = (n===TSTEPS)?'保存并回到主页':'下一步';
  try {
    if(n===1) rStep1();
    else if(n===2) rStep2();
    else if(n===3) rStep3();
    else if(n===4) rStep4();
    else if(n===5) rStep5();
    else if(n===6) rStep6();
    else if(n===7) rStep7();
    else if(n===8) rStep8();
    else if(n===9) rStep9();
    else if(n===10) rStep10();
    else if(n===11) rStep11();
  } catch(e){ console.error('步骤渲染错误', e); }
  window.scrollTo(0,0);
}
window.goPrev = function(){ showStep(curStep-1); };
window.goNext = function(){
  if(!S){ alert('状态丢失'); return; }
  // 基本信息页的输入框必须先写回角色状态，再切换步骤。
  // 旧版只定义了 onName/onPlayer，却没有把它们绑定到 input，导致输入的名字从未进入 S。
  if(curStep===1){
    var nameEl=$('inpName'), playerEl=$('inpPlayer');
    if(nameEl) S.name=(nameEl.value||'').trim();
    if(playerEl) S.player=(playerEl.value||'').trim();
  }
  if(curStep<TSTEPS){ showStep(curStep+1); return; }
  if(!S.name) S.name='无名冒险者';
  if(!S.cls){ alert('请先选择职业'); showStep(3); return; }
  if(!S.game) initGame(); else syncGame();
  saveCur();
  S=null;
  renderHome();
  showPage('pgHome');
};
window.lvlDown = function(){ if(S && S.level>1){ S.level--; $('lvlVal').textContent=S.level; } };
window.lvlUp = function(){ if(S && S.level<20){ S.level++; $('lvlVal').textContent=S.level; } };

function rStep1(){ $('inpName').value=S.name; $('inpPlayer').value=S.player; $('lvlVal').textContent=S.level; }
function rStep2(){
  var h='';
  for(var k in SPECIES){
    var v=SPECIES[k], sel=S.species===k;
    var m=['速度 '+v.sp+' 尺']; if(v.dv) m.push('黑暗视觉 '+v.dv+' 尺');
    h += '<div class="oc'+(sel?' sel':'')+'" onclick="pickSpecies(\''+k+'\')"><span class="ck"></span><span class="ob"><span class="on2">'+v.n+'</span><span class="om">'+m.join(' · ')+'</span></span></div>';
  }
  $('speciesList').innerHTML=h;
}
function rStep3(){
  var h='';
  for(var k in CLASSES){
    var v=CLASSES[k], sel=S.cls===k;
    var sv = v.sv.map(function(s){ return ABM[s].n; }).join('、');
    var sk = v.any?'任意':v.sc+' 项';
    var tag = SPELLCASTER[k]?'<span class="tg p">施法者</span>':'';
    h += '<div class="oc'+(sel?' sel':'')+'" onclick="pickClass(\''+k+'\')"><span class="ck"></span><span class="ob"><span class="on2">'+v.n+'</span><span class="om"><span class="tg">生命骰 d'+v.hd+'</span><span class="tg">豁免 '+sv+'</span><span class="tg b">技能 '+sk+'</span><span class="tg g">起始 '+v.gold+' gp</span>'+tag+'</span></span></div>';
  }
  $('classList').innerHTML=h;
}
function rStep4(){
  var h='';
  for(var k in BACKGROUNDS){
    var v=BACKGROUNDS[k], sel=S.bg===k;
    var ab = v.ab.map(function(a){ return ABM[a].n; }).join('/');
    var f = FEATS[v.f];
    h += '<div class="oc'+(sel?' sel':'')+'" onclick="pickBg(\''+k+'\')"><span class="ck"></span><span class="ob"><span class="on2">'+v.n+'</span><span class="om"><span class="tg b">属性 '+ab+'</span><span class="tg">'+f.n+'</span><br>技能：'+v.sk.map(function(s){ return SKM[s].n; }).join('、')+'</span></span></div>';
  }
  $('bgList').innerHTML=h;
}
function rStep5(){
  var box=$('bgAllocBox');
  var bg=BACKGROUNDS[S.bg];
  if(!bg){ box.innerHTML='<div style="text-align:center;color:#9a8f7d;font-size:13px;padding:20px">请先在上一步选择背景</div>'; return; }
  var h='<div class="bgat">分配「'+bg.n+'」的属性加值 · 提供：'+bg.ab.map(function(a){ return ABM[a].n; }).join('、')+'</div>'
    +'<div class="amr">'
    +'<button class="amb'+(S.bgAllocMode==='2_1'?' on':'')+'" onclick="setBAMode(\'2_1\')">一项 +2 / 另一项 +1</button>'
    +'<button class="amb'+(S.bgAllocMode==='1_1_1'?' on':'')+'" onclick="setBAMode(\'1_1_1\')">三项各 +1</button>'
    +'</div><div class="asl">';
  function opts(cur, others){
    var o='';
    bg.ab.forEach(function(k){
      var dis = (others.indexOf(k)>=0) && cur!==k;
      o += '<option value="'+k+'"'+(cur===k?' selected':'')+(dis?' disabled':'')+'>'+ABM[k].n+'</option>';
    });
    return o;
  }
  if(S.bgAllocMode==='2_1'){
    h += '<div class="ar2"><span class="abn">+2</span><select onchange="setBA(\'plus2\',this.value)"><option value="">选择属性</option>'+opts(S.bgAlloc.plus2,[S.bgAlloc.plus1])+'</select></div>'
      +'<div class="ar2"><span class="abn">+1</span><select onchange="setBA(\'plus1\',this.value)"><option value="">选择属性</option>'+opts(S.bgAlloc.plus1,[S.bgAlloc.plus2])+'</select></div>';
  } else {
    ['plus1a','plus1b','plus1c'].forEach(function(key){
      var others = ['plus1a','plus1b','plus1c'].filter(function(k2){ return k2!==key; }).map(function(k2){ return S.bgAlloc[k2]; });
      h += '<div class="ar2"><span class="abn">+1</span><select onchange="setBA(\''+key+'\',this.value)"><option value="">选择属性</option>'+opts(S.bgAlloc[key],others)+'</select></div>';
    });
  }
  h += '</div>';
  box.innerHTML=h;
}
function rStep6(){
  var bg=BACKGROUNDS[S.bg];
  var h='';
  if(!bg){ h='<div style="text-align:center;color:#9a8f7d;font-size:13px;padding:20px">请先选择背景</div>'; }
  else {
    var rec=bg.f;
    for(var kk in FEATS){
      var f=FEATS[kk], on=S.feat===kk, isRec=kk===rec;
      h += '<div class="fi'+(on?' on':'')+'" onclick="pickFeat(\''+kk+'\')"><span class="ck"></span><span class="fb"><div class="fnm">'+f.n+(isRec?'<span class="frec">推荐</span>':'')+'</div><div class="fd">'+f.d+'</div></span></div>';
    }
  }
  $('featList').innerHTML=h;
}
function abCard(a){
  var b=base(a.k), bg=bgB(a.k);
  var t=Math.min(20, b+bg);
  var m=mod(t);
  var ctrl='';
  if(S.mode==='pointbuy'){
    var canI = b<15 && (pointsUsed()-PBC[b]+(PBC[b+1]||0)<=PBT);
    var canD = b>8;
    ctrl = '<div class="stp" style="padding:6px"><button class="sb" '+(canD?'':'disabled')+' onclick="incAb(\''+a.k+'\',-1)">−</button><span class="val">'+b+'</span><button class="sb" '+(canI?'':'disabled')+' onclick="incAb(\''+a.k+'\',1)">+</button></div>';
  } else if(S.mode==='manual'){
    ctrl = '<input class="ni" type="number" inputmode="numeric" value="'+b+'" min="3" max="20" onchange="manualSet(\''+a.k+'\',this.value)">';
  } else {
    var cur=S.assign[a.k];
    ctrl='<div class="vb">';
    S.pool.forEach(function(v,i){
      var own=null;
      AB.forEach(function(o){ if(o.k!==a.k && S.assign[o.k]===i) own=o; });
      var cl='';
      if(cur===i) cl+=' sel';
      if(own) cl+=' tk';
      ctrl += '<button class="'+cl+'" onclick="setAssign(\''+a.k+'\','+i+')">'+v+'</button>';
    });
    ctrl += '</div>';
  }
  var bgt = bg?'<span style="font-size:11px;color:#6d6252;margin-left:4px">背景 +'+bg+'</span>':'';
  var capped = (b+bg)>20 ? '<span style="font-size:11px;color:#e05252;margin-left:4px">已封顶 20</span>' : '';
  return '<div class="ac"><div class="at"><span class="al">'+a.n+'<em>'+a.e+'</em>'+bgt+capped+'</span><span class="ar"><span class="ato">'+t+'</span><span class="am">'+fmt(m)+'</span></span></div>'+ctrl+'</div>';
}
function rStep7(){
  var modes=[{k:'pointbuy',n:'点数购买'},{k:'standard',n:'标准数组'},{k:'roll',n:'随机骰点'},{k:'manual',n:'手动输入'}];
  var b='';
  modes.forEach(function(m){ b += '<button class="'+(S.mode===m.k?'on':'')+'" onclick="setMode(\''+m.k+'\')">'+m.n+'</button>'; });
  $('modeBar').innerHTML=b;
  var info=$('modeInfo');
  if(S.mode==='pointbuy'){
    var u=pointsUsed(); var l=PBT-u;
    info.innerHTML = '27 点购买池 · 已用 <b>'+u+'</b> · 剩余 <b>'+l+'</b><br><span style="font-size:12px;color:#6d6252">8~13 每点 1 分 · 14~15 每点 2 分</span>';
  } else if(S.mode==='standard'||S.mode==='roll'){
    var ui={};
    for(var k in S.assign) ui[S.assign[k]]=1;
    var chips = S.pool.map(function(v,i){ return '<span class="pc'+(ui[i]?' u':'')+'">'+v+'</span>'; }).join('');
    info.innerHTML = (S.mode==='standard'?'标准数组':'4d6 去最低')+'：<div style="margin-top:8px">'+chips+'</div>';
    if(S.mode==='roll') info.innerHTML += '<button style="margin-top:10px;padding:8px 16px;border-radius:20px;border:1.5px solid #c9a227;background:linear-gradient(180deg,#3a2f1c,#2b2314);color:#e8c95a;font-size:13px" onclick="doRoll();rStep7()">重新骰点</button>';
  } else {
    info.innerHTML = '手动输入：数值范围 <b>3 ~ 20</b>，背景加值会额外叠加（总上限 20）。';
  }
  var h='';
  AB.forEach(function(a){ h += abCard(a); });
  $('abList').innerHTML=h;
}
function rStep8(){
  var cls=CLASSES[S.cls], bg=BACKGROUNDS[S.bg];
  var need=cls?cls.sc:0;
  var bgN=S.bgSkills.length;
  var clsN=clsSkillN();
  var hh='';
  if(!cls && !bg){
    hh='<div class="shr"><span class="shl">请先选择职业与背景</span></div>';
  } else {
    if(bg) hh += '<div class="shr"><span class="shl">背景「'+bg.n+'」技能</span><span class="shv">'+bgN+' 项</span></div>';
    if(cls){
      var ok=clsN>=need?'ok':'';
      hh += '<div class="shr"><span class="shl">职业「'+cls.n+'」可选</span><span class="shv '+ok+'">'+clsN+' / '+need+'</span></div>';
      var pct = need>0?Math.min(100,clsN/need*100):0;
      hh += '<div class="skb"><i style="width:'+pct+'%"></i></div>';
    }
  }
  $('skillHeader').innerHTML=hh;
  var h='';
  SKILLS.forEach(function(s){
    var isBg = S.bgSkills.indexOf(s.k)>=0;
    var isCls = S.skills.indexOf(s.k)>=0 && !isBg;
    var isAll = allowedByCls(s.k);
    var isFull = cls && clsN>=need && !isCls;
    var dis = !isBg && (!isAll || isFull);
    var cl='si';
    if(isBg) cl+=' lk'; else if(isCls) cl+=' on';
    if(dis) cl+=' ds';
    var bo=skillB(s.k);
    var tag='';
    if(isBg) tag='<span class="stg bg">背景</span>';
    else if(isCls) tag='<span class="stg cl">职业</span>';
    h += '<div class="'+cl+'" onclick="togSkill(\''+s.k+'\')">'+tag+'<span class="ck"></span><span class="snm">'+s.n+'</span><span class="sab">'+ABM[s.a].e+'</span><span class="sbo">'+fmt(bo)+'</span></div>';
  });
  $('skillList').innerHTML=h;
  var hint='';
  if(cls){
    if(clsN===need) hint='✓ 已完成职业技能选择。';
    else hint='还需选择 <b>'+(need-clsN)+'</b> 项。';
  } else hint='选择职业后可筛选可选技能。';
  $('skillHintRow').innerHTML=hint;
}
function rStep9(){
  var sc=SPELLCASTER[S.cls];
  var desc=$('spellDesc'), box=$('spellContent');
  if(!S.cls){
    desc.textContent='请先在上一步选择职业。';
    box.innerHTML='<div style="text-align:center;color:#9a8f7d;font-size:13px;padding:20px">尚未选择职业</div>';
    return;
  }
  if(!sc){
    desc.textContent='你的职业不是施法者，可以跳过这一步。';
    box.innerHTML='<div style="text-align:center;padding:24px;background:rgba(90,143,191,.06);border:1.5px dashed rgba(90,143,191,.4);border-radius:14px"><div style="font-size:15px;color:#7fb0e0;font-weight:600;margin-bottom:6px">'+CLASSES[S.cls].n+' 不是施法者</div><div style="font-size:12.5px;color:#9a8f7d">直接点击「下一步」继续即可。</div></div>';
    return;
  }
  var slots = getSlots(S.cls, S.level);
  if(slots.length === 0){
    desc.textContent = CLASSES[S.cls].n+' 在等级 '+S.level+' 时还没有法术位。';
    box.innerHTML = '<div style="text-align:center;padding:24px;background:rgba(90,143,191,.06);border:1.5px dashed rgba(90,143,191,.4);border-radius:14px"><div style="font-size:15px;color:#7fb0e0;font-weight:600;margin-bottom:6px">尚未获得法术位</div><div style="font-size:12.5px;color:#9a8f7d">'+CLASSES[S.cls].n+' 在等级 2 时获得法术位，直接点击「下一步」继续即可。</div></div>';
    return;
  }
  desc.textContent='从'+CLASSES[S.cls].n+'的法术列表中选择戏法和一环法术。施法属性：'+ABM[sc.ab].n+'。';
  var sum = '<div class="sh" style="margin-bottom:14px">施法属性：<b style="color:#c9a6e0">'+ABM[sc.ab].n+'</b>　豁免 DC：<b style="color:#c9a6e0">'+(8+pb()+modOf(sc.ab))+'</b><br>法术攻击加值：<b style="color:#c9a6e0">'+fmt(pb()+modOf(sc.ab))+'</b></div>';
  var h=sum;
  if(sc.ct>0){
    var cnt=S.cantrips.length;
    var cls2=cnt>=sc.ct?'ok':'';
    h += '<div class="spell-cat"><div class="spell-cat-t">戏法 <span class="spell-cat-c '+cls2+'">'+cnt+' / '+sc.ct+'</span></div><div class="spell-list">';
    CANTRIPS.forEach(function(sp){
      if(sp.cl.indexOf(S.cls)<0) return;
      var on = S.cantrips.indexOf(sp.k)>=0;
      var full = cnt>=sc.ct && !on;
      h += '<div class="spell-item'+(on?' on':'')+(full?' ds':'')+'" onclick="togCantrip(\''+sp.k+'\')"><span class="ck"></span><span class="spell-body"><div class="spell-nm">'+sp.n+'</div><div class="spell-dc">'+sp.t+' · '+sp.r+' · '+sp.c+(sp.cn?' · <span style="color:#e05252">专注</span>':'')+'<br>'+sp.d+'</div></span></div>';
    });
    h += '</div></div>';
  }
  if(sc.sp>0){
    var cnt1=S.spells1.length;
    var cls4=cnt1>=sc.sp?'ok':'';
    h += '<div class="spell-cat"><div class="spell-cat-t">一环法术 <span class="spell-cat-c '+cls4+'">'+cnt1+' / '+sc.sp+'</span></div><div class="spell-list">';
    LEVEL1_SPELLS.forEach(function(sp){
      if(sp.cl.indexOf(S.cls)<0) return;
      var on = S.spells1.indexOf(sp.k)>=0;
      var full = cnt1>=sc.sp && !on;
      h += '<div class="spell-item'+(on?' on':'')+(full?' ds':'')+'" onclick="togSpell1(\''+sp.k+'\')"><span class="ck"></span><span class="spell-body"><div class="spell-nm">'+sp.n+'</div><div class="spell-dc">'+sp.t+' · '+sp.r+' · '+sp.c+(sp.cn?' · <span style="color:#e05252">专注</span>':'')+'<br>'+sp.d+'</div></span></div>';
    });
    h += '</div></div>';
  }
  box.innerHTML=h;
}
function rStep10(){
  var s=startG(), sp=spent(), rm=s-sp;
  var pct = s>0?Math.min(100,sp/s*100):0;
  var wh = '<div class="wr"><span class="wl">起始金币</span><span class="wv">'+(s?gold(s):'—')+'</span></div>'
    +'<div class="wr"><span class="wl">已花费</span><span class="wv" style="font-size:16px;color:#9a8f7d">'+gold(sp)+'</span></div>'
    +'<div class="wba"><i class="'+(rm<0?'ov':'')+'" style="width:'+pct+'%"></i></div>'
    +'<div class="wr" style="margin-top:6px;margin-bottom:0"><span class="wl">剩余可用</span><span class="wv r'+(rm<0?' n':'')+'">'+gold(rm)+'</span></div>';
  $('walletBox').innerHTML=wh;
  var selA=$('selArmor');
  if(!selA.options.length){
    var hA='';
    for(var k in ARMORS){
      var v=ARMORS[k], sf;
      if(v.c===Infinity) sf='+敏捷';
      else if(v.c>0) sf='+敏捷上限'+v.c;
      else sf='无敏捷加值';
      hA += '<option value="'+k+'">'+v.n+'（AC '+v.b+' '+sf+'）— '+(v.p?price(v.p):'免费')+'</option>';
    }
    selA.innerHTML=hA;
  }
  selA.value=S.armor;
  $('armorPrice').innerHTML = '价格：<b>'+(ARMORS[S.armor]?(ARMORS[S.armor].p?price(ARMORS[S.armor].p):'免费'):'免费')+'</b>';
  $('selShield').value=String(S.shield);
  var selW=$('selWeapon');
  if(!selW.options.length){
    var hW='<option value="">— 无 —</option>';
    for(var wk in WEAPONS){
      var w=WEAPONS[wk];
      var pp = w.pr.length?'，'+w.pr.join('、'):'';
      hW += '<option value="'+wk+'">'+w.n+'（'+w.d+' '+w.dt+pp+'）— '+price(w.p)+'</option>';
    }
    selW.innerHTML=hW;
  }
  selW.value=S.weapon||'';
  var selO=$('selOffhand');
  if(!selO.options.length) selO.innerHTML=selW.innerHTML;
  selO.value=S.offhand||'';
  selO.disabled=is2h(WEAPONS[S.weapon]);
  var gh='';
  for(var gk in GEAR){
    var g=GEAR[gk];
    gh += '<div class="eb"><div class="ebt">'+g.n+'</div><div class="gl">';
    for(var ik in g.it){
      var it=g.it[ik];
      var qty=S.gear[ik]||0;
      var can = remainG()-it.p >= -0.001;
      gh += '<div class="gr'+(qty>0?' on':'')+'"><div class="gi"><div class="gn">'+it.n+'</div><div class="gp">'+price(it.p)+'</div></div><div class="gq"><button class="gqb" '+(qty<=0?'disabled':'')+' onclick="gearDec(\''+ik+'\')">−</button><span class="gqn'+(qty===0?' z':'')+'">'+qty+'</span><button class="gqb" '+(can?'':'disabled')+' onclick="gearInc(\''+ik+'\')">+</button></div></div>';
    }
    gh += '</div></div>';
  }
  $('gearList').innerHTML=gh;
}
function rStep11(){
  var cls=CLASSES[S.cls], spc=SPECIES[S.species], bg=BACKGROUNDS[S.bg];
  var ft=FEATS[S.feat], sc=SPELLCASTER[S.cls];
  var lv=Number(S.level)||1, p=pb();
  var sub=[];
  if(spc) sub.push(spc.n);
  if(cls) sub.push(cls.n);
  sub.push('等级 '+lv);
  if(bg) sub.push(bg.n);
  var scHtml='';
  AB.forEach(function(a){
    var t=total(a.k);
    scHtml += '<div class="sc"><div class="l">'+a.n+'</div><div class="v">'+t+'</div><div class="m">'+fmt(mod(t))+'</div></div>';
  });
  var hp=calcHP(), ac=calcAC();
  var init = modOf('dex') + (S.feat==='alert'?p:0);
  var pass = 10 + modOf('wis') + (S.skills.indexOf('perception')>=0?p:0);
  var spd = spc?spc.sp:30;
  var stats = '<div class="stt"><span>AC</span><b>'+ac+'</b></div>'
    +'<div class="stt"><span>HP</span><b>'+(hp==null?'—':hp)+'</b></div>'
    +'<div class="stt"><span>先攻</span><b>'+fmt(init)+'</b></div>'
    +'<div class="stt"><span>熟练</span><b>'+fmt(p)+'</b></div>'
    +'<div class="stt"><span>被动察觉</span><b>'+pass+'</b></div>'
    +'<div class="stt"><span>速度</span><b>'+spd+' 尺</b></div>';
  var sv='';
  if(cls){
    AB.forEach(function(a){
      var pr=cls.sv.indexOf(a.k)>=0;
      sv += '<li><span>'+a.n+'豁免'+(pr?' ●':'')+'</span><b>'+fmt(modOf(a.k)+(pr?p:0))+'</b></li>';
    });
  }
  var sl='';
  var chosen = SKILLS.filter(function(s){ return S.skills.indexOf(s.k)>=0; });
  if(chosen.length){
    chosen.forEach(function(s){
      var isBg = S.bgSkills.indexOf(s.k)>=0;
      var tag = isBg?' [背景]':' [职业]';
      sl += '<li><span>'+s.n+'<em style="font-size:10px;color:#6d6252">'+tag+'</em></span><b>'+fmt(skillB(s.k))+'</b></li>';
    });
  } else sl='<li class="ae">尚未选择技能熟练</li>';
  var spellHtml='';
  if(sc){
    spellHtml += '<div style="font-size:12px;color:#9a8f7d;margin-bottom:8px">施法属性 '+ABM[sc.ab].n+'　豁免 DC '+(8+p+modOf(sc.ab))+'　攻击 '+fmt(p+modOf(sc.ab))+'</div>';
  }
  var ftL = ft?'<li><span>起源专长</span><b style="font-size:13px">'+esc(ft.n)+'</b></li>':'';
  var arm=ARMORS[S.armor]||ARMORS.none;
  var armL='<li><span>护甲</span><b>'+arm.n+(S.shield?' + 盾牌':'')+'</b></li>';
  var wL='';
  if(S.weapon && WEAPONS[S.weapon]){
    var w=WEAPONS[S.weapon];
    wL += '<li><span>主手</span><b>'+w.n+'（'+fmt(wAtk(S.weapon))+' | '+wDmg(S.weapon)+'）</b></li>';
  }
  if(S.offhand && WEAPONS[S.offhand]){
    var o=WEAPONS[S.offhand];
    wL += '<li><span>副手</span><b>'+o.n+'（'+fmt(wAtk(S.offhand))+' | '+wDmg(S.offhand)+'）</b></li>';
  }
  if(!wL) wL='<li class="ae">尚未购买武器</li>';
  var gE=[];
  for(var gk in GEAR){
    for(var ik in GEAR[gk].it){
      var qty=S.gear[ik]||0;
      if(qty>0) gE.push(GEAR[gk].it[ik].n+' ×'+qty);
    }
  }
  var gT='';
  if(gE.length){ gT='<ul class="shl2">'; gE.forEach(function(x){ gT += '<li><span>'+x+'</span></li>'; }); gT += '</ul>'; }
  var spLine='';
  if(cls){
    spLine = '<ul class="shl2"><li><span>起始金币</span><b>'+gold(startG())+'</b></li><li><span>已花费</span><b>'+gold(spent())+'</b></li><li><span>剩余（带入追踪）</span><b style="color:#7fc98a">'+gold(remainG())+'</b></li></ul>';
  }
  $('sheet').innerHTML =
    '<div class="shn">'+(esc(S.name)||'无名冒险者')+'</div>'
    +'<div class="shs">'+sub.join(' · ')+'</div>'
    +(S.player?'<div class="shs">玩家：'+esc(S.player)+'</div>':'')
    +'<div class="hr"></div><div class="sg">'+scHtml+'</div>'
    +'<div class="hr"></div><p class="sec">核心数值</p><div class="stg2">'+stats+'</div>'
    +(ft?'<div class="hr"></div><p class="sec">起源专长</p><ul class="shl2">'+ftL+'</ul>':'')
    +(cls?'<div class="hr"></div><p class="sec">豁免检定</p><ul class="shl2">'+sv+'</ul>':'')
    +'<div class="hr"></div><p class="sec">技能熟练</p><ul class="shl2">'+sl+'</ul>'
    +'<div class="hr"></div><p class="sec">护甲</p><ul class="shl2">'+armL+'</ul>'
    +'<div class="hr"></div><p class="sec">武器</p><ul class="shl2">'+wL+'</ul>'
    +(gT?'<div class="hr"></div><p class="sec">冒险道具</p>'+gT:'')
    +(spLine?'<div class="hr"></div><p class="sec">财富</p>'+spLine:'');
}

// 创建向导回调
window.onName = function(v){ if(S) S.name=v; };
window.onPlayer = function(v){ if(S) S.player=v; };
window.pickSpecies = function(k){ if(S){ S.species=k; rStep2(); } };
window.pickClass = function(k){
  if(!S) return;
  S.cls=k;
  var cls=CLASSES[k];
  if(cls){
    var rm=[];
    for(var i=0;i<S.skills.length;i++){
      var sk=S.skills[i];
      if(S.bgSkills.indexOf(sk)>=0) continue;
      if(!cls.any && cls.sk.indexOf(sk)<0) rm.push(i);
    }
    for(var r=rm.length-1;r>=0;r--) S.skills.splice(rm[r],1);
    while(clsSkillN()>cls.sc){
      for(var j=S.skills.length-1;j>=0;j--){
        if(S.bgSkills.indexOf(S.skills[j])<0){ S.skills.splice(j,1); break; }
      }
    }
  }
  S.cantrips=[]; S.spells1=[];
  rStep3();
};
window.pickBg = function(k){
  if(!S) return;
  if(k===S.bg){ rStep4(); return; }
  for(var i=S.bgSkills.length-1;i>=0;i--){
    var idx=S.skills.indexOf(S.bgSkills[i]);
    if(idx>=0) S.skills.splice(idx,1);
  }
  S.bgSkills=[];
  S.bg=k;
  var nb=BACKGROUNDS[k];
  if(nb){
    nb.sk.forEach(function(sk){ if(S.skills.indexOf(sk)<0) S.skills.push(sk); S.bgSkills.push(sk); });
  }
  S.bgAlloc={plus2:'',plus1:'',plus1a:'',plus1b:'',plus1c:''};
  S.bgAllocMode='2_1';
  S.feat=nb?nb.f:'';
  rStep4();
};
window.setBAMode = function(m){ if(S){ S.bgAllocMode=m; S.bgAlloc={plus2:'',plus1:'',plus1a:'',plus1b:'',plus1c:''}; rStep5(); } };
window.setBA = function(slot,v){ if(S){ S.bgAlloc[slot]=v; rStep5(); } };
window.pickFeat = function(k){ if(S){ S.feat=k; rStep6(); } };
window.setMode = function(m){
  if(!S) return;
  if(m===S.mode) return;
  if(m==='roll'){ doRoll(); S.mode='roll'; rStep7(); return; }
  if(m==='standard'){ S.pool=SA.slice(); S.assign={str:0,dex:1,con:2,int:3,wis:4,cha:5}; }
  if(m==='pointbuy') S.base={str:8,dex:8,con:8,int:8,wis:8,cha:8};
  if(m==='manual'){
    var b={};
    AB.forEach(function(a){ b[a.k]=Math.max(3,Math.min(20,total(a.k)-bgB(a.k))); });
    S.base=b;
  }
  S.mode=m;
  rStep7();
};
window.doRoll = function(){
  if(!S) return;
  var r=[];
  for(var i=0;i<6;i++){
    var d=[];
    for(var j=0;j<4;j++) d.push(1+Math.floor(Math.random()*6));
    d.sort(function(a,b){ return b-a; });
    r.push(d[0]+d[1]+d[2]);
  }
  r.sort(function(a,b){ return b-a; });
  S.pool=r;
  S.assign={};
  AB.forEach(function(a,i){ S.assign[a.k]=i; });
};
window.incAb = function(k,d){
  if(!S) return;
  if(d>0){
    var cur=S.base[k], nx=cur+1;
    if(nx>15) return;
    var df=(PBC[nx]||0)-(PBC[cur]||0);
    if(pointsUsed()+df>PBT) return;
    S.base[k]=nx;
  } else {
    if(S.base[k]<=8) return;
    S.base[k]--;
  }
  rStep7();
};
window.manualSet = function(k,v){
  if(!S) return;
  var n=Number(v);
  if(isNaN(n)||n<3) n=3;
  if(n>20) n=20;
  S.base[k]=n;
  rStep7();
};
window.setAssign = function(k,i){
  if(!S) return;
  var old=S.assign[k];
  if(old===i) return;
  var own=null;
  AB.forEach(function(o){ if(o.k!==k && S.assign[o.k]===i) own=o; });
  if(own && old!=null) S.assign[own.k]=old;
  S.assign[k]=i;
  rStep7();
};
window.togSkill = function(k){
  if(!S) return;
  if(S.bgSkills.indexOf(k)>=0) return;
  var c=CLASSES[S.cls];
  if(c && !c.any && c.sk.indexOf(k)<0) return;
  var i=S.skills.indexOf(k);
  if(i>=0) S.skills.splice(i,1);
  else {
    if(c && clsSkillN()>=c.sc) return;
    S.skills.push(k);
  }
  rStep8();
};
window.togCantrip = function(k){
  if(!S) return;
  var sc=SPELLCASTER[S.cls];
  if(!sc) return;
  var i=S.cantrips.indexOf(k);
  if(i>=0) S.cantrips.splice(i,1);
  else { if(S.cantrips.length>=sc.ct) return; S.cantrips.push(k); }
  rStep9();
};
window.togSpell1 = function(k){
  if(!S) return;
  var sc=SPELLCASTER[S.cls];
  if(!sc) return;
  var i=S.spells1.indexOf(k);
  if(i>=0) S.spells1.splice(i,1);
  else { if(S.spells1.length>=sc.sp) return; S.spells1.push(k); }
  rStep9();
};
window.onArmor = function(v){ if(S){ S.armor=v; rStep10(); } };
window.onShield = function(v){ if(S){ S.shield=Number(v); rStep10(); } };
window.onWeapon = function(v){ if(!S) return; S.weapon=v; if(is2h(WEAPONS[v])) S.offhand=''; rStep10(); };
window.onOffhand = function(v){ if(S){ S.offhand=v; rStep10(); } };
window.gearInc = function(k){
  if(!S) return;
  var f=findGearItem(k);
  if(!f) return;
  var pr=f.def.p||0;
  var cur=S.gear[k]||0;
  if(remainG()-pr<-0.001) return;
  S.gear[k]=cur+1;
  rStep10();
};
window.gearDec = function(k){
  if(!S) return;
  var cur=S.gear[k]||0;
  if(cur<=0) return;
  S.gear[k]=cur-1;
  if(S.gear[k]===0) delete S.gear[k];
  rStep10();
};

// ==================== 初始化 game 对象 ====================
function initGame(){
  var hp = calcHP()||10;
  var slots = getSlots(S.cls, S.level);
  var ss=[];
  for(var i=0;i<slots.length;i++) if(slots[i]>0) ss.push({level:i+1, max:slots[i], used:0});
  var resources={};
  var rDefs = CLASS_RESOURCES[S.cls]||[];
  var lvNow = Number(S.level)||1;
  var chaMod = modOf('cha');
  rDefs.forEach(function(r){
    if(lvNow < r.lv) return;
    resources[r.k] = { n:r.n, max:r.max(lvNow, chaMod), used:0, reset:r.reset, d:r.d, pool:!!r.pool, poolUsed:0 };
  });
  var ammo={}, consumables={};
  for(var k in S.gear){
    var cnt=S.gear[k]||0;
    if(cnt<=0) continue;
    var f=findGearItem(k);
    if(!f) continue;
    if(f.group === 'ammo' && f.def.ammoType){
      ammo[f.def.ammoType] = (ammo[f.def.ammoType]||0) + cnt*f.def.ammoQty;
    } else if(f.group === 'consumable'){
      consumables[f.def.n] = cnt;
    }
  }
  [S.weapon, S.offhand].forEach(function(wk){
    var an = getAmmoForWeapon(wk);
    if(an && !ammo[an]) ammo[an]=20;
  });
  var currency = {pp:0, gp:Math.max(0,remainG()), ep:0, sp:0, cp:0};
  var clsHd = (CLASSES[S.cls]||{hd:8}).hd;
  S.game = {
    currentHP:hp, tempHP:0, maxHP:hp,
    hitDice:{total:Number(S.level)||1, used:0, die:clsHd},
    deathSuccess:0, deathFail:0,
    exhaustion:0,
    inspiration:false,
    spellSlots:ss,
    conditions:[],
    concentration:'',
    resources:resources,
    currency:currency,
    ammo:ammo,
    consumables:consumables,
    inventory:[],
    companions:[],
    notes:'',
    castHistory:[],
    hpLevelGains:[],
    levelUpHistory:[],
    advancementFeats:[],
    masteries:{},
    version:3,
    // 战斗关联
    inCombat:false,
    combatUnitId:''
  };
}
function syncGame(){
  if(!S.game) return;
  var nm = calcHP()||10;
  var wasFull = S.game.currentHP >= S.game.maxHP;
  S.game.maxHP = nm;
  if(wasFull) S.game.currentHP = nm;
  if(S.game.currentHP > nm) S.game.currentHP = nm;
  var ns=getSlots(S.cls,S.level);
  var os=S.game.spellSlots||[];
  var mg=[];
  for(var i=0;i<ns.length;i++){
    if(ns[i]>0){
      var ou=0;
      for(var j=0;j<os.length;j++) if(os[j].level===i+1){ ou=os[j].used; break; }
      mg.push({level:i+1, max:ns[i], used:Math.min(ou, ns[i])});
    }
  }
  S.game.spellSlots = mg;
  if(S.game.hitDice) S.game.hitDice.total = Number(S.level)||1;
}

// ==================== 打开追踪 ====================
window.openTrk = function(id){
  var c=null;
  for(var i=0;i<CHARS.length;i++) if(CHARS[i].id===id) c=CHARS[i];
  if(!c) return;
  S=norm(JSON.parse(JSON.stringify(c)));
  if(!S.game) initGame(); else syncGame();
  saveCur();
  $('trkTitle').textContent = S.name||'角色卡';
  showPage('pgTrk');
  renderTrk();
  mountVoiceBar();
};
window.exitTrk = function(){
  saveCur();
  if(DM.active && DM.role==='player'){
    showPage('pgDM');
    renderDMHome();
    mountVoiceBarDM();
    return;
  }
  if(VOICE.enabled) voiceLeave();
  S=null;
  renderHome();
  showPage('pgHome');
};

function findSpell(k){
  var s=CANTRIPS.find(function(x){ return x.k===k; }); if(s) return s;
  s=LEVEL1_SPELLS.find(function(x){ return x.k===k; }); if(s) return s;
  s=LEVEL2_SPELLS.find(function(x){ return x.k===k; }); if(s) return s;
  s=LEVEL3_SPELLS.find(function(x){ return x.k===k; }); if(s) return s;
  return null;
}

window.jumpPlay=function(id){var el=document.getElementById(id);if(el)el.scrollIntoView({behavior:'smooth',block:'start'});};

// ==================== 追踪页渲染 ====================
function renderTrk(){
  if(!S || !S.game) return;
  var backBtn=$('trkBackBtn'); if(backBtn) backBtn.textContent=(DM.active&&DM.role==='player')?'跑团大厅':'返回主页';
  var g=S.game, cls=CLASSES[S.cls], spc=SPECIES[S.species];
  var sub=[spc?spc.n:'', cls?cls.n:'', '等级 '+S.level].filter(Boolean);
  var init=(S.name||'?').trim().charAt(0)||'?';
  var h='';
  h += '<div class="th"><div class="ta">'+esc(init)+'</div><div class="thi"><div class="thn">'+esc(S.name||'无名冒险者')+'</div><div class="thm">'+esc(sub.join(' · '))+'</div></div></div>';
  h += '<div class="play-strip"><div class="play-stat"><b>'+g.currentHP+'/'+g.maxHP+'</b><span>HP</span></div><div class="play-stat"><b>'+calcAC(S)+'</b><span>AC</span></div><div class="play-stat"><b>'+fmtMod(mod(S.abilities.dex))+'</b><span>先攻</span></div></div>';
  var liveCombat = !!(COMBAT.encounter && COMBAT.encounter.active && COMBAT.encounter.started);
  if(DM.active && DM.role==='player'){
    if(liveCombat) h += '<div class="session-mode combat"><div class="mode-icon">⚔</div><div class="mode-copy"><div class="mode-title">遭遇模式</div><div class="mode-sub">DM 已发起战斗 · 第 '+(COMBAT.encounter.round||1)+' 轮 · 常用战斗操作已置顶</div></div></div>';
    else h += '<div class="session-mode"><div class="mode-icon">🕯</div><div class="mode-copy"><div class="mode-title">探索模式</div><div class="mode-sub">已连接 DM · 自由调查、检定、记笔记；遭遇开始时会自动切换</div></div></div>';
  }
  if(liveCombat){
    h += '<div class="combat-actions"><button class="hot" onclick="jumpPlay(\'secAttack\')">⚔ 攻击</button><button onclick="jumpPlay(\'secSpell\')">✦ 法术</button><button onclick="jumpPlay(\'secHP\')">♥ HP</button></div>';
    h += '<div class="turn-order-mini">';
    COMBAT.encounter.units.forEach(function(u){ var cls2=(u.id===COMBAT.encounter.currentUnitId?' cur':'')+(u.ownerId===S.id?' me':''); h += '<span class="turn-chip'+cls2+'">'+esc(u.name)+'</span>'; });
    h += '</div>';
  }
  h += '<div class="quickdock"><button class="primary" onclick="jumpPlay(\'secDice\')">🎲 检定</button><button onclick="jumpPlay(\'secHP\')">♥ HP</button><button onclick="jumpPlay(\'secAttack\')">⚔ 攻击</button><button onclick="jumpPlay(\'secSpell\')">✦ 法术</button><button onclick="jumpPlay(\'secBag\')">▣ 背包</button><button onclick="jumpPlay(\'secNotes\')">✎ 笔记</button></div>';
  var bloodied = g.maxHP>0 && g.currentHP>0 && g.currentHP<=Math.floor(g.maxHP/2);
  var exhLv = Number(g.exhaustion)||0;
  h += '<div class="rules24-dash">';
  h += '<div class="rules24-head"><b>2024 状态总览</b><span>'+(liveCombat?'战斗中':'冒险中')+'</span></div>';
  h += '<div class="rules24-grid">';
  h += '<button onclick="jumpPlay(\'secHP\')"><b>'+(bloodied?'🩸 Bloodied':'♥ '+g.currentHP+'/'+g.maxHP)+'</b><span>'+(bloodied?'生命值不高于一半':'生命值')+'</span></button>';
  h += '<button onclick="toggleInsp()"><b>'+(g.inspiration?'✦ 已有':'✧ 无')+'</b><span>英雄激励</span></button>';
  h += '<button onclick="jumpPlay(\'secCond\')"><b>'+(g.conditions.length?g.conditions.length:'0')+'</b><span>状态</span></button>';
  h += '<button onclick="jumpPlay(\'secExh\')"><b>'+(exhLv?('−'+(exhLv*2)):'0')+'</b><span>力竭 D20 修正</span></button>';
  h += '</div></div>';

  // 当前遭遇（如果有）
  if(COMBAT.encounter && COMBAT.encounter.active && g.inCombat){
    var myUnit = COMBAT.encounter.units.find(function(u){ return u.ownerId===S.id; });
    var curUnit = COMBAT.encounter.units.find(function(u){ return u.id===COMBAT.encounter.currentUnitId; });
    if(myUnit && curUnit){
      var isMyTurn = (myUnit.id === curUnit.id);
      h += '<div class="turn-banner'+(isMyTurn?' myturn':'')+'">';
      h += '<div class="turn-banner-nm">'+(isMyTurn?'✦ 你的回合 ✦':'当前回合：'+esc(curUnit.name))+'</div>';
      h += '<div class="turn-banner-sub">第 '+COMBAT.encounter.round+' 轮</div>';
      h += '</div>';
      var mvUsed = Number(myUnit.moveUsed)||0, mvMax=Number(myUnit.moveMax)||30;
      h += '<div class="turn-economy'+(isMyTurn?'':' offturn')+'">';
      h += '<div class="turn-economy-title"><b>本回合</b><span>'+(isMyTurn?'轮到你行动':'等待 '+esc(curUnit.name))+'</span></div>';
      h += '<div class="turn-slots">';
      h += '<button class="turn-slot'+(myUnit.actionUsed?' used':'')+'" '+(!isMyTurn?'disabled':'')+' onclick="toggleTurnResource(\'action\')">⚔ 动作<br>'+(myUnit.actionUsed?'已使用':'可使用')+'</button>';
      h += '<button class="turn-slot'+(myUnit.bonusUsed?' used':'')+'" '+(!isMyTurn?'disabled':'')+' onclick="toggleTurnResource(\'bonus\')">✦ 附赠动作<br>'+(myUnit.bonusUsed?'已使用':'可使用')+'</button>';
      h += '<button class="turn-slot'+(myUnit.reactionUsed?' used':'')+'" '+(!isMyTurn?'disabled':'')+' onclick="toggleTurnResource(\'reaction\')">↩ 反应<br>'+(myUnit.reactionUsed?'已使用':'可使用')+'</button>';
      h += '</div>';
      h += '<div class="turn-move"><b>移动 '+mvUsed+' / '+mvMax+' 尺</b><button '+(!isMyTurn?'disabled':'')+' onclick="changeTurnMove(-5)">−5</button><button '+(!isMyTurn?'disabled':'')+' onclick="changeTurnMove(5)">+5</button><button '+(!isMyTurn?'disabled':'')+' onclick="changeTurnMove(999)">用完</button></div>';
      h += '<button class="end-turn-btn" '+(!isMyTurn?'disabled':'')+' onclick="endMyTurn()">✓ 结束我的回合</button>';
      h += '</div>';
    }
  }

  // 专注
  if(g.concentration){
    var fSp=findSpell(g.concentration);
    if(fSp){
      h += '<div class="focus-box"><span style="font-size:20px">◉</span><span class="focus-name">专注：'+esc(fSp.n)+'</span><button class="focus-btn" onclick="dropFocus()">✕</button></div>';
    }
  }

  // 灵感
  h += '<div class="insp2">'
    +'<span class="insp2-star">✦</span>'
    +'<span class="insp2-label">英雄激励</span>'
    +'<span class="insp2-state">'+(g.inspiration?'可重掷一次':'未持有')+'</span>'
    +'<button class="insp2-btn'+(g.inspiration?' on':'')+'" onclick="toggleInsp()">'+(g.inspiration?'使用':'获得')+'</button>'
    +'</div>';

  // 经验
  var lv=Number(S.level)||1, curE=g.exp||0;
  var curT=EXP_T[lv-1]||0, nxT=lv<20?EXP_T[lv]:null;
  var inL=curE-curT, needN=nxT!==null?nxT-curT:0;
  var canUp = nxT!==null && curE>=nxT;
  var pct = needN>0?Math.min(100,Math.max(0,inL/needN*100)):0;
  var toN = nxT!==null?Math.max(0,nxT-curE):0;
  h += '<div class="tb"><div class="tt">经验值 EXP</div>'
    +'<div class="ed"><div class="ec">'+curE.toLocaleString()+'</div><div class="el">总经验 · 等级 '+lv+'</div></div>';
  if(nxT!==null){
    h += '<div class="eb2"><i class="'+(canUp?'r':'')+'" style="width:'+pct+'%"></i></div><div class="em"><span>本级 <b>'+inL.toLocaleString()+'</b>/'+needN.toLocaleString()+'</span><span>距升级 <b>'+toN.toLocaleString()+'</b></span></div>';
  } else {
    h += '<div style="text-align:center;font-size:12px;color:#e8c95a;margin-top:8px">已满级 20</div>';
  }
  h += '<div class="eir"><button class="eab" onclick="addExp(50)">+50</button><button class="eab" onclick="addExp(100)">+100</button><button class="eab" onclick="addExp(250)">+250</button><button class="eab" onclick="addExp(500)">+500</button></div>'
    +'<div class="ecr"><input class="eci" type="number" id="expIn" placeholder="自定义" min="0"><button class="ecb a" onclick="expAdd()">获得</button><button class="ecb s" onclick="expSub()">扣除</button></div>';
  if(canUp) h += '<div class="lur"><div class="lut">★ 可以升级！</div><div style="font-size:12px;color:#9a8f7d">升至等级 '+(lv+1)+'</div><button class="lub" onclick="openLevelUp()">查看升级详情</button></div>';
  h += '</div>';

  // HP
  var hpPct=g.maxHP>0?g.currentHP/g.maxHP*100:0;
  var hpc=hpPct<=25?'c':(hpPct<=50?'w':'');
  var tmpPct=g.maxHP>0?Math.min(100,g.tempHP/g.maxHP*100):0;
  h += '<div class="tb" id="secHP"><div class="tt">生命值 HP</div>'
    +'<div class="hpd"><span class="hpc '+hpc+'">'+g.currentHP+'</span><span class="hps">/</span><span class="hpm">'+g.maxHP+'</span>'+(g.tempHP>0?'<span class="hpt">+ '+g.tempHP+' 临时</span>':'')+'</div>'
    +'<div class="hpb"><i class="'+hpc+'" style="width:'+hpPct+'%"></i>'+(g.tempHP>0?'<i class="t" style="width:'+tmpPct+'%"></i>':'')+'</div>'
    +'<div class="hir"><input class="hi" type="number" id="dmgIn" placeholder="受伤量" min="1"><button class="hab d" onclick="hpDmg()">受伤<small>扣除</small></button></div>'
    +'<div class="hir"><input class="hi" type="number" id="healIn" placeholder="治疗量" min="1"><button class="hab h" onclick="hpHeal()">治疗<small>恢复</small></button></div>'
    +'<div class="hir"><input class="hi" type="number" id="tmpIn" placeholder="临时 HP" min="0"><button class="hab t" onclick="hpTemp()">设置<small>临时</small></button></div>'
    +'<div class="hqr"><button class="hqb d" onclick="quickHP(-5)">-5</button><button class="hqb d" onclick="quickHP(-10)">-10</button><button class="hqb d" onclick="quickHP(-20)">-20</button><button class="hqb h" onclick="quickHP(5)">+5</button><button class="hqb h" onclick="quickHP(10)">+10</button><button class="hqb h" onclick="quickHP(20)">+20</button></div></div>';

  // 武器攻击
  var weapons=[];
  if(S.weapon && WEAPONS[S.weapon]) weapons.push(['主手', S.weapon]);
  if(S.offhand && WEAPONS[S.offhand]) weapons.push(['副手', S.offhand]);
  if(weapons.length > 0){
    h += '<div class="tb" id="secAttack"><div class="tt">武器攻击</div>';
    weapons.forEach(function(pair){
      var label=pair[0], k=pair[1];
      var w=WEAPONS[k], atk=wAtk(k), dm=wDmg(k);
      var safeK=k.replace(/'/g,"\\'");
      var ammoName = getAmmoForWeapon(k);
      var ammoCnt = ammoName ? (g.ammo[ammoName]||0) : null;
      var disabled = ammoName && ammoCnt<=0;
      h += '<div class="atk-card">';
      h += '<div class="atk-hd"><span class="atk-lb">'+label+'</span><span class="atk-nm">'+w.n+'</span><span class="atk-stat">'+fmt(atk)+' | '+dm+'</span></div>';
      if(ammoName){
        var ac = ammoCnt>0 ? (ammoCnt<=5?'#e0a33c':'#9a8f7d') : '#e05252';
        h += '<div style="font-size:11.5px;color:'+ac+';margin-bottom:8px;display:flex;align-items:center;gap:8px;flex-wrap:wrap"><span>需要 '+ammoName+'：<b>'+ammoCnt+'</b> 发</span>';
        if(ammoCnt<=0) h += '<button class="ecb a" style="flex:0 0 auto;width:auto;min-height:24px;font-size:11px;padding:0 8px" onclick="quickAddAmmo(\''+ammoName+'\')">补充 20</button>';
        h += '</div>';
      }
      h += '<div class="atk-btns">';
      if(disabled) h += '<button class="atk-btn hit" disabled style="opacity:.4">攻击（缺'+ammoName+'）</button>';
      else h += '<button class="atk-btn hit" onclick="rollWeaponAttack(\''+safeK+'\',\''+(ammoName||'')+'\')">攻击'+(ammoName?'（消耗 1）':'')+'</button>';
      h += '<button class="atk-btn dmg" onclick="rollDamage(\''+safeK+'\',false)">伤害</button>';
      h += '<button class="atk-btn crit" onclick="rollDamage(\''+safeK+'\',true)">暴击</button>';
      h += '</div></div>';
    });
    h += '</div>';
  }

  // 职业资源
  var resKeys = Object.keys(g.resources||{});
  if(resKeys.length > 0){
    h += '<div class="tb"><div class="tt">职业资源</div>';
    resKeys.forEach(function(rk){
      var r=g.resources[rk];
      h += '<div class="res-row">';
      h += '<div class="res-info"><div class="res-nm">'+r.n+'</div><div class="res-d">'+r.d+'</div></div>';
      if(r.pool){
        var used=r.poolUsed||0, avail=r.max-used;
        h += '<div class="res-pool"><span class="res-cnt">'+avail+'/'+r.max+'</span><input type="number" id="poolIn_'+rk+'" placeholder="用" min="1"><button onclick="resPoolSpend(\''+rk+'\')">消耗</button><button onclick="resPoolRestore(\''+rk+'\')">↻</button></div>';
      } else {
        h += '<div class="res-pips">';
        for(var pi=0; pi<r.max; pi++) h += '<div class="res-pip'+(pi<r.used?' u':'')+'" onclick="resToggle(\''+rk+'\','+pi+')"></div>';
        h += '</div><span class="res-cnt">'+(r.max-r.used)+'/'+r.max+'</span><button class="tb2" onclick="resRestore(\''+rk+'\')">↻</button>';
      }
      h += '</div>';
    });
    h += '</div>';
  }

  // 法术
  if(SPELLCASTER[S.cls] && (S.cantrips.length || S.spells1.length)){
    h += '<div class="tb" id="secSpell"><div class="tt">法术使用</div>';
    var sc=SPELLCASTER[S.cls];
    h += '<div style="font-size:12px;color:#9a8f7d;padding:0 4px 8px">施法属性 '+ABM[sc.ab].n+'　豁免 DC <b style="color:#c9a6e0">'+(8+pb()+modOf(sc.ab))+'</b>　攻击 <b style="color:#c9a6e0">'+fmt(pb()+modOf(sc.ab))+'</b></div>';
    h += '<div class="sp-cast">';
    S.cantrips.forEach(function(k){
      var sp=CANTRIPS.find(function(x){ return x.k===k; });
      if(!sp) return;
      h += '<div class="sp-cast-item"><div class="sp-cast-hd"><span class="sp-cast-nm" style="cursor:pointer" onclick="showSpell(\''+sp.k+'\')">'+sp.n+' <span style="font-size:11px;color:#6d6252">ⓘ</span></span></div><div class="sp-cast-dc">'+sp.d+'</div><div class="sp-cast-tags"><span class="sp-tag">'+sp.t+'</span><span class="sp-tag r">'+sp.r+'</span><span class="sp-tag">'+sp.c+'</span>'+(sp.cn?'<span class="sp-tag c">专注</span>':'')+'<span class="sp-tag">戏法</span></div><div style="margin-top:8px"><button class="sp-cast-btn" onclick="castSpell(\''+sp.k+'\',0)">施展戏法</button></div></div>';
    });
    S.spells1.forEach(function(k){
      var sp=LEVEL1_SPELLS.find(function(x){ return x.k===k; });
      if(!sp) return;
      var av1=g.spellSlots.filter(function(s){ return s.level===1 && s.used<s.max; }).length;
      var av2=g.spellSlots.filter(function(s){ return s.level===2 && s.used<s.max; }).length;
      var av3=g.spellSlots.filter(function(s){ return s.level===3 && s.used<s.max; }).length;
      var dis=av1===0;
      h += '<div class="sp-cast-item"><div class="sp-cast-hd"><span class="sp-cast-nm" style="cursor:pointer" onclick="showSpell(\''+sp.k+'\')">'+sp.n+' <span style="font-size:11px;color:#6d6252">ⓘ</span></span></div><div class="sp-cast-dc">'+sp.d+'</div><div class="sp-cast-tags"><span class="sp-tag">'+sp.t+'</span><span class="sp-tag r">'+sp.r+'</span><span class="sp-tag">'+sp.c+'</span>'+(sp.cn?'<span class="sp-tag c">专注</span>':'')+'<span class="sp-tag">1 环</span></div><div style="display:flex;gap:6px;margin-top:8px"><button class="sp-cast-btn" style="flex:1" '+(dis?'disabled':'')+' onclick="castSpell(\''+sp.k+'\',1)">1 环</button>';
      if(av2>0) h += '<button class="sp-cast-btn" style="flex:1" onclick="castSpell(\''+sp.k+'\',2)">升环 2</button>';
      if(av3>0) h += '<button class="sp-cast-btn" style="flex:1" onclick="castSpell(\''+sp.k+'\',3)">升环 3</button>';
      h += '</div></div>';
    });
    h += '</div></div>';
  }

  // 力竭
  h += '<div class="tb" id="secExh"><div class="tt">力竭 · 2024</div><div class="rule-note">每级：所有 D20 检定 −2，速度 −5 尺；6 级死亡。完成一次长休减少 1 级。</div>';
  EXH.forEach(function(e,i){
    var lvNum=i+1, on=(g.exhaustion||0)>=lvNum;
    var cls2='exh-lv'; if(lvNum>=5) cls2+=' danger'; else if(lvNum>=3) cls2+=' warn';
    h += '<div class="exh-row"><div style="flex:1"><div class="exh-label">'+e[1]+'</div><div class="exh-desc">'+e[2]+'</div></div><span class="'+cls2+'">'+(on?'●':'○')+'</span></div>';
  });
  h += '<div style="display:flex;gap:8px;margin-top:8px"><button class="rsb" style="flex:1" onclick="chExh(-1)">减少 1 级</button><button class="rsb s" style="flex:1" onclick="chExh(1)">增加 1 级</button></div></div>';

  // 死亡豁免
  if(g.currentHP<=0){
    h += '<div class="tb"><div class="tt">死亡豁免</div><div class="dsv">';
    h += '<div class="dgp"><div class="dlb s">成功</div><div class="dps">';
    for(var i=0;i<3;i++) h += '<div class="dp'+(i<g.deathSuccess?' on s':'')+'" onclick="setDS(\'s\','+i+')"></div>';
    h += '</div></div>';
    h += '<div class="dgp"><div class="dlb f">失败</div><div class="dps">';
    for(var j=0;j<3;j++) h += '<div class="dp'+(j<g.deathFail?' on f':'')+'" onclick="setDS(\'f\','+j+')"></div>';
    h += '</div></div>';
    h += '</div><div style="text-align:center;margin-top:12px"><button class="rsb r" style="max-width:200px;margin:0 auto" onclick="resetDS()">重置死亡豁免</button></div></div>';
  }

  // 法术位
  if(g.spellSlots && g.spellSlots.length>0){
    h += '<div class="tb"><div class="tt">法术位</div><div class="slg">';
    g.spellSlots.forEach(function(s){
      h += '<div class="slr"><div class="sll">'+s.level+' 环</div><div class="slp">';
      for(var k=0;k<s.max;k++) h += '<div class="pp'+(k<s.used?' u':'')+'" onclick="togPip('+s.level+','+k+')"></div>';
      h += '</div><div class="sbr"><button class="tb2" onclick="restSlots('+s.level+')">↻</button></div></div>';
    });
    h += '</div></div>';
  }

  // 生命骰
  var hd=g.hitDice||{total:Number(S.level)||1, used:0, die:(cls?cls.hd:8)};
  h += '<div class="tb"><div class="tt">生命骰</div><div style="display:flex;align-items:center;gap:12px;padding:10px 12px;background:#100d0a;border:1px solid #3a3128;border-radius:10px"><span style="font-size:13px;color:#c9a6e0;font-weight:600;font-family:Georgia,serif">d'+hd.die+'</span><div style="flex:1;display:flex;gap:4px;flex-wrap:wrap">';
  for(var hdI=0;hdI<hd.total;hdI++){
    var hdUsed=hdI<hd.used;
    h += '<div style="width:22px;height:22px;border-radius:6px;border:2px solid '+(hdUsed?'#5a4d3c':'#a37ac9')+';background:'+(hdUsed?'transparent':'#a37ac9')+'"></div>';
  }
  h += '</div><span style="font-size:12px;color:#9a8f7d">'+(hd.total-hd.used)+'/'+hd.total+'</span><button class="tb2" onclick="restHD()">↻</button></div></div>';

  // 状态
  h += '<div class="tb" id="secCond"><div class="tt">状态 · 2024';
  if(g.conditions.length) h += '<span style="font-size:11px;color:#e05252;font-weight:400;letter-spacing:0">　'+g.conditions.length+'</span>';
  h += '</div><div class="cg">';
  COND.forEach(function(c){
    var on=g.conditions.indexOf(c[0])>=0;
    h += '<div class="cck'+(on?' on':'')+'" onclick="togCond(\''+c[0]+'\')">'+c[1]+'</div>';
  });
  h += '</div>';
  if(g.conditions.length) h += '<div style="text-align:center;margin-top:12px"><button class="rsb r" style="max-width:200px;margin:0 auto" onclick="clrCond()">清除所有状态</button></div>';
  h += '</div>';

  // 2024 休息中心
  h += '<div class="tb" id="secRest"><div class="tt">休息</div><div class="rest24-grid">';
  h += '<button onclick="shortRest24()"><b>☕ 短休</b><span>使用生命骰 · 恢复短休资源</span></button>';
  h += '<button onclick="longRest()"><b>☾ 长休</b><span>恢复 HP / 资源 · 力竭 −1</span></button>';
  h += '</div><div class="rule-note">短休不会自动花费生命骰；先点击“短休”，再按需要使用生命骰恢复生命值。</div></div>';

  // 货币
  h += '<div class="tb"><div class="tt">货币</div>';
  var totalGp = currencyGpValue(g.currency);
  h += '<div style="font-size:12px;color:#9a8f7d;margin-bottom:10px">总计约 <b style="color:#e8c95a">'+totalGp.toFixed(2)+' GP</b> 等值</div>';
  h += '<div class="cur-grid">';
  CURRENCY_META.forEach(function(m){
    var v=g.currency[m.k]||0;
    h += '<div class="cur-cell"><div class="cur-e">'+m.e+'</div><div class="cur-v">'+v+'</div><div class="cur-c">'+m.n+'</div></div>';
  });
  h += '</div>';
  CURRENCY_META.forEach(function(m){
    h += '<div class="cur-row"><span class="cur-row-label">'+m.e+'</span><button class="cur-btn minus" onclick="curChange(\''+m.k+'\',-1)">−1</button><button class="cur-btn minus" onclick="curChange(\''+m.k+'\',-10)">−10</button><button class="cur-btn plus" onclick="curChange(\''+m.k+'\',1)">+1</button><button class="cur-btn plus" onclick="curChange(\''+m.k+'\',10)">+10</button></div>';
  });
  h += '<div class="cur-conv"><select id="convFrom">';
  CURRENCY_META.forEach(function(m){ if((g.currency[m.k]||0)>0) h += '<option value="'+m.k+'">'+m.e+' ('+(g.currency[m.k]||0)+')</option>'; });
  h += '</select><input type="number" id="convAmt" placeholder="数量" min="1"><button onclick="curConvert()">兑换</button></div>';
  h += '</div>';

  // 商店入口
  h += '<div class="tb"><div class="tt">商店</div><div class="shop-grid">';
  for(var sid in SHOPS){
    var sh=SHOPS[sid];
    h += '<button class="shop-btn" onclick="openShop(\''+sid+'\')"><span class="shop-ic">'+sh.icon+'</span><span style="flex:1;min-width:0"><span class="shop-nm">'+sh.n+'</span><span class="shop-sub">'+sh.desc+'</span></span></button>';
  }
  h += '</div></div>';

  // 队伍
  h += renderPartyPanel();

  // 背包
  h += '<div class="tb" id="secBag"><div class="tt">背包</div>';
  var inv=g.inventory||[];
  if(inv.length === 0) h += '<div class="empty-tip">背包空空如也</div>';
  else inv.forEach(function(item, i){
    h += '<div class="inv-item"><div class="inv-info"><div class="inv-nm">'+esc(item.n)+(item.q>1?' <span class="inv-q">×'+item.q+'</span>':'')+'</div>';
    if(item.d) h += '<div class="inv-d">'+esc(item.d)+'</div>';
    h += '</div>';
    if(item.cat==='weapon'||item.cat==='armor'||item.cat==='shield') h += '<button class="inv-eq" onclick="equipItem('+i+')">装备</button>';
    h += '</div>';
  });
  h += '</div>';

  // 弹药
  h += '<div class="tb"><div class="tt">弹药</div>';
  var ammoKeys = Object.keys(g.ammo||{});
  var usedAmmo = {};
  [S.weapon, S.offhand].forEach(function(wk){
    var an = getAmmoForWeapon(wk);
    if(an) usedAmmo[an] = (usedAmmo[an]||0) + 1;
  });
  if(ammoKeys.length === 0) h += '<div class="empty-tip">暂无弹药</div>';
  else {
    ammoKeys.sort(function(a,b){
      var au = usedAmmo[a]?1:0, bu = usedAmmo[b]?1:0;
      if(au!==bu) return bu-au;
      return a.localeCompare(b);
    });
    ammoKeys.forEach(function(name){
      var cnt=g.ammo[name];
      var safeName = esc(name).replace(/'/g,"\\'");
      var cls2 = cnt<=0?' z':(cnt<=5?' low':'');
      var usedTag = usedAmmo[name] ? '<span style="font-size:10px;padding:1px 6px;border-radius:6px;background:rgba(90,143,191,.15);color:#7fb0e0;margin-left:6px;border:1px solid rgba(90,143,191,.3)">装备中</span>' : '';
      h += '<div class="ammo-row2"><span class="ammo-nm2">'+esc(name)+usedTag+'</span><div class="ammo-ctrl2"><button class="ammo-btn2" onclick="ammoChange(\''+safeName+'\',-1)">−</button><span class="ammo-cnt2'+cls2+'">'+cnt+'</span><button class="ammo-btn2" onclick="ammoChange(\''+safeName+'\',1)">+</button><button class="ammo-btn2" onclick="ammoChange(\''+safeName+'\',5)">+5</button><button class="ammo-btn2 rec" onclick="ammoRecover(\''+safeName+'\')">回收</button></div></div>';
    });
  }
  h += '</div>';

  // 消耗品
  h += '<div class="tb"><div class="tt">消耗品</div>';
  var consKeys = Object.keys(g.consumables||{});
  var hasCons=false;
  consKeys.forEach(function(name){
    var qty=g.consumables[name];
    if(qty<=0) return;
    hasCons=true;
    var eff=CONSUMABLE_EFFECTS[name];
    var safeName=esc(name).replace(/'/g,"\\'");
    h += '<div class="ammo-row"><span class="ammo-name">'+esc(name)+(eff?'<span style="font-size:10.5px;color:#6d6252;margin-left:6px">'+eff.d+'</span>':'')+'</span><div class="ammo-ctrl"><button class="ammo-btn" onclick="chCons(\''+safeName+'\',-1)">−</button><span class="ammo-num">'+qty+'</span><button class="ammo-btn" onclick="chCons(\''+safeName+'\',1)">+</button>';
    if(eff && (eff.eff==='heal'||eff.eff==='attack'||eff.eff==='buff')) h += '<button class="ammo-btn" style="width:auto;padding:0 10px;font-size:11px;background:rgba(95,158,106,.15);color:#7fc98a" onclick="useCons(\''+safeName+'\')">用</button>';
    h += '</div></div>';
  });
  if(!hasCons) h += '<div class="empty-tip">暂无消耗品</div>';
  h += '</div>';

  // 骰子
  h += '<div class="tb" id="secDice"><div class="tt">骰子面板</div>';
  h += '<div class="amr" style="margin-bottom:10px"><button class="adv-btn dis'+(diceAdvMode==='dis'?' on':'')+'" data-adv-btn="dis" onclick="setAdvMode(\'dis\')">劣势</button><button class="adv-btn'+(diceAdvMode==='normal'?' on':'')+'" data-adv-btn="normal" onclick="setAdvMode(\'normal\')">普通</button><button class="adv-btn adv'+(diceAdvMode==='adv'?' on':'')+'" data-adv-btn="adv" onclick="setAdvMode(\'adv\')">优势</button></div>';
  h += '<div id="diceResult" class="dice-result"></div>';
  h += '<div class="dice-label">属性检定</div><div class="dice-grid">';
  AB.forEach(function(a){
    var m=modOf(a.k);
    h += '<button class="dice-btn" onclick="rollD20('+m+', \''+a.n+'检定\')">'+a.n+' '+fmt(m)+'</button>';
  });
  h += '</div>';
  h += '<div class="dice-label">豁免检定</div><div class="dice-grid">';
  AB.forEach(function(a){
    var cl=CLASSES[S.cls];
    var prof=cl && cl.sv.indexOf(a.k)>=0;
    var m=modOf(a.k)+(prof?pb():0);
    h += '<button class="dice-btn sv" onclick="rollD20('+m+', \''+a.n+'豁免\')">'+a.n+' '+fmt(m)+(prof?' ●':'')+'</button>';
  });
  h += '</div>';
  h += '<div class="dice-label">技能检定</div>';
  h += '<select class="es" style="margin-bottom:10px" onchange="if(this.value){var v=this.value.split(\'|\');rollD20(parseInt(v[1]), v[0]+\'检定\');this.value=\'\'}"><option value="">选择技能…</option>';
  SKILLS.forEach(function(s){
    var m=skillB(s.k);
    var prof=S.skills.indexOf(s.k)>=0;
    h += '<option value="'+s.n+'|'+m+'">'+s.n+' '+fmt(m)+(prof?' [熟练]':'')+'</option>';
  });
  h += '</select>';
  h += '<div class="dice-label">先攻</div>';
  var initBonus = modOf('dex')+(S.feat==='alert'?pb():0);
  h += '<button class="dice-btn" style="width:100%;margin-bottom:12px" onclick="rollD20('+initBonus+', \'先攻\')">先攻检定 '+fmt(initBonus)+'</button>';
  h += '<div class="dice-label">自定义表达式</div>';
  h += '<div class="ecr"><input class="eci" type="text" id="diceExpr" placeholder="例如 2d6+3" style="flex:1"><button class="ecb a" onclick="rollExpr($(\'diceExpr\').value)">掷骰</button></div>';
  h += '</div>';

  // 协作者
  h += '<div class="tb"><div class="tt">协作者/伙伴</div>';
  if(!g.companions || g.companions.length===0) h += '<div class="empty-tip">暂无协作者</div>';
  else g.companions.forEach(function(comp,i){
    var down=comp.hp<=0;
    h += '<div class="comp-row"><span class="comp-name">'+esc(comp.name)+'</span><span class="comp-hp">'+comp.hp+'/'+comp.maxHP+'</span><span class="comp-status'+(down?' down':'')+'">'+(down?'倒地':'正常')+'</span><button class="ammo-btn" style="width:28px;height:28px;font-size:14px" onclick="delComp('+i+')">✕</button></div>';
  });
  h += '<div style="display:flex;gap:6px;margin-top:8px"><input class="eci" type="text" id="compName" placeholder="同伴名称" style="flex:1"><input class="eci" type="number" id="compHP" placeholder="HP" min="1" style="width:80px"><button class="ecb a" onclick="addComp()">添加</button></div></div>';

  // 玩家申请（仅 P2P 连接时）
  if(DM.active && DM.role === 'player'){
    h += renderPlayerRequests();
  }

  // 笔记
  h += '<div class="tb" id="secNotes"><div class="tt">冒险笔记</div><textarea class="note-area" id="noteArea" placeholder="记录任务、NPC、地点、线索…" oninput="saveNote()">'+esc(g.notes||'')+'</textarea><div class="note-meta" id="noteMeta">自动保存</div></div>';

  // 休整
  h += '<div class="tb"><div class="tt">休整</div><div class="rst" style="margin-top:0"><button class="rsb l" onclick="longRest()">🌙 长休</button><button class="rsb s" onclick="shortRest()">☕ 短休</button></div><div class="rst"><button class="rsb r" onclick="resetTrk()">🔄 重置追踪</button></div></div>';

  $('trkMain').innerHTML=h;
}

// 队伍面板
function renderPartyPanel(){
  if(!DM.active || DM.role !== 'player') return '';
  var h = '<div class="tb"><div class="tt">队伍</div><div class="party-grid">';
  // 自己
  if(S && S.game){
    var meName = S.name || '我';
    var hpPct = S.game.maxHP>0 ? S.game.currentHP/S.game.maxHP*100 : 0;
    var hc = hpPct<=25?'c':(hpPct<=50?'w':'');
    h += '<div class="party-card me"><div class="party-av">'+esc(meName.charAt(0))+'</div><div class="party-info"><div class="party-nm">'+esc(meName)+' (我)</div><div class="party-meta">'+CLASSES[S.cls]?.n+' · 等级 '+S.level+'</div><div class="party-hp-bar"><i class="'+hc+'" style="width:'+hpPct+'%"></i></div></div><div class="party-hp">'+S.game.currentHP+'/'+S.game.maxHP+'</div></div>';
  }
  // 队友
  PARTY.members.forEach(function(m){
    var hpPct = m.maxHP>0 ? m.hp/m.maxHP*100 : 0;
    var hc = hpPct<=25?'c':(hpPct<=50?'w':'');
    h += '<div class="party-card"><div class="party-av">'+esc(m.name.charAt(0))+'</div><div class="party-info"><div class="party-nm">'+esc(m.name)+'</div><div class="party-meta">'+(m.cls||'')+(m.online?' · 在线':' · 离线')+'</div><div class="party-hp-bar"><i class="'+hc+'" style="width:'+hpPct+'%"></i></div></div><div class="party-hp">'+m.hp+'/'+m.maxHP+'</div></div>';
  });
  h += '</div></div>';
  return h;
}

// 玩家申请面板
function renderPlayerRequests(){
  var h = '<div class="tb"><div class="tt">向 DM 申请</div>';
  h += '<div class="req-grid">';
  h += '<button class="heal" onclick="playerRequest(\'heal\')">💊 申请加血</button>';
  h += '<button class="gold" onclick="playerRequest(\'gold\')">💰 申请补钱</button>';
  h += '<button class="rest" onclick="playerRequest(\'rest\')">☕ 申请休息</button>';
  h += '<button class="msg" onclick="playerRequest(\'msg\')">💬 发送消息</button>';
  h += '</div></div>';
  return h;
}

// ==================== 追踪页操作 ====================
window.toggleInsp = function(){ if(!S||!S.game) return; S.game.inspiration = !S.game.inspiration; saveCur(); renderTrk(); };
window.saveNote = function(){
  if(!S||!S.game) return;
  var ta=$('noteArea'); if(!ta) return;
  S.game.notes = ta.value;
  saveCur();
  var meta=$('noteMeta'); if(meta) meta.textContent = '已保存 · ' + new Date().toLocaleTimeString();
};
window.showSpell = function(k){
  var sp=findSpell(k); if(!sp) return;
  var html = '<div style="font-size:16px;color:#c9a6e0;font-weight:600;margin-bottom:8px">'+sp.n+'</div>';
  html += '<div style="font-size:12.5px;color:#9a8f7d;line-height:1.8">';
  html += '<b style="color:#c9a227">施法时间：</b>'+sp.t+'<br>';
  html += '<b style="color:#c9a227">范围：</b>'+sp.r+'<br>';
  html += '<b style="color:#c9a227">成分：</b>'+sp.c+'<br>';
  html += '<b style="color:#c9a227">持续时间：</b>'+(sp.du||'—')+'<br>';
  if(sp.cn) html += '<b style="color:#e05252">需要专注</b>';
  html += '</div>';
  html += '<div style="margin-top:12px;padding:12px;background:#100d0a;border-radius:8px;font-size:13px;line-height:1.6;color:#e8e0d0">'+sp.d+'</div>';
  if(sp.up) html += '<div style="margin-top:8px;padding:8px 12px;background:rgba(201,162,39,.08);border-left:3px solid #c9a227;border-radius:6px;font-size:12px;color:#e8c95a;text-align:left"><b>升环：</b>'+sp.up+'</div>';
  dlg(sp.n, '', [{l:'关闭', c:'p'}], true);
  $('dgX').innerHTML = html;
};
window.setAdvMode = function(m){
  diceAdvMode = m;
  document.querySelectorAll('[data-adv-btn]').forEach(function(b){
    b.classList.toggle('on', b.getAttribute('data-adv-btn')===m);
  });
};
window.renderDiceResult = function(txt, crit){
  var box=$('diceResult'); if(!box) return;
  box.innerHTML='<div style="font-size:14px;color:#e8c95a;font-weight:600;font-family:Georgia,serif;line-height:1.6">'+esc(txt)+'</div>';
  if(crit===20) box.style.borderColor='#7fc98a';
  else if(crit===1) box.style.borderColor='#e05252';
  else box.style.borderColor='rgba(201,162,39,.4)';
  box.style.display='block';
};
window.rollD20 = function(bonus, label){
  var r1=Math.floor(Math.random()*20)+1;
  var r2=null, used=r1;
  if(diceAdvMode==='adv'){ r2=Math.floor(Math.random()*20)+1; used=Math.max(r1,r2); }
  else if(diceAdvMode==='dis'){ r2=Math.floor(Math.random()*20)+1; used=Math.min(r1,r2); }
  var total = used+bonus;
  var txt = label+'：d20';
  if(r2!==null) txt += '（'+r1+' , '+r2+'）→ '+used;
  else txt += '（'+used+'）';
  txt += ' '+(bonus>=0?'+'+bonus:bonus)+' = '+total;
  if(used===20) txt += ' ★ 大成功！';
  if(used===1) txt += ' ✗ 大失败！';
  renderDiceResult(txt, used);
  if(DM.active && DM.role==='player' && P2P.ready){
    P2P.send({type:'dice-roll', name:(S&&S.name)||'玩家', text:txt});
  }
};
window.rollExpr = function(expr){
  if(!expr) return;
  var m=expr.trim().match(/^(\d*)d(\d+)([+-]\d+)?$/i);
  if(!m){ renderDiceResult('表达式格式无效，例如：2d6+3', 0); return; }
  var n=m[1]?parseInt(m[1]):1;
  var d=parseInt(m[2]);
  var b=m[3]?parseInt(m[3]):0;
  if(n<1||n>50||d<2||d>100){ renderDiceResult('骰子数量或面数超出范围', 0); return; }
  var rolls=[], sum=0;
  for(var i=0;i<n;i++){ var r=Math.floor(Math.random()*d)+1; rolls.push(r); sum+=r; }
  var total=sum+b;
  var txt=expr+'：['+rolls.join(', ')+']';
  if(b) txt += (b>=0?' + '+b:' - '+Math.abs(b));
  txt += ' = '+total;
  renderDiceResult(txt, 0);
  if(DM.active && DM.role==='player' && P2P.ready){
    P2P.send({type:'dice-roll', name:(S&&S.name)||'玩家', text:txt});
  }
};
function myCombatUnit(){
  if(!S || !COMBAT.encounter || !COMBAT.encounter.units) return null;
  return COMBAT.encounter.units.find(function(u){ return u.ownerId===S.id; }) || null;
}
function isMyCombatTurn(){ var u=myCombatUnit(); return !!(u && COMBAT.encounter.currentUnitId===u.id && COMBAT.encounter.started); }
function syncTurnUse(u){
  saveEncounter();
  if(DM.active && DM.role==='player' && P2P.ready && u){
    P2P.send({type:'turn-action', unitId:u.id, actionUsed:!!u.actionUsed, bonusUsed:!!u.bonusUsed, reactionUsed:!!u.reactionUsed, moveUsed:Number(u.moveUsed)||0});
  }
}
window.toggleTurnResource=function(kind){
  var u=myCombatUnit(); if(!u || !isMyCombatTurn()) return;
  var key=kind==='bonus'?'bonusUsed':kind==='reaction'?'reactionUsed':'actionUsed';
  u[key]=!u[key]; syncTurnUse(u); renderTrk();
};
window.changeTurnMove=function(delta){
  var u=myCombatUnit(); if(!u || !isMyCombatTurn()) return;
  var max=Number(u.moveMax)||30, cur=Number(u.moveUsed)||0;
  u.moveUsed = delta===999 ? max : Math.max(0,Math.min(max,cur+delta));
  syncTurnUse(u); renderTrk();
};
function autoUseTurnResource(kind){
  var u=myCombatUnit(); if(!u || !isMyCombatTurn()) return;
  var key=kind==='bonus'?'bonusUsed':kind==='reaction'?'reactionUsed':'actionUsed';
  if(!u[key]){ u[key]=true; syncTurnUse(u); }
}
window.endMyTurn=function(){
  var u=myCombatUnit(); if(!u || !isMyCombatTurn()) return;
  if(DM.active && DM.role==='player' && P2P.ready){ P2P.send({type:'turn-end',unitId:u.id,name:(S&&S.name)||'玩家'}); }
};

window.rollWeaponAttack = function(k, ammoName){
  var w=WEAPONS[k]; if(!w) return;
  autoUseTurnResource('action');
  if(ammoName){
    var cur=(S.game.ammo && S.game.ammo[ammoName])||0;
    if(cur<=0){ alert('没有 '+ammoName+' 了！'); return; }
  }
  var r1=Math.floor(Math.random()*20)+1;
  var r2=null, used=r1;
  if(diceAdvMode==='adv'){ r2=Math.floor(Math.random()*20)+1; used=Math.max(r1,r2); }
  else if(diceAdvMode==='dis'){ r2=Math.floor(Math.random()*20)+1; used=Math.min(r1,r2); }
  var bonus=wAtk(k), total=used+bonus;
  var txt=w.n+' 攻击：d20';
  if(r2!==null) txt += '（'+r1+' , '+r2+'）→ '+used;
  else txt += '（'+used+'）';
  txt += ' '+(bonus>=0?'+'+bonus:bonus)+' = '+total;
  if(ammoName) txt += '（消耗 1 '+ammoName+'）';
  var isCrit=(used===20), isFumble=(used===1);
  if(isCrit) txt += ' ★ 暴击！';
  if(isFumble) txt += ' ✗ 大失败！';
  renderDiceResult(txt, used);
  if(ammoName && S.game.ammo){
    S.game.ammo[ammoName] = Math.max(0, (S.game.ammo[ammoName]||0)-1);
    if(S.game.ammo[ammoName]===0) delete S.game.ammo[ammoName];
    saveCur();
  }
  // 同步 DM
  if(DM.active && DM.role==='player' && P2P.ready){
    P2P.send({type:'attack-roll', name:(S&&S.name)||'玩家', weapon:w.n, text:txt, damage: wDmg(k), crit: isCrit});
  }
  if(isCrit){
    dlg('暴击！','你的「'+w.n+'」击出暴击！\n点击下方按钮掷双倍伤害。',[
      {l:'稍后'},
      {l:'掷双倍伤害', c:'p', f:function(){ rollDamage(k,true); }}
    ]);
  }
};
window.rollDamage = function(k, crit){
  var w=WEAPONS[k]; if(!w) return;
  var dm=String(w.d).match(/^(\d+)d(\d+)$/);
  if(!dm){ renderDiceResult('无法解析伤害骰：'+w.d, 0); return; }
  var n=parseInt(dm[1]), d=parseInt(dm[2]);
  var total=0, rolls=[];
  if(crit){
    var n2=n*2;
    for(var i=0;i<n2;i++){ var r=Math.floor(Math.random()*d)+1; rolls.push(r); total+=r; }
    var m=wDmgM(k);
    var grand=total+m;
    var txt=w.n+' 暴击伤害：'+n2+'d'+d+' ['+rolls.join(', ')+']';
    if(m) txt += (m>=0?' + '+m:' - '+Math.abs(m));
    txt += ' = '+grand+' '+w.dt;
    renderDiceResult(txt, 20);
  } else {
    for(var i=0;i<n;i++){ var r=Math.floor(Math.random()*d)+1; rolls.push(r); total+=r; }
    var m=wDmgM(k);
    var grand=total+m;
    var txt=w.n+' 伤害：'+n+d+'d'+(n>1?'':'')+' ['+rolls.join(', ')+']';
    txt = w.n+' 伤害：'+n+'d'+d+' ['+rolls.join(', ')+']';
    if(m) txt += (m>=0?' + '+m:' - '+Math.abs(m));
    txt += ' = '+grand+' '+w.dt;
    renderDiceResult(txt, 0);
  }
  if(DM.active && DM.role==='player' && P2P.ready){
    P2P.send({type:'dice-roll', name:(S&&S.name)||'玩家', text:'伤害掷骰'});
  }
};
window.hpDmg = function(){
  if(!S||!S.game) return;
  var g=S.game, v=parseInt($('dmgIn').value,10);
  if(isNaN(v)||v<=0) return;
  var rm=v;
  if(g.tempHP>0){ var u=Math.min(g.tempHP,rm); g.tempHP-=u; rm-=u; }
  if(rm>0) g.currentHP=Math.max(0, g.currentHP-rm);
  if(g.concentration && rm>0){
    var dc=Math.max(10,Math.floor(rm/2));
    var concName = findSpell(g.concentration)?findSpell(g.concentration).n:g.concentration;
    var bonus = modOf('con')+(CLASSES[S.cls]&&CLASSES[S.cls].sv.indexOf('con')>=0?pb():0);
    saveCur(); renderTrk();
    syncToDM();
    dlg('专注豁免','你受到了 '+rm+' 点伤害。\n维持「'+concName+'」需要进行体质豁免。\nDC = '+dc+'\n\n你的体质豁免加值：'+fmt(bonus),[
      {l:'好', c:'p'},
      {l:'掷骰', c:'p', f:function(){ rollD20(bonus, concName+' 专注豁免'); }}
    ]);
    return;
  }
  saveCur(); renderTrk();
  syncToDM();
};
window.hpHeal = function(){
  if(!S||!S.game) return;
  var g=S.game, v=parseInt($('healIn').value,10);
  if(isNaN(v)||v<=0) return;
  g.currentHP=Math.min(g.maxHP, g.currentHP+v);
  saveCur(); renderTrk();
  syncToDM();
};
window.hpTemp = function(){
  if(!S||!S.game) return;
  var g=S.game, v=parseInt($('tmpIn').value,10);
  if(isNaN(v)||v<0) return;
  g.tempHP=v;
  saveCur(); renderTrk();
};
window.quickHP = function(n){
  if(!S||!S.game) return;
  var g=S.game;
  if(n<0){
    var rm=-n;
    if(g.tempHP>0){ var u=Math.min(g.tempHP,rm); g.tempHP-=u; rm-=u; }
    if(rm>0) g.currentHP=Math.max(0, g.currentHP-rm);
  } else {
    g.currentHP=Math.min(g.maxHP, g.currentHP+n);
  }
  saveCur(); renderTrk();
  syncToDM();
};
window.chExh = function(d){ if(S&&S.game){ S.game.exhaustion=Math.max(0,Math.min(6,(S.game.exhaustion||0)+d)); saveCur(); renderTrk(); } };
window.togPip = function(lv,idx){
  if(!S||!S.game) return;
  var g=S.game, sl=null;
  for(var i=0;i<g.spellSlots.length;i++) if(g.spellSlots[i].level===lv){ sl=g.spellSlots[i]; break; }
  if(!sl) return;
  sl.used = (idx<sl.used)?idx:idx+1;
  saveCur(); renderTrk();
};
window.restSlots = function(lv){
  if(!S||!S.game) return;
  var g=S.game;
  for(var i=0;i<g.spellSlots.length;i++) if(g.spellSlots[i].level===lv){ g.spellSlots[i].used=0; break; }
  saveCur(); renderTrk();
};
window.restHD = function(){ if(S&&S.game){ if(S.game.hitDice) S.game.hitDice.used=0; saveCur(); renderTrk(); } };
window.togCond = function(k){
  if(!S||!S.game) return;
  var g=S.game;
  var i=g.conditions.indexOf(k);
  if(i>=0) g.conditions.splice(i,1); else g.conditions.push(k);
  saveCur(); renderTrk();
  syncToDM();
};
window.clrCond = function(){ if(S&&S.game){ S.game.conditions=[]; saveCur(); renderTrk(); syncToDM(); } };
window.setDS = function(t,i){
  if(!S||!S.game) return;
  var g=S.game;
  if(t==='s') g.deathSuccess = (i<g.deathSuccess)?i:i+1;
  else g.deathFail = (i<g.deathFail)?i:i+1;
  saveCur(); renderTrk();
};
window.resetDS = function(){ if(S&&S.game){ S.game.deathSuccess=0; S.game.deathFail=0; saveCur(); renderTrk(); } };
window.chGold = function(d){ if(S&&S.game){ S.game.gold=(S.game.gold||0)+d; saveCur(); renderTrk(); } };
window.ammoChange = function(name, amt){
  if(!S||!S.game) return;
  if(!S.game.ammo) S.game.ammo={};
  var cur=S.game.ammo[name]||0;
  var nv=Math.max(0, cur+amt);
  if(nv===0) delete S.game.ammo[name]; else S.game.ammo[name]=nv;
  saveCur(); renderTrk();
};
window.ammoRecover = function(name){
  if(!S||!S.game) return;
  if(!S.game.ammo) S.game.ammo={};
  var cur=S.game.ammo[name]||0;
  var half=Math.ceil(cur/2);
  S.game.ammo[name]=cur+half;
  saveCur(); renderTrk();
};
window.quickAddAmmo = function(name){
  if(!S||!S.game) return;
  if(!S.game.ammo) S.game.ammo={};
  S.game.ammo[name]=(S.game.ammo[name]||0)+20;
  saveCur(); renderTrk();
};
window.chCons = function(name,d){
  if(!S||!S.game) return;
  if(!S.game.consumables) S.game.consumables={};
  S.game.consumables[name]=Math.max(0,(S.game.consumables[name]||0)+d);
  if(S.game.consumables[name]===0) delete S.game.consumables[name];
  saveCur(); renderTrk();
};
window.useCons = function(name){
  if(!S||!S.game) return;
  var g=S.game;
  if(!g.consumables[name]||g.consumables[name]<=0) return;
  var eff=CONSUMABLE_EFFECTS[name];
  var msg='';
  if(!eff) msg='使用了「'+name+'」。';
  else if(eff.eff==='heal'){
    var roll=rollDice(eff.dice);
    var before=g.currentHP;
    g.currentHP=Math.min(g.maxHP, g.currentHP+roll);
    var healed=g.currentHP-before;
    msg='使用「'+name+'」\n掷骰 '+eff.dice+' = '+roll+'\n恢复 '+healed+' HP（当前 '+g.currentHP+'/'+g.maxHP+'）';
  } else if(eff.eff==='attack'){
    var dmg=rollDice(eff.dice);
    msg='使用「'+name+'」\n掷骰 '+eff.dice+' = '+dmg+'\n造成 '+dmg+' 点伤害，请手动应用到目标。';
  } else msg='使用「'+name+'」\n'+eff.d;
  g.consumables[name]--;
  if(g.consumables[name]<=0) delete g.consumables[name];
  saveCur(); renderTrk();
  syncToDM();
  dlg('使用消耗品', msg, [{l:'好', c:'p'}]);
};
window.resRestore = function(key){
  if(!S||!S.game) return;
  var r=S.game.resources[key]; if(!r) return;
  r.used=0; if(r.pool) r.poolUsed=0;
  saveCur(); renderTrk();
};
window.resToggle = function(key, idx){
  if(!S||!S.game) return;
  var r=S.game.resources[key]; if(!r||r.pool) return;
  r.used=(idx<r.used)?idx:idx+1;
  saveCur(); renderTrk();
};
window.resPoolSpend = function(key){
  if(!S||!S.game) return;
  var r=S.game.resources[key]; if(!r||!r.pool) return;
  var inp=$('poolIn_'+key); if(!inp) return;
  var v=parseInt(inp.value,10);
  if(isNaN(v)||v<=0) return;
  var avail=r.max-(r.poolUsed||0);
  if(v>avail) v=avail;
  r.poolUsed=(r.poolUsed||0)+v;
  inp.value='';
  saveCur(); renderTrk();
};
window.resPoolRestore = function(key){
  if(!S||!S.game) return;
  var r=S.game.resources[key]; if(!r||!r.pool) return;
  r.poolUsed=0;
  saveCur(); renderTrk();
};
window.curChange = function(kind, amt){
  if(!S||!S.game) return;
  var c=S.game.currency;
  c[kind]=Math.max(0,(c[kind]||0)+amt);
  saveCur(); renderTrk();
  syncToDM();
};
window.curConvert = function(){
  if(!S||!S.game) return;
  var sel=$('convFrom'), inp=$('convAmt');
  if(!sel||!inp) return;
  var fromK=sel.value, v=parseInt(inp.value,10);
  if(isNaN(v)||v<=0) return;
  var fromMeta=null;
  CURRENCY_META.forEach(function(m){ if(m.k===fromK) fromMeta=m; });
  if(!fromMeta) return;
  var c=S.game.currency;
  if((c[fromK]||0)<v){ alert('数量不足'); return; }
  var idx=CURRENCY_META.indexOf(fromMeta);
  if(idx<=0){ alert('已是最小面额，无法再换'); return; }
  c[fromK]-=v;
  var toMeta=CURRENCY_META[idx-1];
  var rate=fromMeta.toCp/toMeta.toCp;
  var toAmt=Math.floor(v*rate);
  var leftover=v-Math.floor(toAmt*toMeta.toCp/fromMeta.toCp);
  c[toMeta.k]=(c[toMeta.k]||0)+toAmt;
  if(leftover>0) c[fromK]=(c[fromK]||0)+leftover;
  saveCur(); renderTrk();
};
window.addComp = function(){
  var name=$('compName').value.trim();
  var hp=parseInt($('compHP').value,10);
  if(!name||isNaN(hp)||hp<=0) return;
  if(!S.game.companions) S.game.companions=[];
  S.game.companions.push({name:name, hp:hp, maxHP:hp});
  saveCur(); renderTrk();
};
window.delComp = function(i){
  if(S&&S.game&&S.game.companions){ S.game.companions.splice(i,1); saveCur(); renderTrk(); }
};
window.castSpell = function(k,lvl){
  if(!S||!S.game) return;
  var g=S.game, sp=findSpell(k);
  if(!sp) return;
  if(lvl>0){
    var slot=null;
    for(var i=0;i<g.spellSlots.length;i++) if(g.spellSlots[i].level===lvl && g.spellSlots[i].used<g.spellSlots[i].max){ slot=g.spellSlots[i]; break; }
    if(!slot){ alert(lvl+' 环法术位已用尽'); return; }
    slot.used++;
  }
  if(sp.cn){
    if(g.concentration && g.concentration!==k){
      var old=findSpell(g.concentration);
      var msg='施展「'+sp.n+'」会打断当前专注的「'+(old?old.n:g.concentration)+'」。确定继续吗？';
      dlg('切换专注', msg, [
        {l:'取消'},
        {l:'确定切换', c:'p', f:function(){ doCast(k,lvl,sp); }}
      ]);
      return;
    }
    g.concentration = k;
  }
  doCast(k,lvl,sp);
};
function doCast(k,lvl,sp){
  var g=S.game;
  var castTime=String(sp.t||'');
  if(castTime.indexOf('附赠')>=0) autoUseTurnResource('bonus');
  else if(castTime.indexOf('反应')>=0) autoUseTurnResource('reaction');
  else autoUseTurnResource('action');
  if(!g.castHistory) g.castHistory=[];
  g.castHistory.unshift({k:k, lvl:lvl, t:Date.now()});
  if(g.castHistory.length>20) g.castHistory=g.castHistory.slice(0,20);
  saveCur(); renderTrk();
  var lvlTxt = lvl===0?'戏法':(lvl+' 环法术位');
  var extra = '';
  if(lvl>1 && sp.up) extra = '\n\n升环效果：'+sp.up;
  dlg('施展成功','施展了「'+sp.n+'」\n消耗：'+lvlTxt+(sp.cn?'\n现在处于专注状态':'')+extra, [{l:'好', c:'p'}]);
}
window.dropFocus = function(){ if(!S||!S.game) return; S.game.concentration=''; saveCur(); renderTrk(); };
window.addExp = function(n){ if(S&&S.game){ S.game.exp=(S.game.exp||0)+n; saveCur(); renderTrk(); } };
window.expAdd = function(){ if(!S||!S.game) return; var v=parseInt($('expIn').value,10); if(isNaN(v)||v<=0) return; S.game.exp=(S.game.exp||0)+v; saveCur(); renderTrk(); };
window.expSub = function(){ if(!S||!S.game) return; var v=parseInt($('expIn').value,10); if(isNaN(v)||v<=0) return; S.game.exp=Math.max(0,(S.game.exp||0)-v); saveCur(); renderTrk(); };

window.shortRest24 = function(){
  if(!S||!S.game) return;
  var g=S.game;
  Object.keys(g.resources||{}).forEach(function(rk){ var r=g.resources[rk]; if(r && r.reset==='short'){ if(r.pool) r.poolUsed=0; else r.used=0; } });
  // Pact Magic and other short-rest resources are represented in resources; spell-slot handling remains class-specific.
  saveCur(); renderTrk(); syncToDM();
  toast('短休完成：短休资源已恢复。生命骰请按需要使用。');
};
window.longRest = function(){
  if(!S||!S.game) return;
  var g=S.game;
  g.currentHP=g.maxHP; g.tempHP=0;
  g.spellSlots.forEach(function(s){ s.used=0; });
  g.deathSuccess=0; g.deathFail=0;
  if(g.hitDice) g.hitDice.used = Math.max(0, g.hitDice.used - Math.ceil(g.hitDice.total/2));
  if(g.exhaustion>0) g.exhaustion--;
  g.conditions=[]; g.concentration='';
  Object.keys(g.resources||{}).forEach(function(rk){
    var r=g.resources[rk]; r.used=0; if(r.pool) r.poolUsed=0;
  });
  saveCur(); renderTrk();
  syncToDM();
};
window.shortRest = function(){
  if(!S||!S.game) return;
  var g=S.game;
  g.tempHP=0;
  if(S.cls==='warlock') g.spellSlots.forEach(function(s){ s.used=0; });
  Object.keys(g.resources||{}).forEach(function(rk){
    var r=g.resources[rk];
    if(r.reset==='short'){ r.used=0; if(r.pool) r.poolUsed=0; }
  });
  if(g.hitDice && g.hitDice.used<g.hitDice.total){
    g.hitDice.used++;
    var die=g.hitDice.die||8;
    var roll=Math.floor(Math.random()*die)+1;
    var conMod=modOf('con');
    var healed=Math.max(1, roll+conMod);
    g.currentHP=Math.min(g.maxHP, g.currentHP+healed);
  }
  saveCur(); renderTrk();
  syncToDM();
};
window.resetTrk = function(){
  if(!S) return;
  dlg('重置追踪','确定重置？等级、经验、货币、背包会保留。',[
    {l:'取消'},
    {l:'重置', c:'d', f:function(){
      var keepExp=S.game.exp||0;
      var keepCurrency=JSON.parse(JSON.stringify(S.game.currency||{pp:0,gp:0,ep:0,sp:0,cp:0}));
      var keepInsp=S.game.inspiration||false;
      var keepNotes=S.game.notes||'';
      var keepAmmo=JSON.parse(JSON.stringify(S.game.ammo||{}));
      var keepInv=JSON.parse(JSON.stringify(S.game.inventory||[]));
      initGame();
      S.game.exp=keepExp;
      S.game.currency=keepCurrency;
      S.game.inspiration=keepInsp;
      S.game.notes=keepNotes;
      S.game.ammo=keepAmmo;
      S.game.inventory=keepInv;
      saveCur(); renderTrk();
    }}
  ]);
};
window.openLevelUp = function(){
  if(!S||!S.game) return;
  var lv=Number(S.level)||1;
  if(lv>=20){ alert('已满级'); return; }
  var nlv=lv+1;
  var oldHP=S.game.maxHP;
  var cls=CLASSES[S.cls], co=modOf('con'), die=cls?cls.hd:8;
  var pl=Math.max(1, Math.floor(die/2)+1+co);
  var newHP=oldHP+pl;
  var oldPB=2+Math.floor((lv-1)/4), newPB=2+Math.floor((nlv-1)/4);
  var oldSlots=getSlots(S.cls,lv), newSlots=getSlots(S.cls,nlv);
  var slotsDiff=[];
  var maxLen=Math.max(oldSlots.length,newSlots.length);
  for(var i=0;i<maxLen;i++){
    var o=oldSlots[i]||0, n=newSlots[i]||0;
    if(n>o) slotsDiff.push((i+1)+' 环：'+o+' → '+n+' (+'+(n-o)+')');
  }
  var asiLv=[4,8,12,16,19];
  var hasASI = asiLv.indexOf(nlv)>=0;
  var html='<div class="levelup-hero"><div class="levelup-lv">'+nlv+'</div><div class="levelup-lb">LEVEL UP</div></div>';
  html += '<ul class="levelup-list">';
  html += '<li><span>最大 HP</span><b>'+oldHP+' → '+newHP+' (+'+pl+')</b></li>';
  if(newPB>oldPB) html += '<li><span>熟练加值</span><b>+'+oldPB+' → +'+newPB+'</b></li>';
  slotsDiff.forEach(function(d){ html += '<li><span>法术位</span><b>'+d+'</b></li>'; });
  if(hasASI) html += '<li><span>等级 '+nlv+' 特性</span><b>属性提升或专长</b></li>';
  html += '</ul>';
  dlg('升级至 '+nlv+' 级', '', [{l:'取消'}, {l:'确认升级', c:'p', f:function(){ doLevelUp(); }}], true);
  $('dgX').innerHTML = html;
};
function doLevelUp(){
  var lv=Number(S.level)||1;
  if(lv>=20) return;
  var oM=S.game.maxHP, oH=S.game.currentHP;
  S.level=lv+1;
  var nM=calcHP(), gn=nM-oM;
  var nH=oH+gn; if(oH>=oM) nH=nM;
  S.game.maxHP=nM; S.game.currentHP=Math.min(nH,nM);
  var ns=getSlots(S.cls, S.level), os=S.game.spellSlots||[], mg=[];
  for(var i=0;i<ns.length;i++){
    if(ns[i]>0){
      var ou=0;
      for(var j=0;j<os.length;j++) if(os[j].level===i+1){ ou=Math.min(os[j].used, ns[i]); break; }
      mg.push({level:i+1, max:ns[i], used:ou});
    }
  }
  S.game.spellSlots=mg;
  if(S.game.hitDice) S.game.hitDice.total=Number(S.level);
  var lvNow=Number(S.level), chaMod=modOf('cha');
  if(!S.game.resources) S.game.resources={};
  (CLASS_RESOURCES[S.cls]||[]).forEach(function(r){
    if(lvNow<r.lv) return;
    if(!S.game.resources[r.k]) S.game.resources[r.k]={n:r.n, max:r.max(lvNow,chaMod), used:0, reset:r.reset, d:r.d, pool:!!r.pool, poolUsed:0};
    else {
      var newMax=r.max(lvNow,chaMod);
      if(newMax>S.game.resources[r.k].max) S.game.resources[r.k].max=newMax;
    }
  });
  saveCur();
  $('trkTitle').textContent=S.name||'追踪';
  renderTrk();
}

// ==================== 商店 ====================
window.openShop = function(shopId){
  if(!SHOPS[shopId]) return;
  curShopId=shopId;
  var shop=SHOPS[shopId];
  $('shopIcon').textContent=shop.icon;
  $('shopTitle').textContent=shop.n;
  showPage('pgShop');
  renderShop();
};
window.exitShop = function(){ saveCur(); curShopId=null; showPage('pgTrk'); renderTrk(); };
function renderShop(){
  if(!curShopId || !SHOPS[curShopId]) return;
  var shop=SHOPS[curShopId], g=S.game;
  var totalGp=currencyGpValue(g.currency);
  var h='';
  h += '<div class="shop-hd"><div class="shop-hd-ic">'+shop.icon+'</div><div class="shop-hd-info"><div class="shop-hd-nm">'+shop.n+'</div><div class="shop-hd-d">'+(shop.desc||'')+'</div></div><div class="shop-hd-gold">'+totalGp.toFixed(2)+' GP</div></div>';
  var cats={};
  shop.items.forEach(function(item, idx){
    if(!cats[item.cat]) cats[item.cat]=[];
    cats[item.cat].push({item:item, idx:idx});
  });
  var catNames={weapon:'武器', armor:'护甲', shield:'盾牌', ammo:'弹药', consumable:'消耗品', gear:'道具'};
  var catOrder=['weapon','armor','shield','ammo','consumable','gear'];
  catOrder.forEach(function(c){
    if(!cats[c]) return;
    h += '<div class="tb"><div class="tt">'+(catNames[c]||c)+'</div>';
    cats[c].forEach(function(entry){
      var item=entry.item;
      var canBuy = totalGp >= item.p;
      h += '<div class="shop-item"><div class="shop-item-info"><div class="shop-item-nm">'+esc(item.n)+'</div>';
      if(item.d) h += '<div class="shop-item-d">'+esc(item.d)+'</div>';
      h += '<div class="shop-item-pr">'+price(item.p)+'</div></div>';
      h += '<button class="shop-buy" '+(canBuy?'':'disabled')+' onclick="buyItem(\''+curShopId+'\','+entry.idx+')">购买</button></div>';
    });
    h += '</div>';
  });
  $('shopMain').innerHTML=h;
}
window.buyItem = function(shopId, itemIdx){
  var shop=SHOPS[shopId]; if(!shop) return;
  var item=shop.items[itemIdx]; if(!item) return;
  var cpPrice=Math.round(item.p*100);
  if(!payCp(cpPrice)){ alert('金币不足！需要 '+price(item.p)); return; }
  if(item.cat==='ammo'){
    if(!S.game.ammo) S.game.ammo={};
    S.game.ammo[item.an]=(S.game.ammo[item.an]||0)+item.qty;
  } else if(item.cat==='consumable'){
    if(!S.game.consumables) S.game.consumables={};
    S.game.consumables[item.cn]=(S.game.consumables[item.cn]||0)+1;
  } else {
    if(!Array.isArray(S.game.inventory)) S.game.inventory=[];
    addInvItem(item);
  }
  saveCur();
  renderShop();
};
function payCp(cpNeed){
  if(!S.game.currency) S.game.currency={pp:0,gp:0,ep:0,sp:0,cp:0};
  var cur=S.game.currency;
  if(currencyToCp(cur) < cpNeed) return false;
  var order=['cp','sp','ep','gp','pp'];
  var metas={cp:1, sp:10, ep:50, gp:100, pp:1000};
  var remaining=cpNeed;
  for(var i=0;i<order.length;i++){
    if(remaining<=0) break;
    var k=order[i];
    var have=cur[k]||0;
    if(have===0) continue;
    var val=have*metas[k];
    if(val>=remaining){
      var useCoins=Math.ceil(remaining/metas[k]);
      cur[k]=have-useCoins;
      var change=useCoins*metas[k]-remaining;
      if(change>0){
        var chg=cpToCurrency(change);
        for(var kk in chg) cur[kk]=(cur[kk]||0)+chg[kk];
      }
      remaining=0;
    } else {
      cur[k]=0;
      remaining-=val;
    }
  }
  return remaining<=0;
}
function addInvItem(item){
  if(!Array.isArray(S.game.inventory)) S.game.inventory=[];
  for(var i=0;i<S.game.inventory.length;i++){
    if(S.game.inventory[i].n===item.n && S.game.inventory[i].cat===item.cat){
      S.game.inventory[i].q=(S.game.inventory[i].q||1)+1;
      return;
    }
  }
  S.game.inventory.push({n:item.n, q:1, cat:item.cat, k:item.k, d:item.d});
}
window.equipItem = function(idx){
  if(!S.game.inventory || !S.game.inventory[idx]) return;
  var item=S.game.inventory[idx];
  if(item.cat==='weapon' && item.k){
    var old=S.weapon;
    S.weapon=item.k;
    if(is2h(WEAPONS[item.k])) S.offhand='';
    if(item.q>1) item.q--; else S.game.inventory.splice(idx,1);
    if(old && WEAPONS[old]) addInvItem({n:WEAPONS[old].n, cat:'weapon', k:old, d:WEAPONS[old].d+' '+WEAPONS[old].dt});
  } else if(item.cat==='armor' && item.k){
    var oldA=S.armor;
    S.armor=item.k;
    if(item.q>1) item.q--; else S.game.inventory.splice(idx,1);
    if(oldA && ARMORS[oldA] && oldA!=='none') addInvItem({n:ARMORS[oldA].n, cat:'armor', k:oldA, d:'AC '+ARMORS[oldA].b});
  } else if(item.cat==='shield'){
    S.shield=1;
    if(item.q>1) item.q--; else S.game.inventory.splice(idx,1);
  }
  saveCur();
  renderTrk();
};

// ==================== 战斗引擎（DM 侧） ====================
window.combatCreate = function(){
  var name = prompt('遭遇名称：', '新遭遇');
  if(!name) return;
  COMBAT.encounter = newEncounter(name);
  COMBAT.active = true;
  dmLog('创建遭遇：'+name, 'sys');
  saveEncounter();
  renderDMHome();
};
window.combatStart = function(){
  if(!COMBAT.encounter) return;
  if(COMBAT.encounter.units.length === 0){ alert('没有参战单位'); return; }
  sortInitOrder();
  COMBAT.encounter.started = true;
  COMBAT.encounter.active = true;
  COMBAT.encounter.round = 1;
  COMBAT.encounter.currentUnitId = COMBAT.encounter.units[0].id;
  // 同步玩家的 inCombat
  COMBAT.encounter.units.forEach(function(u){
    if(u.ownerId){
      var c = CHARS.find(function(x){ return x.id===u.ownerId; });
      if(c && c.game){ c.game.inCombat = true; c.game.combatUnitId = u.id; }
    }
  });
  saveAll();
  dmLog('战斗开始！', 'sys');
  syncEncounterToPlayers();
  saveEncounter();
  renderDMHome();
};
window.combatNextTurn = function(){
  if(!COMBAT.encounter) return;
  var units = COMBAT.encounter.units.filter(function(u){ return u.hp>0; });
  if(units.length === 0){ combatEnd(); return; }
  var curIdx = units.findIndex(function(u){ return u.id===COMBAT.encounter.currentUnitId; });
  var nextIdx = curIdx+1;
  if(nextIdx>=units.length){
    COMBAT.encounter.round++;
    nextIdx=0;
    dmLog('第 '+COMBAT.encounter.round+' 轮', 'sys');
  }
  COMBAT.encounter.currentUnitId = units[nextIdx].id;
  var cur = units[nextIdx];
  cur.moveUsed = 0;
  cur.actionUsed = false;
  cur.bonusUsed = false;
  cur.reactionUsed = false;
  // 回合开始时处理状态
  if(cur.conditions.indexOf('poisoned')>=0){
    dmLog(cur.name+' 因中毒损失 1d6 HP', 'dmg');
  }
  dmLog('轮到：'+cur.name, 'info');
  syncEncounterToPlayers();
  saveEncounter();
  renderDMHome();
};
window.combatPrevTurn = function(){
  if(!COMBAT.encounter) return;
  var units = COMBAT.encounter.units.filter(function(u){ return u.hp>0; });
  var curIdx = units.findIndex(function(u){ return u.id===COMBAT.encounter.currentUnitId; });
  var prevIdx = curIdx-1;
  if(prevIdx<0){
    if(COMBAT.encounter.round>1){ COMBAT.encounter.round--; prevIdx=units.length-1; }
    else prevIdx=0;
  }
  COMBAT.encounter.currentUnitId = units[prevIdx].id;
  syncEncounterToPlayers();
  saveEncounter();
  renderDMHome();
};
window.combatEnd = function(){
  dlg('结束战斗', '确定结束本次遭遇？', [
    {l:'取消'},
    {l:'结束', c:'d', f:function(){
      COMBAT.encounter.active = false;
      COMBAT.encounter.started = false;
      // 清玩家的 inCombat
      CHARS.forEach(function(c){
        if(c.game){ c.game.inCombat=false; c.game.combatUnitId=''; }
      });
      saveAll();
      dmLog('战斗结束', 'sys');
      P2P.broadcast({type:'encounter-end'});
      saveEncounter();
      renderDMHome();
    }}
  ]);
};
window.combatRollAllInit = function(){
  if(!COMBAT.encounter) return;
  COMBAT.encounter.units.forEach(function(u){
    if(!u.initRolled){
      var roll=Math.floor(Math.random()*20)+1;
      u.init = u.init + roll;
      u.initRolled = true;
    }
  });
  sortInitOrder();
  dmLog('全体掷先攻', 'dice');
  syncEncounterToPlayers();
  saveEncounter();
  renderDMHome();
};
function sortInitOrder(){
  if(!COMBAT.encounter) return;
  COMBAT.encounter.units.sort(function(a,b){ return (b.init||0)-(a.init||0); });
}
window.combatAddMonster = function(monsterKey){
  if(!COMBAT.encounter){ alert('请先创建遭遇'); return; }
  var m = MONSTER_LIBRARY[monsterKey];
  if(!m) return;
  var count = prompt('添加几只？', '1');
  if(!count) return;
  var n = Math.max(1, Math.min(20, parseInt(count)||1));
  for(var i=0;i<n;i++){
    var u = newUnit({
      name: m.n+' '+String.fromCharCode(65+i),
      type: 'enemy',
      hp: m.hp, maxHP: m.hp,
      ac: m.ac, init: m.init,
      size: m.size||1,
      x: Math.floor(Math.random()*COMBAT.encounter.grid.w),
      y: Math.floor(Math.random()*COMBAT.encounter.grid.h)
    });
    u.notes = m.d||'';
    COMBAT.encounter.units.push(u);
  }
  dmLog('添加 '+n+' 只 '+m.n, 'sys');
  syncEncounterToPlayers();
  saveEncounter();
  renderDMHome();
};
window.combatAddUnit = function(type){
  if(!COMBAT.encounter){ alert('请先创建遭遇'); return; }
  var defaultName = type==='enemy'?'新敌人':(type==='npc'?'新NPC':'新单位');
  var h = '<div style="padding:0 4px">';
  h += '<div class="unit-label">名称</div><input class="unit-input" id="nuName" placeholder="'+defaultName+'">';
  h += '<div class="unit-grid" style="margin-top:10px">';
  h += '<div><div class="unit-label">HP</div><input class="unit-input" type="number" id="nuHP" value="10" min="1"></div>';
  h += '<div><div class="unit-label">AC</div><input class="unit-input" type="number" id="nuAC" value="12" min="1"></div>';
  h += '<div><div class="unit-label">先攻加值</div><input class="unit-input" type="number" id="nuInit" value="0"></div>';
  h += '<div><div class="unit-label">体型</div><input class="unit-input" type="number" id="nuSize" value="1" min="1" max="3"></div>';
  h += '</div></div>';
  dlg('添加 '+type, h, [
    {l:'取消'},
    {l:'添加', c:'p', f:function(){
      var u=newUnit({
        name: ($('nuName').value||defaultName).trim(),
        type: type,
        hp: parseInt($('nuHP').value)||10,
        maxHP: parseInt($('nuHP').value)||10,
        ac: parseInt($('nuAC').value)||12,
        init: parseInt($('nuInit').value)||0,
        size: parseInt($('nuSize').value)||1,
        x: Math.floor(Math.random()*COMBAT.encounter.grid.w),
        y: Math.floor(Math.random()*COMBAT.encounter.grid.h)
      });
      COMBAT.encounter.units.push(u);
      dmLog('添加单位：'+u.name, 'sys');
      syncEncounterToPlayers();
      saveEncounter();
      renderDMHome();
    }}
  ], true);
};
window.combatDamageUnit = function(unitId, delta){
  if(!COMBAT.encounter) return;
  var u = COMBAT.encounter.units.find(function(x){ return x.id===unitId; });
  if(!u) return;
  u.hp = Math.max(0, Math.min(u.maxHP, u.hp+delta));
  dmLog(u.name+' HP '+(delta>0?'+':'')+delta+' → '+u.hp, delta>0?'heal':'dmg');
  syncEncounterToPlayers();
  saveEncounter();
  renderDMHome();
};
window.combatToggleHidden = function(unitId){
  if(!COMBAT.encounter) return;
  var u = COMBAT.encounter.units.find(function(x){ return x.id===unitId; });
  if(!u) return;
  u.hidden = !u.hidden;
  syncEncounterToPlayers();
  saveEncounter();
  renderDMHome();
};
window.combatDeleteUnit = function(unitId){
  if(!COMBAT.encounter) return;
  dlg('删除单位','确定移除？',[
    {l:'取消'},
    {l:'删除', c:'d', f:function(){
      COMBAT.encounter.units = COMBAT.encounter.units.filter(function(u){ return u.id!==unitId; });
      syncEncounterToPlayers();
      saveEncounter();
      renderDMHome();
    }}
  ]);
};
window.combatEditUnit = function(unitId){
  if(!COMBAT.encounter) return;
  var u=COMBAT.encounter.units.find(function(x){ return x.id===unitId; });
  if(!u) return;
  var h='<div style="padding:0 4px">';
  h += '<div class="unit-label">名称</div><input class="unit-input" id="euName" value="'+esc(u.name)+'">';
  h += '<div class="unit-grid" style="margin-top:10px">';
  h += '<div><div class="unit-label">当前 HP</div><input class="unit-input" type="number" id="euHP" value="'+u.hp+'"></div>';
  h += '<div><div class="unit-label">最大 HP</div><input class="unit-input" type="number" id="euMaxHP" value="'+u.maxHP+'"></div>';
  h += '<div><div class="unit-label">AC</div><input class="unit-input" type="number" id="euAC" value="'+u.ac+'"></div>';
  h += '<div><div class="unit-label">先攻</div><input class="unit-input" type="number" id="euInit" value="'+u.init+'"></div>';
  h += '<div><div class="unit-label">X 坐标</div><input class="unit-input" type="number" id="euX" value="'+u.x+'"></div>';
  h += '<div><div class="unit-label">Y 坐标</div><input class="unit-input" type="number" id="euY" value="'+u.y+'"></div>';
  h += '</div>';
  h += '<div class="unit-label" style="margin-top:10px">备注</div><input class="unit-input" id="euNotes" value="'+esc(u.notes||'')+'">';
  h += '</div>';
  dlg('编辑单位', h, [
    {l:'取消'},
    {l:'保存', c:'p', f:function(){
      u.name = $('euName').value.trim()||u.name;
      u.maxHP = Math.max(1, parseInt($('euMaxHP').value)||1);
      u.hp = Math.max(0, Math.min(u.maxHP, parseInt($('euHP').value)||0));
      u.ac = Math.max(1, parseInt($('euAC').value)||10);
      u.init = parseInt($('euInit').value)||0;
      u.x = Math.max(0, Math.min(COMBAT.encounter.grid.w-1, parseInt($('euX').value)||0));
      u.y = Math.max(0, Math.min(COMBAT.encounter.grid.h-1, parseInt($('euY').value)||0));
      u.notes = $('euNotes').value.trim();
      sortInitOrder();
      syncEncounterToPlayers();
      saveEncounter();
      renderDMHome();
    }}
  ], true);
};
window.combatToggleCondition = function(unitId, condKey){
  if(!COMBAT.encounter) return;
  var u=COMBAT.encounter.units.find(function(x){ return x.id===unitId; });
  if(!u) return;
  var idx = u.conditions.indexOf(condKey);
  if(idx>=0) u.conditions.splice(idx,1); else u.conditions.push(condKey);
  syncEncounterToPlayers();
  saveEncounter();
  renderDMHome();
};
function saveEncounter(){
  if(!COMBAT.encounter) return;
  try { localStorage.setItem(DM_KEY+'_encounter', JSON.stringify(COMBAT.encounter)); } catch(e){}
}
function loadEncounter(){
  try {
    var r = localStorage.getItem(DM_KEY+'_encounter');
    if(r){
      COMBAT.encounter = JSON.parse(r);
      COMBAT.active = !!(COMBAT.encounter && COMBAT.encounter.active);
    }
  } catch(e){}
}
function syncEncounterToPlayers(){
  if(!COMBAT.encounter) return;
  if(!P2P.ready || DM.role!=='dm') return;
  var visible = {
    id: COMBAT.encounter.id,
    name: COMBAT.encounter.name,
    active: COMBAT.encounter.active,
    started: COMBAT.encounter.started,
    grid: COMBAT.encounter.grid,
    round: COMBAT.encounter.round,
    currentUnitId: COMBAT.encounter.currentUnitId,
    units: COMBAT.encounter.units.map(function(u){
      var isHidden = u.hidden && !COMBAT.showHidden;
      return {
        id: u.id, name: isHidden?'???':u.name, type:u.type,
        x: u.x, y: u.y, size: u.size, hidden: isHidden,
        hp: isHidden?null:u.hp, maxHP: isHidden?null:u.maxHP, ac: isHidden?null:u.ac,
        init: u.init, conditions: isHidden?[]:u.conditions, ownerId: u.ownerId
      };
    })
  };
  P2P.broadcast({type:'encounter-update', data: visible});
}

// ==================== 战术地图 ====================
window.openMap = function(){
  if(!COMBAT.encounter) return;
  showPage('pgMap');
  $('mapTitle').textContent = COMBAT.encounter.name || '战术地图';
  setTimeout(initMapCanvas, 50);
};
window.exitMap = function(){
  showPage(DM.role==='dm'?'pgDM':'pgTrk');
  if(DM.role==='dm') renderDMHome();
  else renderTrk();
};

function initMapCanvas(){
  var host = $('mapMain');
  if(!host) return;
  var enc = COMBAT.encounter;
  if(!enc) return;
  var isDM = DM.role==='dm';
  var h = '';
  h += '<div class="map-wrap" id="mapWrap">';
  h += '<canvas id="mapCanvas" class="map-canvas"></canvas>';
  h += '<div class="map-overlay">';
  h += '<button class="map-btn'+(COMBAT.showGrid?' on':'')+'" onclick="toggleMapGrid()">⊞</button>';
  h += '<button class="map-btn" onclick="mapZoom(1.25)">+</button>';
  h += '<button class="map-btn" onclick="mapZoom(0.8)">−</button>';
  h += '<button class="map-btn" onclick="mapCenter()">◎</button>';
  h += '</div>';
  h += '<div class="map-info" id="mapInfo"></div>';
  h += '</div>';

  if(isDM){
    h += '<div class="combat-toolbar">';
    h += '<button onclick="combatRollAllInit()">掷先攻</button>';
    if(enc.started) h += '<button class="pri" onclick="combatNextTurn()">下一回合</button>';
    else h += '<button class="pri" onclick="combatStart();initMapCanvas()">开始战斗</button>';
    h += '<button class="dan" onclick="combatEnd();initMapCanvas()">结束</button>';
    h += '</div>';
    h += '<div class="tb"><div class="tt">快速添加怪物</div><div class="shop-grid">';
    ['goblin','orc','wolf','bandit','skeleton','zombie','ogre','spider','kobold','hobgoblin'].forEach(function(mk){
      var m = MONSTER_LIBRARY[mk];
      h += '<button class="shop-btn" onclick="combatAddMonster(\''+mk+'\');initMapCanvas()"><span class="shop-ic">👹</span><span style="flex:1"><span class="shop-nm">'+m.n+'</span><span class="shop-sub">HP '+m.hp+' AC '+m.ac+'</span></span></button>';
    });
    h += '</div></div>';
    h += '<div class="tb"><div class="tt">单位列表</div>';
    h += renderUnitList(enc, isDM);
    h += '</div>';
  } else {
    h += '<div class="tb"><div class="tt">战斗视图</div>';
    h += '<div style="font-size:12px;color:#9a8f7d;text-align:center;margin-bottom:8px">第 '+enc.round+' 轮</div>';
    h += renderUnitList(enc, isDM);
    h += '</div>';
  }

  host.innerHTML = h;

  var canvas = $('mapCanvas');
  COMBAT.canvas = canvas;
  COMBAT.ctx = canvas.getContext('2d');
  // 设置 canvas 尺寸
  var wrap = $('mapWrap');
  var w = wrap.clientWidth;
  var viewSize = Math.min(w, 480);
  canvas.width = viewSize;
  canvas.height = viewSize;
  drawMap();
  bindMapEvents();
}

function renderUnitList(enc, isDM){
  var h = '<div class="init-list">';
  enc.units.forEach(function(u){
    var isCur = u.id===enc.currentUnitId;
    var isDead = u.hp<=0;
    var isHidden = u.hidden && !isDM;
    if(isHidden) return;
    var hpPct = u.maxHP>0 ? u.hp/u.maxHP*100 : 0;
    var hc = hpPct<=25?'c':(hpPct<=50?'w':'');
    var cls = 'init-row';
    if(isCur) cls += ' cur';
    if(isDead) cls += ' dead';
    if(u.hidden) cls += ' hidden';
    var init = (u.name||'?').trim().charAt(0)||'?';
    h += '<div class="'+cls+'" onclick="mapSelectUnit(\''+u.id+'\')">';
    h += '<div class="init-ic">'+esc(init)+'</div>';
    h += '<div class="init-info">';
    h += '<div class="init-nm">'+esc(u.name)+(u.hidden?' (隐藏)':'')+'</div>';
    h += '<div class="init-meta">HP '+u.hp+'/'+u.maxHP+' · AC '+u.ac+'</div>';
    h += '<div class="init-hp-bar"><i class="'+hc+'" style="width:'+hpPct+'%"></i></div>';
    if(u.conditions && u.conditions.length){
      h += '<div class="init-cond-tags">';
      u.conditions.forEach(function(c){
        var nm=''; COND.forEach(function(cc){ if(cc[0]===c) nm=cc[1]; });
        if(!nm) nm=c;
        h += '<span class="init-cond-tag">'+esc(nm)+'</span>';
      });
      h += '</div>';
    }
    h += '</div>';
    h += '<div class="init-init">'+(u.init>=0?'+':'')+u.init+'</div>';
    if(isDM){
      h += '<div class="init-ctrl">';
      h += '<button class="init-btn" onclick="event.stopPropagation();combatDamageUnit(\''+u.id+'\',-5);initMapCanvas()">-5</button>';
      h += '<button class="init-btn" onclick="event.stopPropagation();combatDamageUnit(\''+u.id+'\',5);initMapCanvas()">+5</button>';
      h += '</div>';
    }
    h += '</div>';
  });
  h += '</div>';
  return h;
}

function mapSelectUnit(id){
  COMBAT.selectedUnitId = (COMBAT.selectedUnitId===id)?null:id;
  drawMap();
  showUnitInfo();
}
function showUnitInfo(){
  var info = $('mapInfo');
  if(!info) return;
  if(!COMBAT.selectedUnitId){
    info.classList.remove('on');
    return;
  }
  var u = COMBAT.encounter.units.find(function(x){ return x.id===COMBAT.selectedUnitId; });
  if(!u) return;
  info.innerHTML = '<div class="map-info-nm">'+esc(u.name)+'</div><div class="map-info-d">HP '+u.hp+'/'+u.maxHP+' · AC '+u.ac+' · 先攻 '+u.init+'</div>';
  info.classList.add('on');
}

function drawMap(){
  var canvas = COMBAT.canvas;
  if(!canvas) return;
  var ctx = canvas.getContext('2d');
  var enc = COMBAT.encounter;
  if(!enc) return;
  var W = canvas.width, H = canvas.height;
  var cell = COMBAT.cellPx * COMBAT.zoom;
  var panX = COMBAT.panX, panY = COMBAT.panY;

  ctx.fillStyle = '#0a0805';
  ctx.fillRect(0, 0, W, H);

  // 网格
  if(COMBAT.showGrid){
    ctx.strokeStyle = 'rgba(58,49,40,.5)';
    ctx.lineWidth = 1;
    var startX = (panX % cell);
    var startY = (panY % cell);
    for(var x=startX; x<=W; x+=cell){
      ctx.beginPath(); ctx.moveTo(x,0); ctx.lineTo(x,H); ctx.stroke();
    }
    for(var y=startY; y<=H; y+=cell){
      ctx.beginPath(); ctx.moveTo(0,y); ctx.lineTo(W,y); ctx.stroke();
    }
  }

  // 边界
  var totalW = enc.grid.w * cell;
  var totalH = enc.grid.h * cell;
  ctx.strokeStyle = 'rgba(201,162,39,.3)';
  ctx.lineWidth = 2;
  ctx.strokeRect(panX, panY, totalW, totalH);

  // 单位
  enc.units.forEach(function(u){
    if(u.hp<=0 && u.type!=='player') {
      // 死亡单位用灰色
    }
    var cx = panX + (u.x + u.size/2) * cell;
    var cy = panY + (u.y + u.size/2) * cell;
    var r = u.size * cell * 0.42;
    // 是否可见
    var hidden = u.hidden && DM.role!=='dm';
    ctx.globalAlpha = hidden ? 0.3 : 1;
    // 圆
    ctx.fillStyle = u.color || UNIT_COLORS[u.type] || '#666';
    ctx.beginPath();
    ctx.arc(cx, cy, r, 0, Math.PI*2);
    ctx.fill();
    // 描边
    ctx.strokeStyle = (u.id===COMBAT.selectedUnitId) ? '#fff' :
                      (u.id===enc.currentUnitId ? '#e8c95a' : 'rgba(20,17,14,.8)');
    ctx.lineWidth = (u.id===enc.currentUnitId || u.id===COMBAT.selectedUnitId) ? 3 : 1.5;
    ctx.stroke();
    // HP 圆环
    if(u.maxHP>0 && u.hp>0 && u.hp<u.maxHP){
      ctx.strokeStyle = u.hp/u.maxHP<=0.25 ? '#e05252' : (u.hp/u.maxHP<=0.5 ? '#e0a33c' : '#7fc98a');
      ctx.lineWidth = 3;
      ctx.beginPath();
      ctx.arc(cx, cy, r+2, -Math.PI/2, -Math.PI/2 + Math.PI*2*(u.hp/u.maxHP));
      ctx.stroke();
    }
    // 名字
    if(!hidden){
      ctx.fillStyle = '#e8e0d0';
      ctx.font = Math.max(9, Math.min(14, cell*0.32))+'px -apple-system,sans-serif';
      ctx.textAlign = 'center';
      ctx.textBaseline = 'middle';
      ctx.fillText(u.name.substring(0, 4), cx, cy);
    }
    ctx.globalAlpha = 1;
  });
}

function bindMapEvents(){
  var canvas = COMBAT.canvas;
  if(!canvas) return;
  canvas.onmousedown = canvas.ontouchstart = function(e){
    e.preventDefault();
    var rect = canvas.getBoundingClientRect();
    var pt = getPoint(e, rect);
    COMBAT.touchStartX = pt.x;
    COMBAT.touchStartY = pt.y;
    COMBAT.touchDragging = false;
    if(e.touches && e.touches.length===2){
      var t1=e.touches[0], t2=e.touches[1];
      var dx=t1.clientX-t2.clientX, dy=t1.clientY-t2.clientY;
      COMBAT.pinchStartDist = Math.sqrt(dx*dx+dy*dy);
      COMBAT.pinchStartZoom = COMBAT.zoom;
    }
  };
  canvas.onmousemove = canvas.ontouchmove = function(e){
    e.preventDefault();
    if(!COMBAT.touchStartX && !COMBAT.touchStartY) return;
    var rect = canvas.getBoundingClientRect();
    if(e.touches && e.touches.length===2){
      var t1=e.touches[0], t2=e.touches[1];
      var dx=t1.clientX-t2.clientX, dy=t1.clientY-t2.clientY;
      var dist = Math.sqrt(dx*dx+dy*dy);
      if(COMBAT.pinchStartDist>0){
        COMBAT.zoom = Math.max(0.3, Math.min(3, COMBAT.pinchStartZoom * dist / COMBAT.pinchStartDist));
        drawMap();
      }
      return;
    }
    var pt = getPoint(e, rect);
    var dx2 = pt.x - COMBAT.touchStartX;
    var dy2 = pt.y - COMBAT.touchStartY;
    if(Math.abs(dx2)>3 || Math.abs(dy2)>3){
      COMBAT.touchDragging = true;
      COMBAT.panX += dx2;
      COMBAT.panY += dy2;
      COMBAT.touchStartX = pt.x;
      COMBAT.touchStartY = pt.y;
      drawMap();
    }
  };
  canvas.onmouseup = canvas.ontouchend = function(e){
    e.preventDefault();
    if(!COMBAT.touchDragging){
      var rect = canvas.getBoundingClientRect();
      var pt = getPoint(e.changedTouches ? e.changedTouches[0] : e, rect);
      handleMapClick(pt.x, pt.y);
    }
    COMBAT.touchStartX = 0;
    COMBAT.touchStartY = 0;
    COMBAT.touchDragging = false;
    COMBAT.pinchStartDist = 0;
  };
}
function getPoint(e, rect){
  var x = (e.clientX||0) - rect.left;
  var y = (e.clientY||0) - rect.top;
  return {x:x, y:y};
}
function handleMapClick(x, y){
  var enc = COMBAT.encounter;
  if(!enc) return;
  var cell = COMBAT.cellPx * COMBAT.zoom;
  // 找被点到的单位
  var clicked = null;
  for(var i=enc.units.length-1;i>=0;i--){
    var u = enc.units[i];
    var cx = COMBAT.panX + (u.x + u.size/2) * cell;
    var cy = COMBAT.panY + (u.y + u.size/2) * cell;
    var r = u.size * cell * 0.5;
    if(Math.hypot(x-cx, y-cy) <= r){
      clicked = u; break;
    }
  }
  if(clicked){
    if(COMBAT.selectedUnitId && COMBAT.selectedUnitId !== clicked.id && DM.role==='dm'){
      // 有选中单位，且点了另一个位置 → 移动选中单位到这里
      var sel = enc.units.find(function(u){ return u.id===COMBAT.selectedUnitId; });
      if(sel){
        var gx = Math.floor((x - COMBAT.panX) / cell - sel.size/2);
        var gy = Math.floor((y - COMBAT.panY) / cell - sel.size/2);
        sel.x = Math.max(0, Math.min(enc.grid.w-sel.size, gx));
        sel.y = Math.max(0, Math.min(enc.grid.h-sel.size, gy));
        syncEncounterToPlayers();
        saveEncounter();
        initMapCanvas();
        return;
      }
    }
    mapSelectUnit(clicked.id);
  } else {
    COMBAT.selectedUnitId = null;
    drawMap();
    showUnitInfo();
  }
}
window.toggleMapGrid = function(){ COMBAT.showGrid = !COMBAT.showGrid; drawMap(); initMapCanvas(); };
window.mapZoom = function(f){ COMBAT.zoom = Math.max(0.3, Math.min(3, COMBAT.zoom*f)); drawMap(); };
window.mapCenter = function(){ COMBAT.panX=0; COMBAT.panY=0; COMBAT.zoom=1; drawMap(); };

// ==================== P2P 层 · V8 DM 主机稳定连接 ====================
P2P._clearTimers = function(){
  if(this.reconnectTimer){ clearTimeout(this.reconnectTimer); this.reconnectTimer=null; }
  if(this.heartbeatTimer){ clearInterval(this.heartbeatTimer); this.heartbeatTimer=null; }
};
P2P._peerOptions = function(){
  return {
    debug: 0,
    pingInterval: 5000,
    config: {
      iceServers: [
        {urls:'stun:stun.l.google.com:19302'},
        {urls:'stun:stun1.l.google.com:19302'}
      ],
      sdpSemantics:'unified-plan'
    }
  };
};
P2P._bindConn = function(conn, inbound){
  var self=this;
  if(!conn) return;
  conn.on('open', function(){
    self.reconnectAttempt=0;
    if(self.role==='player'){
      self.hostConn=conn;
      self._cancelJoinDeadline();
      self._status('connected','已连接 DM');
      self._startHeartbeat();
    } else {
      if(self.conns.indexOf(conn)<0) self.conns.push(conn);
      self._status('player-join','玩家已连接');
    }
  });
  conn.on('data', function(data){ self._handle(data,conn); });
  conn.on('close', function(){
    if(self.role==='dm'){
      self.conns=self.conns.filter(function(c){return c!==conn;});
      if(self.onPlayerLeave) self.onPlayerLeave(conn);
    } else if(!self.manualClose){
      self.hostConn=null;
      self._status('reconnecting','与 DM 断开，正在自动重连…');
      self._schedulePlayerReconnect();
    }
  });
  conn.on('error', function(e){
    if(self.role==='player' && !self.manualClose){
      self._status('reconnecting','连接波动，正在恢复…');
      self._schedulePlayerReconnect();
    }
  });
};
// V7: finite connection diagnostics; never leave players waiting indefinitely.
P2P._cancelJoinDeadline=function(){if(this.joinDeadline){clearTimeout(this.joinDeadline);this.joinDeadline=null;}};
P2P._joinFailed=function(reason){
  this._cancelJoinDeadline();
  if(this.role!=='player'||this.manualClose)return;
  this._status('error',reason);
  this._clearTimers();
  this.manualClose=true;
  try{if(this.hostConn)this.hostConn.close()}catch(e){}
  try{if(this.peer)this.peer.destroy()}catch(e){}
  this.hostConn=null;this.peer=null;this.ready=false;
};
P2P._joinDeadlineStart=function(){
  this._cancelJoinDeadline();var self=this;
  this.joinDeadline=setTimeout(function(){
    if(self.role==='player'&&!(self.hostConn&&self.hostConn.open))
      self._joinFailed('连接超时（18秒）：未建立到 DM 的数据通道。请确认 DM 已显示「房间就绪」，双方能访问 PeerJS 信令服务。');
  },18000);
};
P2P._connectHost = function(){
  if(this.role!=='player' || !this.peer || this.peer.destroyed || !this.peer.open) return;
  if(this.hostConn && this.hostConn.open) return;
  var dmId='dnd5r-dm-'+this.roomCode.toLowerCase();
  try{
    var conn=this.peer.connect(dmId,{serialization:'json',metadata:{room:this.roomCode},reliable:false});
    this.hostConn=conn;
    this._bindConn(conn,false);
  }catch(e){ this._schedulePlayerReconnect(); }
};
P2P._schedulePlayerReconnect = function(){
  if(this.role!=='player' || this.manualClose || this.reconnectTimer) return;
  var self=this;
  var delays=[1000,2000,4000,8000,12000];
  var delay=delays[Math.min(this.reconnectAttempt,delays.length-1)];
  this.reconnectAttempt++;
  this._status('reconnecting','正在重连 DM · 第 '+this.reconnectAttempt+' 次…');
  this.reconnectTimer=setTimeout(function(){
    self.reconnectTimer=null;
    if(self.manualClose || self.role!=='player') return;
    if(!self.peer || self.peer.destroyed){ self._rebuildPlayerPeer(); return; }
    if(self.peer.disconnected){
      try{ self.peer.reconnect(); }catch(e){ self._rebuildPlayerPeer(); return; }
      setTimeout(function(){ self._connectHost(); },700);
    } else self._connectHost();
  },delay);
};
P2P._rebuildPlayerPeer = function(){
  if(this.role!=='player' || this.manualClose) return;
  var code=this.roomCode, self=this;
  try{ if(this.peer) this.peer.destroy(); }catch(e){}
  this.peer=null; this.hostConn=null;
  var id='dnd5r-pl-'+Math.random().toString(36).substr(2,10);
  try{
    this.peer=new Peer(id,this._peerOptions());
    this._bindPeerEvents('player',code);
  }catch(e){ this._schedulePlayerReconnect(); }
};
P2P._startHeartbeat = function(){
  var self=this;
  if(this.heartbeatTimer) clearInterval(this.heartbeatTimer);
  this.heartbeatTimer=setInterval(function(){
    if(self.role==='player'){
      if(self.hostConn && self.hostConn.open) self.send({type:'ping',t:Date.now()});
      else self._schedulePlayerReconnect();
    } else if(self.role==='dm'){
      self.conns.forEach(function(c){ if(c.open) self.sendTo({type:'ping',t:Date.now()},c); });
    }
  },8000);
};
P2P._bindPeerEvents = function(role,roomCode){
  var self=this;
  this.peer.on('open',function(){
    self.ready=true; self._status('ready','已就绪');
    if(self.onOpen) self.onOpen();
    self._startHeartbeat();
    if(role==='player') self._connectHost();
  });
  this.peer.on('connection',function(conn){
    if(self.role!=='dm'){ try{conn.close();}catch(e){} return; }
    self._bindConn(conn,true);
  });
  this.peer.on('error',function(e){
    var t=e&&e.type||'';
    if(role==='player' && t==='peer-unavailable'){
      self._joinFailed('找不到房间：DM 不在线、房间码有误，或双方使用的信令服务不同。');return;
    }
    if(role==='dm' && t==='unavailable-id'){
      self._status('error','房间码已被占用，请关闭房间并重新创建。');return;
    }
    if(role==='player' && (t==='network'||t==='socket-error'||t==='socket-closed'||t==='webrtc')){
      var msg=t==='peer-unavailable'?'暂时找不到 DM，确认 DM 房间仍开着…':'网络连接波动，正在恢复…';
      self._status('reconnecting',msg); self._schedulePlayerReconnect(); return;
    }
    self._status('error','P2P 错误：'+(e.message||t||'未知错误'));
    if(self.onError) self.onError(e);
  });
  this.peer.on('disconnected',function(){
    if(self.manualClose) return;
    self._status('reconnecting','信令断开，正在恢复…');
    try{ self.peer.reconnect(); }catch(e){ if(role==='player') self._schedulePlayerReconnect(); }
  });
};
P2P.init = function(role,roomCode){
  this.destroy();
  this.manualClose=false; this.role=role; this.roomCode=roomCode; this.reconnectAttempt=0;
  if(role==='player')this._joinDeadlineStart();
  if(typeof Peer==='undefined'){ this._status('error','PeerJS 未加载'); return; }
  var id=(role==='dm')?('dnd5r-dm-'+roomCode.toLowerCase()):('dnd5r-pl-'+Math.random().toString(36).substr(2,10));
  try{ this.peer=new Peer(id,this._peerOptions()); this._bindPeerEvents(role,roomCode); }
  catch(e){ this._status('error','P2P 初始化失败：'+e.message); }
};
P2P._handle = function(data,conn){
  this.msgCount++;
  if(data && data.type==='ping'){ this.sendTo({type:'pong',t:data.t},conn); return; }
  if(data && data.type==='pong'){ this.lastLatency=Date.now()-data.t; return; }
  if(this.onData) this.onData(data,conn);
};
P2P.sendTo = function(data,conn){ if(conn&&conn.open){try{conn.send(data);}catch(e){}} };
P2P.send = function(data){ if(this.role==='player'&&this.hostConn&&this.hostConn.open){try{this.hostConn.send(data);}catch(e){this._schedulePlayerReconnect();}} };
P2P.broadcast = function(data){ if(this.role!=='dm')return; this.conns.slice().forEach(function(c){if(c.open)try{c.send(data);}catch(e){}}); };
P2P._status = function(state,msg){ if(this.onStatus)this.onStatus(state,msg); };
P2P.destroy = function(){
  this.manualClose=true; this._cancelJoinDeadline(); this._clearTimers();
  this.conns.forEach(function(c){try{c.close();}catch(e){}});
  if(this.hostConn)try{this.hostConn.close();}catch(e){}
  if(this.peer)try{this.peer.destroy();}catch(e){}
  this.peer=null; this.conns=[]; this.hostConn=null; this.ready=false; this.role=null; this.roomCode=null; this.reconnectAttempt=0;
};

// ==================== DM 模式 ====================
function dmLoadNote(){
  try {
    var r=localStorage.getItem(DM_KEY);
    if(r){ var o=JSON.parse(r); if(o.note) DM.note = o.note; }
  } catch(e){}
}
function dmSaveNote(){
  try { localStorage.setItem(DM_KEY, JSON.stringify({note: DM.note})); } catch(e){}
}
function dmLog(text, type){
  DM.log.unshift({t: new Date().toLocaleTimeString('zh-CN',{hour12:false}), m:text, k:type||'info'});
  if(DM.log.length > 200) DM.log = DM.log.slice(0, 200);
}
function dmStatusText(){
  var map = {'off':'未启动','wait':'等待连接…','ok':'已连接','error':'连接错误'};
  return map[DM.statusState] || DM.statusText;
}

window.openDMHome = function(){
  dmLoadNote();
  loadEncounter();
  showPage('pgDM');
  renderDMHome();
  mountVoiceBarDM();
};
window.exitDM = function(){
  if(DM.active){
    dlg('退出 DM 模式','确定要断开所有连接并退出吗？',[
      {l:'取消'},
      {l:'退出', c:'d', f:function(){
        if(VOICE.enabled) voiceLeave();
        P2P.destroy();
        DM.active=false;
        DM.role=null;
        DM.roomCode=null;
        DM.players=[];
        dmSaveNote();
        renderHome();
        showPage('pgHome');
      }}
    ]);
    return;
  }
  dmSaveNote();
  P2P.destroy();
  DM.active=false;
  DM.role=null;
  DM.roomCode=null;
  DM.players=[];
  renderHome();
  showPage('pgHome');
};

function renderDMHome(){
  var h='';
  if(!DM.active){
    h += '<div class="tb"><div class="tt">DM 模式</div>';
    h += '<div style="font-size:13px;color:#9a8f7d;line-height:1.7;margin-bottom:14px">通过 P2P 直连，DM 可以实时查看并远程修改玩家的 HP、金币、状态、经验，并共享战斗地图。无需服务器。</div>';
    h += '<button class="hbt dm" style="width:100%;margin-bottom:10px" onclick="dmCreateRoom()">⚔ 创建一个房间（作为 DM）</button>';
    h += '<button class="hbt" style="width:100%" onclick="dmShowJoinDialog()">🎲 加入一个房间（作为玩家）</button>';
    h += '</div>';
    h += '<div class="tb"><div class="tt">DM 笔记</div>';
    h += '<textarea class="note-area" id="dmNoteArea" placeholder="记录剧情、NPC、伏笔…" oninput="dmOnNoteInput()">'+esc(DM.note||'')+'</textarea>';
    h += '<div class="note-meta" id="dmNoteMeta">自动保存</div>';
    h += '</div>';
  } else if(DM.role==='dm'){
    h += renderDMRoom();
  } else {
    h += renderDMPlayerRoom();
  }
  $('dmMain').innerHTML = h;
}

function renderDMRoom(){
  var h='';
  var dotCls = DM.statusState==='ok'?'ok':(DM.statusState==='wait'?'wait':'');
  h += '<div class="dm-status"><div class="dm-dot '+dotCls+'"></div><div class="dm-status-text">'+esc(dmStatusText());
  h += '<div class="dm-status-sub">'+DM.players.length+' 名玩家 · 消息 '+P2P.msgCount+' 条'+(P2P.lastLatency!=null?' · 延迟 '+P2P.lastLatency+'ms':'')+'</div>';
  h += '</div></div>';
  h += '<div class="room-code">'+DM.roomCode+'</div>';
  h += '<div style="font-size:12px;color:#9a8f7d;text-align:center;margin-bottom:14px">让玩家在「DM 模式 → 加入房间」输入此码</div>';

  // 战斗入口
  if(COMBAT.encounter){
    h += '<div class="tb"><div class="tt">战斗</div>';
    h += '<div style="font-size:12px;color:#9a8f7d;margin-bottom:8px">'+esc(COMBAT.encounter.name)+' · '+COMBAT.encounter.units.length+' 单位'+(COMBAT.encounter.started?' · 第 '+COMBAT.encounter.round+' 轮':'')+'</div>';
    h += '<div class="rst" style="margin-top:0"><button class="rsb l" onclick="openMap()">🗺 打开地图</button>';
    if(COMBAT.encounter.started) h += '<button class="rsb s" onclick="combatNextTurn()">下一回合</button>';
    else h += '<button class="rsb s" onclick="combatStart()">开始战斗</button>';
    h += '</div>';
    h += '<div class="rst"><button class="rsb r" onclick="combatEnd()">结束战斗</button></div>';
    h += '</div>';
  } else {
    h += '<div class="tb"><div class="tt">战斗</div><button class="hbt" style="width:100%" onclick="combatCreate()">✦ 创建遭遇</button></div>';
  }

  // 玩家列表
  h += '<div class="tb"><div class="tt">玩家</div>';
  if(DM.players.length === 0){
    h += '<div class="empty-tip">还没有玩家加入</div>';
  } else {
    DM.players.forEach(function(p, idx){
      h += renderDMPlayerCard(p, idx);
    });
  }
  h += '</div>';

  // 骰子
  h += '<div class="tb"><div class="tt">DM 掷骰（广播）</div><div class="dice-grid">';
  [4,6,8,10,12,20,100].forEach(function(d){
    h += '<button class="dice-btn" onclick="dmRollBroadcast('+d+')">d'+d+'</button>';
  });
  h += '<button class="dice-btn" onclick="dmRollBroadcast(20, true)">d20 优势</button>';
  h += '<button class="dice-btn" onclick="dmRollBroadcast(20, false, true)">d20 劣势</button>';
  h += '</div>';
  h += '<div class="ecr"><input class="eci" type="text" id="dmDiceExpr" placeholder="自定义 例如 2d6+3" style="flex:1"><button class="ecb a" onclick="dmRollExpr($(\'dmDiceExpr\').value)">掷骰</button></div></div>';

  // 广播
  h += '<div class="tb"><div class="tt">广播消息</div><div class="ecr"><input class="eci" type="text" id="dmBroadcastMsg" placeholder="输入要广播的文本…" style="flex:1"><button class="ecb a" onclick="dmBroadcastMsg()">发送</button></div></div>';

  // 玩家申请
  var pending = DM.pendingRequests || [];
  if(pending.length > 0){
    h += '<div class="tb"><div class="tt">玩家申请 ('+pending.length+')</div>';
    pending.forEach(function(req, idx){
      h += '<div class="dm-player-card" style="border-color:rgba(201,162,39,.5)">';
      h += '<div style="font-size:13px;color:#e8c95a;margin-bottom:8px">'+esc(req.name)+'：'+esc(req.desc)+'</div>';
      h += '<div class="rst" style="margin-top:0"><button class="rsb l" onclick="dmApproveReq('+idx+')">同意</button><button class="rsb r" onclick="dmDenyReq('+idx+')">拒绝</button></div>';
      h += '</div>';
    });
    h += '</div>';
  }

  // 日志
  h += '<div class="tb"><div class="tt">战斗日志</div><div class="dm-log" id="dmLog">';
  if(DM.log.length === 0) h += '<div style="color:#5b5245;font-style:italic;padding:10px;text-align:center">暂无日志</div>';
  else DM.log.forEach(function(e){
    h += '<div class="dm-log-entry"><span class="dm-log-t">'+esc(e.t)+'</span><span class="dm-log-m '+(e.k||'info')+'">'+esc(e.m)+'</span></div>';
  });
  h += '</div><div class="rst" style="margin-top:10px"><button class="rsb r" onclick="dmClearLog()">清空日志</button></div></div>';

  // 连接诊断
  h += '<div class="tb"><div class="tt">连接诊断</div><div class="conn-panel">';
  h += '<div class="conn-row"><span>状态</span><b>'+esc(dmStatusText())+'</b></div>';
  h += '<div class="conn-row"><span>房间码</span><b>'+DM.roomCode+'</b></div>';
  h += '<div class="conn-row"><span>玩家数</span><b>'+DM.players.length+'</b></div>';
  h += '<div class="conn-row"><span>消息数</span><b>'+P2P.msgCount+'</b></div>';
  h += '<div class="conn-row"><span>延迟</span><b>'+(P2P.lastLatency!=null?P2P.lastLatency+' ms':'—')+'</b></div>';
  h += '</div>';
  h += '<div class="rst" style="margin-top:8px"><button class="rsb s" onclick="dmPing()">测试延迟</button><button class="rsb r" onclick="dmCloseRoom()">关闭房间</button></div>';
  h += '</div>';

  // 笔记
  h += '<div class="tb"><div class="tt">DM 笔记</div><textarea class="note-area" id="dmNoteArea" oninput="dmOnNoteInput()">'+esc(DM.note||'')+'</textarea><div class="note-meta" id="dmNoteMeta">自动保存</div></div>';

  // 语音
  h += '<div class="tb"><div class="tt">语音</div><div style="font-size:12.5px;color:#9a8f7d;line-height:1.7;margin-bottom:10px">DM 侧可同时收听所有玩家语音。</div>';
  h += '<button class="voice-join" id="voiceJoinBtn" onclick="voiceToggle()">'+(VOICE.enabled?'🎙 关闭语音':'🎙 开启语音（收听所有玩家）')+'</button>';
  h += '</div>';

  return h;
}

function renderDMPlayerCard(p, idx){
  var d = p.data || {};
  var hp = d.currentHP||0;
  var maxHP = d.maxHP||1;
  var pct = maxHP>0 ? Math.max(0, Math.min(100, hp/maxHP*100)) : 0;
  var hc = pct<=25?'c':(pct<=50?'w':'');
  var cn = d.cls && CLASSES[d.cls] ? CLASSES[d.cls].n : '';
  var sp = d.species && SPECIES[d.species] ? SPECIES[d.species].n : '';
  var meta = [sp, cn, '等级 '+(d.level||1)].filter(Boolean).join(' · ');
  var init = (d.name||'?').trim().charAt(0)||'?';
  var h = '';
  h += '<div class="dm-player-card">';
  h += '<div class="dm-player-hd"><div class="dm-player-av">'+esc(init)+'</div>';
  h += '<div class="dm-player-info"><div class="dm-player-nm">'+esc(d.name||'无名冒险者')+'</div><div class="dm-player-mt">'+esc(meta)+'</div></div>';
  h += '<div class="dm-player-hp">'+hp+'/'+maxHP+'</div></div>';
  h += '<div class="dm-hp-bar"><i class="'+hc+'" style="width:'+pct+'%"></i></div>';
  h += '<div class="dm-ctrl-grid">';
  h += '<button class="d" onclick="dmHpDelta('+idx+',-5)">-5</button>';
  h += '<button class="d" onclick="dmHpDelta('+idx+',-10)">-10</button>';
  h += '<button class="h" onclick="dmHpDelta('+idx+',5)">+5</button>';
  h += '<button class="h" onclick="dmHpDelta('+idx+',10)">+10</button>';
  h += '</div>';
  h += '<div class="dm-ctrl-2">';
  h += '<button class="g" onclick="dmGoldDelta('+idx+',10)">+10 GP</button>';
  h += '<button class="g" onclick="dmGoldDelta('+idx+',-10)">-10 GP</button>';
  h += '<button class="c" onclick="dmExpDelta('+idx+',50)">+50 EXP</button>';
  h += '</div>';
  h += '<div class="dm-ctrl-2">';
  h += '<button onclick="dmFullHeal('+idx+')">满血</button>';
  h += '<button onclick="dmAddCondition('+idx+')">+ 状态</button>';
  h += '<button onclick="dmKickPlayer('+idx+')">踢出</button>';
  h += '</div>';
  var conds = d.conditions||[];
  if(conds.length){
    h += '<div class="cg" style="margin-top:8px">';
    conds.forEach(function(c){
      var nm=''; COND.forEach(function(cc){ if(cc[0]===c) nm=cc[1]; });
      if(!nm) nm=c;
      h += '<span class="cck on">'+esc(nm)+'</span>';
    });
    h += '</div>';
  }
  h += '</div>';
  return h;
}

function renderDMPlayerRoom(){
  var h='';
  var dotCls = DM.statusState==='ok'?'ok':(DM.statusState==='wait'?'wait':'');
  h += '<div class="dm-status"><div class="dm-dot '+dotCls+'"></div><div class="dm-status-text">'+esc(dmStatusText());
  h += '<div class="dm-status-sub">房间 '+DM.roomCode+' · 消息 '+P2P.msgCount+(P2P.lastLatency!=null?' · 延迟 '+P2P.lastLatency+'ms':'')+'</div>';
  h += '</div></div>';

  if(S){
    var d = packCharData();
    h += '<div class="tb"><div class="tt">我的角色</div>';
    h += '<div style="font-size:14px;color:#e8c95a;font-weight:600">'+esc(d.name)+'</div>';
    h += '<div style="font-size:12px;color:#9a8f7d;margin-top:4px">HP '+d.currentHP+'/'+d.maxHP+'</div>';
    h += '</div>';
  }

  // 玩家申请
  h += renderPlayerRequests();

  // 战斗视图
  if(COMBAT.encounter && COMBAT.encounter.active){
    h += '<div class="tb"><div class="tt">战斗</div>';
    h += '<div style="font-size:12px;color:#9a8f7d;text-align:center;margin-bottom:8px">'+esc(COMBAT.encounter.name)+' · 第 '+COMBAT.encounter.round+' 轮</div>';
    h += '<button class="rsb l" style="width:100%" onclick="openMap()">🗺 打开地图</button>';
    h += '</div>';
  }

  // 日志
  h += '<div class="tb"><div class="tt">DM 消息</div><div class="dm-log" id="dmLog">';
  if(DM.log.length === 0) h += '<div style="color:#5b5245;font-style:italic;padding:10px;text-align:center">暂无</div>';
  else DM.log.forEach(function(e){
    h += '<div class="dm-log-entry"><span class="dm-log-t">'+esc(e.t)+'</span><span class="dm-log-m '+(e.k||'info')+'">'+esc(e.m)+'</span></div>';
  });
  h += '</div></div>';

  // 发送消息
  h += '<div class="tb"><div class="tt">发送给 DM</div><div class="ecr"><input class="eci" type="text" id="dmChatMsg" placeholder="输入消息…" style="flex:1"><button class="ecb a" onclick="dmSendChat()">发送</button></div></div>';

  // 语音
  h += '<div class="tb"><div class="tt">语音</div>';
  h += '<button class="voice-join" id="voiceJoinBtn" onclick="voiceToggle()">'+(VOICE.enabled?'🎙 关闭语音':'🎙 加入语音（对 DM 说话）')+'</button>';
  h += '</div>';

  // 操作
  h += '<div class="tb"><div class="tt">操作</div><div class="rst" style="margin-top:0"><button class="rsb s" onclick="dmSyncToDM()">重新同步角色</button><button class="rsb r" onclick="dmLeaveRoom()">离开房间</button></div></div>';

  return h;
}

// DM 创建/加入
window.dmCreateRoom = function(){
  var code = genRoomCode();
  DM.active = true;
  DM.role = 'dm';
  DM.roomCode = code;
  DM.players = [];
  DM.pendingRequests = [];
  DM.statusState = 'wait';
  DM.statusText = '等待玩家加入…';
  dmLog('房间已创建：'+code, 'sys');
  P2P.onStatus = function(state, msg){
    if(state==='ready'){ DM.statusState='ok'; DM.statusText='房间已就绪 · '+code; }
    else if(state==='player-join'){ DM.statusState='ok'; DM.statusText='玩家已连接'; }
    else if(state==='error'){ DM.statusState='error'; DM.statusText=msg; }
    if(DM.role==='dm') renderDMHome();
  };
  P2P.onData = function(data, conn){ dmHandlePlayerData(data, conn); };
  P2P.onPlayerLeave = function(conn){
    DM.players = DM.players.filter(function(p){ return p.conn!==conn; });
    dmLog('玩家断开', 'sys');
    renderDMHome();
  };
  P2P.onError = function(e){ dmLog('P2P 错误：'+e.message, 'sys'); };
  P2P.init('dm', code);
  renderDMHome();
  mountVoiceBarDM();
};
window.dmCloseRoom = function(){
  dlg('关闭房间','所有玩家将断开连接。确定？',[
    {l:'取消'},
    {l:'关闭', c:'d', f:function(){
      P2P.broadcast({type:'room-closed'});
      setTimeout(function(){
        if(VOICE.enabled) voiceLeave();
        P2P.destroy();
        DM.active=false;
        DM.role=null;
        DM.roomCode=null;
        DM.players=[];
        DM.statusState='off';
        renderDMHome();
      }, 200);
    }}
  ]);
};
window.dmShowJoinDialog = function(){
  if(CHARS.length === 0){
    dlg('还没有角色','加入跑团前需要先创建一个角色。',[{l:'取消'},{l:'去创建角色',c:'p',f:function(){ startNewChar(); }}]);
    return;
  }
  var sorted = CHARS.slice().sort(function(a,b){ return (b.updatedAt||0)-(a.updatedAt||0); });
  var h = '<div style="font-size:12.5px;color:#9a8f7d;line-height:1.6;margin-bottom:8px">选择这次跑团要使用的角色</div>';
  h += '<select class="peer-input" id="joinCharSelect" style="margin-bottom:14px">';
  sorted.forEach(function(c){
    h += '<option value="'+esc(c.id)+'">'+esc(c.name||'无名冒险者')+' · Lv.'+(c.level||1)+' '+esc(c.cls||'')+'</option>';
  });
  h += '</select>';
  h += '<div style="font-size:12.5px;color:#9a8f7d;line-height:1.6;margin-bottom:8px">输入 DM 提供的 6 位房间码</div>';
  h += '<input class="peer-input" id="joinCodeInput" placeholder="例如 A1B2C3" maxlength="6" autocomplete="off">';
  h += '<div style="font-size:11.5px;color:#6d6252;margin-top:10px;line-height:1.5">选中的角色卡会发送给 DM，并作为本次跑团角色。</div>';
  dlg('加入 DM 大厅', h, [
    {l:'取消'},
    {l:'加入', c:'p', f:function(){
      var inp=$('joinCodeInput'), sel=$('joinCharSelect');
      if(!inp || !sel) return;
      var code = inp.value.trim().toUpperCase();
      if(code.length !== 6){ alert('房间码需要 6 位'); return; }
      dmJoinRoom(code, sel.value);
    }}
  ], true);
};
window.dmJoinRoom = function(code, charId){
  if(CHARS.length === 0){ alert('请先创建一个角色'); return; }
  var c = CHARS.find(function(x){ return x.id===charId; });
  if(!c){
    var sorted = CHARS.slice().sort(function(a,b){ return (b.updatedAt||0)-(a.updatedAt||0); });
    c = sorted[0];
  }
  S = norm(JSON.parse(JSON.stringify(c)));
  if(!S.game) initGame();
  DM.active = true;
  DM.role = 'player';
  DM.roomCode = code;
  DM.statusState = 'wait';
  DM.statusText = '正在连接到 '+code+'…';
  P2P.onStatus = function(state, msg){
    if(state==='ready'){ DM.statusState='wait'; DM.statusText='正在连接 DM…'; }
    else if(state==='connected'){
      DM.statusState='ok';
      DM.statusText='已连接到 DM · '+code;
      dmLog('已加入房间 '+code, 'sys');
      P2P.send({type:'join', charData: packCharData()});
      $('trkTitle').textContent = (S&&S.name)||'角色卡';
      showPage('pgTrk');
      renderTrk();
      mountVoiceBar();
    } else if(state==='closed'){ DM.statusState='error'; DM.statusText='与 DM 断开'; }
    else if(state==='reconnecting'){ DM.statusState='wait'; DM.statusText=msg; }
    else if(state==='error'){ DM.statusState='error'; DM.statusText=msg; }
    if(DM.role==='player') renderDMHome();
  };
  P2P.onData = function(data){
    if(!data) return;
    if(data.type==='welcome'){ dmLog('DM 已确认加入', 'sys'); }
    else if(data.type==='dm-command'){ applyDMCommand(data.patch); }
    else if(data.type==='dm-roll'){ dmLog('DM 掷骰：'+data.text, 'dice'); renderDMHome(); }
    else if(data==='dm-broadcast'){ dmLog('DM：'+data.text, 'info'); renderDMHome(); }
    else if(data.type==='kick'){
      dlg('被移出房间','DM 将你移出了房间。',[{l:'好', c:'p', f:function(){
        P2P.destroy();
        DM.active=false; DM.role=null;
        renderDMHome();
      }}]);
    }
    else if(data.type==='room-closed'){
      dmLog('DM 关闭了房间', 'sys');
      P2P.destroy();
      DM.active=false; DM.role=null;
      renderDMHome();
    }
    else if(data.type==='encounter-update'){
      COMBAT.encounter = data.data;
      if(S && S.game){
        var myU = COMBAT.encounter && COMBAT.encounter.units ? COMBAT.encounter.units.find(function(u){ return u.ownerId===S.id; }) : null;
        S.game.inCombat = !!(COMBAT.encounter && COMBAT.encounter.active && COMBAT.encounter.started && myU);
        S.game.combatUnitId = myU ? myU.id : '';
        saveCur();
      }
      // DM 发起遭遇后，玩家自动回到角色卡并切换为战斗视图
      if(DM.role==='player'){
        $('trkTitle').textContent = (S&&S.name)||'角色卡';
        showPage('pgTrk');
        renderTrk();
        mountVoiceBar();
      }
    }
    else if(data.type==='encounter-end'){
      COMBAT.encounter = null;
      if(S && S.game){ S.game.inCombat=false; S.game.combatUnitId=''; }
      saveCur();
      dmLog('战斗结束 · 已返回探索模式', 'sys');
      if(DM.role==='player' && S){
        $('trkTitle').textContent = S.name||'角色卡';
        showPage('pgTrk');
        renderTrk();
        mountVoiceBar();
      } else renderDMHome();
    }
    else if(data.type==='request-response'){
      dlg(data.approved?'DM 已同意':'DM 已拒绝', data.msg||'', [{l:'好', c:'p'}]);
    }
  };
  P2P.onError = function(e){ dmLog('P2P 错误：'+e.message, 'sys'); };
  P2P.init('player', code);
  renderDMHome();
  mountVoiceBarDM();
};
window.dmLeaveRoom = function(){
  dlg('离开房间','确定离开？',[
    {l:'取消'},
    {l:'离开', c:'d', f:function(){
      if(VOICE.enabled) voiceLeave();
      P2P.destroy();
      DM.active=false; DM.role=null;
      renderDMHome();
    }}
  ]);
};

// 打包角色数据
function packCharData(){
  if(!S) return null;
  return {
    id: S.id, name: S.name||'无名冒险者',
    cls: S.cls, species: S.species, level: S.level,
    maxHP: S.game?S.game.maxHP:0, currentHP: S.game?S.game.currentHP:0, tempHP: S.game?S.game.tempHP:0,
    conditions: S.game?(S.game.conditions||[]).slice():[],
    currency: S.game?JSON.parse(JSON.stringify(S.game.currency||{})):{},
    exp: S.game?(S.game.exp||0):0
  };
}

// 玩家主动同步
function syncToDM(){
  if(!DM.active || DM.role!=='player' || !P2P.ready) return;
  P2P.send({type:'state-update', charData: packCharData()});
  broadcastPartyState();
}
function broadcastPartyState(){
  // 通知 DM 转发给其他玩家
  if(DM.role==='player' && P2P.ready){
    P2P.send({type:'party-update', data: packCharData()});
  }
}

// DM 处理玩家数据
function dmHandlePlayerData(data, conn){
  if(!data || !data.type) return;
  if(data.type === 'join'){
    var charData=data.charData||{};
    // 重连时按角色 ID 接管旧席位，避免同一角色出现两个幽灵连接
    var existing = DM.players.find(function(p){ return (charData.id && p.data && p.data.id===charData.id) || p.conn===conn; });
    if(existing){
      if(existing.conn!==conn){ try{ if(existing.conn) existing.conn.close(); }catch(e){} }
      existing.conn=conn; existing.data=charData;
      dmLog('「'+(charData.name||'玩家')+'」已重新连接', 'sys');
    } else {
      DM.players.push({conn:conn, data:charData});
      dmLog('「'+(charData.name||'玩家')+'」已加入', 'sys');
    }
    P2P.sendTo({type:'welcome', roomCode: DM.roomCode}, conn);
    // 广播队伍信息
    broadcastParty();
    renderDMHome();
  }
  else if(data.type === 'state-update'){
    var p = DM.players.find(function(pp){ return pp.conn===conn; });
    if(p && data.charData){
      var oldHP = p.data.currentHP;
      p.data = data.charData;
      if(oldHP !== data.charData.currentHP){
        var diff = data.charData.currentHP - oldHP;
        dmLog((data.charData.name||'玩家')+' HP '+(diff>0?'+':'')+diff+' → '+data.charData.currentHP, diff>0?'heal':'dmg');
      }
      broadcastParty();
      renderDMHome();
    }
  }
  else if(data.type === 'party-update'){
    var p2 = DM.players.find(function(pp){ return pp.conn===conn; });
    if(p2) p2.data = data.data;
    broadcastParty();
  }
  else if(data.type === 'dice-roll'){
    dmLog((data.name||'玩家')+' 掷骰：'+data.text, 'dice');
    renderDMHome();
  }
  else if(data.type === 'attack-roll'){
    dmLog((data.name||'玩家')+' 使用「'+data.weapon+'」'+data.text, data.crit?'dice':'info');
    renderDMHome();
  }
  else if(data.type === 'turn-action'){
    if(COMBAT.encounter && COMBAT.encounter.units){
      var tu=COMBAT.encounter.units.find(function(u){ return u.id===data.unitId; });
      if(tu){ tu.actionUsed=!!data.actionUsed; tu.bonusUsed=!!data.bonusUsed; tu.reactionUsed=!!data.reactionUsed; tu.moveUsed=Math.max(0,Math.min(Number(tu.moveMax)||30,Number(data.moveUsed)||0)); saveEncounter(); syncEncounterToPlayers(); renderDMHome(); }
    }
  }
  else if(data.type === 'turn-end'){
    if(COMBAT.encounter && COMBAT.encounter.started && COMBAT.encounter.currentUnitId===data.unitId){
      dmLog((data.name||'玩家')+' 结束回合','info');
      combatNextTurn();
    }
  }
  else if(data.type === 'chat'){
    dmLog((data.name||'玩家')+'：'+data.text, 'info');
    renderDMHome();
  }
  else if(data.type === 'request'){
    if(!DM.pendingRequests) DM.pendingRequests = [];
    DM.pendingRequests.push({conn:conn, name:data.name, desc:data.desc, type:data.reqType, idx:DM.players.findIndex(function(pp){ return pp.conn===conn; })});
    dmLog('「'+data.name+'」申请：'+data.desc, 'info');
    renderDMHome();
  }
}

// 广播队伍信息给所有玩家
function broadcastParty(){
  var members = DM.players.map(function(p){
    return {
      id: p.data.id, name: p.data.name, cls: p.data.cls,
      hp: p.data.currentHP, maxHP: p.data.maxHP,
      conditions: p.data.conditions||[], online: true
    };
  });
  P2P.broadcast({type:'party-list', members: members});
}

// DM 控制
function dmPushToPlayer(p, patch){
  if(!p || !p.conn) return;
  P2P.sendTo({type:'dm-command', patch: patch}, p.conn);
}
window.dmHpDelta = function(idx, delta){
  var p = DM.players[idx]; if(!p) return;
  var d = p.data;
  var old = d.currentHP||0;
  var nv = Math.max(0, Math.min(d.maxHP, old+delta));
  d.currentHP = nv;
  dmPushToPlayer(p, {hpDelta: delta});
  dmLog('DM 修改「'+(d.name||'玩家')+'」HP：'+(delta>0?'+':'')+delta+' → '+nv, delta>0?'heal':'dmg');
  broadcastParty();
  renderDMHome();
};
window.dmFullHeal = function(idx){
  var p = DM.players[idx]; if(!p) return;
  p.data.currentHP = p.data.maxHP;
  dmPushToPlayer(p, {hpSet: p.data.currentHP});
  dmLog('DM 让「'+(p.data.name||'玩家')+'」满血', 'heal');
  broadcastParty();
  renderDMHome();
};
window.dmGoldDelta = function(idx, delta){
  var p = DM.players[idx]; if(!p) return;
  dmPushToPlayer(p, {goldDelta: delta});
  dmLog('DM 修改「'+(p.data.name||'玩家')+'」金币：'+(delta>0?'+':'')+delta+' GP', 'info');
};
window.dmExpDelta = function(idx, delta){
  var p = DM.players[idx]; if(!p) return;
  dmPushToPlayer(p, {expDelta: delta});
  dmLog('DM 给「'+(p.data.name||'玩家')+'」经验：+'+delta, 'info');
};
window.dmAddCondition = function(idx){
  var p = DM.players[idx]; if(!p) return;
  var h = '<div style="max-height:200px;overflow-y:auto;padding:6px 0">';
  COND.forEach(function(c){
    h += '<div style="padding:8px 10px;margin-bottom:4px;background:#100d0a;border:1px solid #3a3128;border-radius:8px;cursor:pointer;font-size:13px" onclick="dmPickCondition('+idx+',\''+c[0]+'\')">'+c[1]+'</div>';
  });
  h += '</div>';
  dlg('切换状态', h, [{l:'关闭', c:'p'}], true);
};
window.dmPickCondition = function(idx, condKey){
  closeDlg();
  var p = DM.players[idx]; if(!p) return;
  var conds = (p.data.conditions||[]).slice();
  var i = conds.indexOf(condKey);
  if(i>=0) conds.splice(i,1); else conds.push(condKey);
  p.data.conditions = conds;
  dmPushToPlayer(p, {conditions: conds});
  var nm=''; COND.forEach(function(c){ if(c[0]===condKey) nm=c[1]; });
  dmLog('DM 切换「'+(p.data.name||'玩家')+'」状态：'+(nm||condKey), 'info');
  broadcastParty();
  renderDMHome();
};
window.dmKickPlayer = function(idx){
  var p = DM.players[idx]; if(!p) return;
  dlg('踢出玩家','确定踢出「'+(p.data.name||'玩家')+'」？',[
    {l:'取消'},
    {l:'踢出', c:'d', f:function(){
      P2P.sendTo({type:'kick'}, p.conn);
      setTimeout(function(){ try { p.conn.close(); } catch(e){} }, 300);
      DM.players = DM.players.filter(function(pp){ return pp!==p; });
      dmLog('已踢出玩家', 'sys');
      broadcastParty();
      renderDMHome();
    }}
  ]);
};
window.dmRollBroadcast = function(dice, adv, dis){
  var r1 = Math.floor(Math.random()*dice)+1;
  var r2 = null, used = r1;
  if(adv){ r2 = Math.floor(Math.random()*dice)+1; used = Math.max(r1,r2); }
  else if(dis){ r2 = Math.floor(Math.random()*dice)+1; used = Math.min(r1,r2); }
  var txt = 'd'+dice;
  if(r2!==null) txt += '（'+r1+', '+r2+'）→ '+used; else txt += ' → '+used;
  if(dice===20 && used===20) txt += ' ★ 大成功！';
  if(dice===20 && used===1) txt += ' ✗ 大失败！';
  dmLog('DM 掷 '+txt, 'dice');
  P2P.broadcast({type:'dm-roll', text: txt, dice: dice, result: used});
  renderDMHome();
};
window.dmRollExpr = function(expr){
  if(!expr) return;
  var m = expr.trim().match(/^(\d*)d(\d+)([+-]\d+)?$/i);
  if(!m){ alert('格式错误'); return; }
  var n = m[1]?parseInt(m[1]):1, d = parseInt(m[2]), b = m[3]?parseInt(m[3]):0;
  if(n<1||n>50||d<2||d>100){ alert('超出范围'); return; }
  var rolls=[], sum=0;
  for(var i=0;i<n;i++){ var r=Math.floor(Math.random()*d)+1; rolls.push(r); sum+=r; }
  var total = sum+b;
  var txt = expr+'：['+rolls.join(', ')+']'+(b?(b>=0?' + '+b:' - '+Math.abs(b)):'')+' = '+total;
  dmLog('DM 掷 '+txt, 'dice');
  P2P.broadcast({type:'dm-roll', text: txt});
  $('dmDiceExpr').value = '';
  renderDMHome();
};
window.dmBroadcastMsg = function(){
  var inp = $('dmBroadcastMsg');
  if(!inp) return;
  var msg = inp.value.trim();
  if(!msg) return;
  dmLog('DM 广播：'+msg, 'info');
  P2P.broadcast({type:'dm-broadcast', text: msg});
  inp.value = '';
  renderDMHome();
};
window.dmClearLog = function(){
  dlg('清空日志','确定清空？',[
    {l:'取消'},
    {l:'清空', c:'d', f:function(){ DM.log=[]; renderDMHome(); }}
  ]);
};
window.dmPing = function(){
  if(P2P.role==='dm'){
    var t = Date.now();
    P2P.conns.forEach(function(c){ if(c.open) try { c.send({type:'ping', t:t}); } catch(e){} });
    dmLog('已发送延迟测试', 'sys');
  }
  renderDMHome();
};
window.dmOnNoteInput = function(){
  var ta = $('dmNoteArea'); if(!ta) return;
  DM.note = ta.value;
  dmSaveNote();
  var meta = $('dmNoteMeta');
  if(meta) meta.textContent = '已保存 · ' + new Date().toLocaleTimeString();
};

// 玩家端申请
window.playerRequest = function(type){
  if(!DM.active || DM.role!=='player' || !P2P.ready) return;
  var desc = '', msg = '';
  if(type==='heal'){ desc = '申请加血'; msg = '请 DM 批准加血'; }
  else if(type==='gold'){ desc = '申请补钱'; msg = '请 DM 批准补钱'; }
  else if(type==='rest'){ desc = '申请休息'; msg = '请 DM 批准短休/长休'; }
  else if(type==='msg'){
    var txt = prompt('发送给 DM 的消息：');
    if(!txt) return;
    P2P.send({type:'chat', name: S.name||'玩家', text: txt});
    dmLog('我：'+txt, 'info');
    renderDMHome();
    return;
  }
  P2P.send({type:'request', name: S.name||'玩家', desc: desc, reqType: type});
  dmLog('已发送申请：'+desc, 'sys');
  renderDMHome();
};
window.dmApproveReq = function(idx){
  var req = DM.pendingRequests[idx];
  if(!req) return;
  var p = DM.players[req.idx];
  if(req.type==='heal' && p){
    dmFullHeal(req.idx);
  } else if(req.type==='gold' && p){
    dmGoldDelta(req.idx, 50);
  } else if(req.type==='rest' && p){
    P2P.sendTo({type:'dm-command', patch:{rest:true}}, p.conn);
    dmLog('批准 '+req.name+' 休息', 'info');
  }
  P2P.sendTo({type:'request-response', approved:true, msg:'DM 已同意：'+req.desc}, req.conn);
  DM.pendingRequests.splice(idx, 1);
  renderDMHome();
};
window.dmDenyReq = function(idx){
  var req = DM.pendingRequests[idx];
  if(!req) return;
  P2P.sendTo({type:'request-response', approved:false, msg:'DM 拒绝：'+req.desc}, req.conn);
  dmLog('拒绝 '+req.name+' 的申请', 'info');
  DM.pendingRequests.splice(idx, 1);
  renderDMHome();
};
window.dmSendChat = function(){
  var inp = $('dmChatMsg'); if(!inp) return;
  var msg = inp.value.trim();
  if(!msg) return;
  P2P.send({type:'chat', name:(S&&S.name)||'玩家', text: msg});
  dmLog('我：'+msg, 'info');
  inp.value = '';
  renderDMHome();
};
window.dmSyncToDM = function(){
  if(!S) return;
  P2P.send({type:'state-update', charData: packCharData()});
  dmLog('已向 DM 同步角色数据', 'sys');
  renderDMHome();
};

// 应用 DM 命令
function applyDMCommand(patch){
  if(!patch || !S || !S.game) return;
  var g = S.game;
  var changed = false;
  if(typeof patch.hpDelta === 'number'){
    var rm = patch.hpDelta;
    if(rm < 0){
      var dmg = -rm;
      if(g.tempHP>0){ var use=Math.min(g.tempHP,dmg); g.tempHP-=use; dmg-=use; }
      if(dmg>0) g.currentHP = Math.max(0, g.currentHP-dmg);
      dmLog('DM 造成 '+(-rm)+' 点伤害', 'dmg');
    } else {
      g.currentHP = Math.min(g.maxHP, g.currentHP+rm);
      dmLog('DM 治疗 '+rm+' HP', 'heal');
    }
    changed = true;
  }
  if(typeof patch.hpSet === 'number'){
    g.currentHP = Math.max(0, Math.min(g.maxHP, patch.hpSet));
    dmLog('DM 设置 HP 为 '+g.currentHP, 'info');
    changed = true;
  }
  if(typeof patch.goldDelta === 'number'){
    if(!g.currency) g.currency = {pp:0,gp:0,ep:0,sp:0,cp:0};
    if(patch.goldDelta >= 0){
      g.currency.gp = (g.currency.gp||0) + patch.goldDelta;
    } else {
      var need = -patch.goldDelta;
      var have = g.currency.gp||0;
      if(have >= need) g.currency.gp = have-need;
      else g.currency.gp = 0;
    }
    dmLog('DM 调整金币：'+(patch.goldDelta>=0?'+':'')+patch.goldDelta+' GP', 'info');
    changed = true;
  }
  if(typeof patch.expDelta === 'number'){
    g.exp = Math.max(0, (g.exp||0) + patch.expDelta);
    dmLog('DM 调整经验：+'+patch.expDelta, 'info');
    changed = true;
  }
  if(Array.isArray(patch.conditions)){
    g.conditions = patch.conditions.slice();
    dmLog('DM 更新状态', 'info');
    changed = true;
  }
  if(patch.rest){
    g.currentHP = g.maxHP; g.tempHP = 0;
    g.spellSlots.forEach(function(s){ s.used=0; });
    dmLog('DM 批准休息，已恢复全部资源', 'heal');
    changed = true;
  }
  if(changed){
    saveCur();
    if($('trkMain')) renderTrk();
    if(DM.role==='player') renderDMHome();
  }
}

// 处理队伍列表
function handlePartyList(members){
  PARTY.members = (members||[]).filter(function(m){ return m.id !== S.id; });
  if(DM.role==='player' && $('trkMain')) renderTrk();
}

// ==================== 语音（WebRTC） ====================
function mountVoiceBar(){
  var host = $('voiceBarHost');
  if(!host) return;
  host.innerHTML = renderVoiceBar();
}
function mountVoiceBarDM(){
  var host = $('voiceBarHostDM');
  if(!host) return;
  host.innerHTML = renderVoiceBar();
}
function renderVoiceBar(){
  if(!DM.active) return '';
  var h = '';
  h += '<div class="voice-bar'+(VOICE.enabled?(VOICE.micOn?' on':' err'):'')+'" style="position:sticky;bottom:8px;margin-top:12px">';
  h += '<button class="voice-mic'+(VOICE.micOn?'':' muted')+'" '+(VOICE.enabled?'':'disabled')+' onclick="voiceToggleMic()">'+(VOICE.micOn?'🎙':'🔇')+'</button>';
  h += '<div class="voice-info">';
  h += '<div class="voice-nm">'+(VOICE.enabled?(VOICE.micOn?'语音开启':'已加入（静音）'):'语音未开启')+'</div>';
  h += '<div class="voice-sub">'+(VOICE.enabled?(Object.keys(VOICE.remoteStreams).length+' 位参与者'):'点击右侧加入')+'</div>';
  h += '</div>';
  h += '<div class="voice-participants">';
  VOICE.participants.forEach(function(p, i){
    if(i>=4) return;
    h += '<div class="voice-pt'+(VOICE.speaking[p.peerId]?' speaking':'')+'">'+esc((p.name||'?').charAt(0))+'</div>';
  });
  h += '</div>';
  h += '<button class="voice-ctrl'+(VOICE.enabled?' on':'')+'" onclick="voiceToggle()">'+(VOICE.enabled?'✕':'🎙')+'</button>';
  h += '</div>';
  return h;
}

window.voiceToggle = async function(){
  if(!DM.active){ alert('请先连接 P2P 房间'); return; }
  if(VOICE.enabled){ voiceLeave(); }
  else { await voiceJoin(); }
  mountVoiceBar(); mountVoiceBarDM();
  if(DM.role==='dm') renderDMHome(); else renderTrk();
};

async function voiceJoin(){
  try {
    if(!navigator.mediaDevices || !navigator.mediaDevices.getUserMedia){
      alert('浏览器不支持麦克风');
      return;
    }
    var stream = await navigator.mediaDevices.getUserMedia({audio:true, video:false});
    VOICE.localStream = stream;
    VOICE.enabled = true;
    VOICE.micOn = true;
    setupVoiceAnalysers();
    startVolumeLoop();
    if(DM.role === 'dm'){
      // DM：接听所有玩家的语音
      P2P.peer.on('call', function(call){
        call.answer(); // 不发送本地流（DM 只听）
        call.on('stream', function(remote){
          addRemoteAudio(call.peer, remote);
        });
        call.on('close', function(){
          removeRemoteAudio(call.peer);
        });
      });
      dmLog('语音已开启（DM 收听模式）', 'sys');
    } else {
      // 玩家：向 DM 发起语音通话
      var dmId = 'dnd5r-dm-'+DM.roomCode.toLowerCase();
      var call = P2P.peer.call(dmId, stream);
      if(call){
        call.on('stream', function(remote){
          addRemoteAudio(dmId, remote);
        });
        call.on('close', function(){ removeRemoteAudio(dmId); });
      }
      dmLog('语音已开启', 'sys');
    }
  } catch(e){
    alert('麦克风权限被拒绝：'+e.message);
    VOICE.enabled = false;
  }
}
function voiceLeave(){
  if(VOICE.localStream){
    VOICE.localStream.getTracks().forEach(function(t){ t.stop(); });
    VOICE.localStream = null;
  }
  Object.keys(VOICE.audioEls).forEach(function(pid){
    var el = VOICE.audioEls[pid];
    if(el) el.remove();
  });
  VOICE.audioEls = {};
  VOICE.remoteStreams = {};
  VOICE.participants = [];
  if(VOICE.rafId) cancelAnimationFrame(VOICE.rafId);
  VOICE.enabled = false;
  VOICE.micOn = false;
  if(DM.active) dmLog('语音已关闭', 'sys');
}
function addRemoteAudio(peerId, stream){
  VOICE.remoteStreams[peerId] = stream;
  var el = document.createElement('audio');
  el.srcObject = stream;
  el.autoplay = true;
  el.playsInline = true;
  el.setAttribute('playsinline', '');
  var container = $('voiceElements');
  if(container) container.appendChild(el);
  VOICE.audioEls[peerId] = el;
  // 更新参与者
  var name = peerId;
  if(DM.role==='dm'){
    var p = DM.players.find(function(pp){ return pp.conn && pp.conn.peer === peerId; });
    if(p && p.data) name = p.data.name;
  } else {
    name = 'DM';
  }
  VOICE.participants = VOICE.participants.filter(function(x){ return x.peerId!==peerId; });
  VOICE.participants.push({peerId:peerId, name:name});
  el.play().catch(function(){});
}
function removeRemoteAudio(peerId){
  if(VOICE.audioEls[peerId]){
    try { VOICE.audioEls[peerId].remove(); } catch(e){}
    delete VOICE.audioEls[peerId];
  }
  delete VOICE.remoteStreams[peerId];
  VOICE.participants = VOICE.participants.filter(function(x){ return x.peerId!==peerId; });
}
function setupVoiceAnalysers(){
  if(!VOICE.localStream) return;
  var ctx = window.AudioContext || window.webkitAudioContext;
  if(!ctx) return;
  if(!VOICE.audioCtx) VOICE.audioCtx = new ctx();
  var src = VOICE.audioCtx.createMediaStreamSource(VOICE.localStream);
  var analyser = VOICE.audioCtx.createAnalyser();
  analyser.fftSize = 256;
  src.connect(analyser);
  VOICE.micAnalyser = analyser;
}
function startVolumeLoop(){
  function loop(){
    if(!VOICE.enabled) return;
    // 本地
    if(VOICE.micAnalyser){
      var data = new Uint8Array(VOICE.micAnalyser.frequencyBinCount);
      VOICE.micAnalyser.getByteFrequencyData(data);
      var sum=0;
      for(var i=0;i<data.length;i++) sum += data[i];
      var vol = sum / data.length;
      VOICE.localVolume = vol;
    }
    VOICE.rafId = requestAnimationFrame(loop);
  }
  VOICE.rafId = requestAnimationFrame(loop);
}
window.voiceToggleMic = function(){
  if(!VOICE.enabled) return;
  VOICE.micOn = !VOICE.micOn;
  if(VOICE.localStream){
    VOICE.localStream.getAudioTracks().forEach(function(t){ t.enabled = VOICE.micOn; });
  }
  mountVoiceBar();
  mountVoiceBarDM();
  if(DM.role==='dm') renderDMHome(); else renderTrk();
};

// ==================== 初始化 ====================
window.onName = window.onName || function(){};
window.onPlayer = window.onPlayer || function(){};

(function(){
  try {
    var st = $('st');
    st.textContent = '✓ 本地 JS 就绪 · 联机模块单独加载';
    st.className = 'ok';
    setTimeout(function(){ st.style.display = 'none'; }, 3000);
    dmLoadNote();
    loadEncounter();
    CHARS = loadAll().map(norm).filter(Boolean);
    renderHome();
    showPage('pgHome');
  } catch(e){
    alert('初始化出错：'+e.message);
    console.error(e);
  }
})();
