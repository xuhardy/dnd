
/* ==================== V14 · Map library + templates ==================== */
(function(){
var MAPS_KEY=(typeof DM_KEY!=='undefined'?DM_KEY:'dnd')+'_maps_v13';
var ACTIVE_KEY=MAPS_KEY+'_active';
function clone(o){return JSON.parse(JSON.stringify(o));}
function uid(){return 'map_'+Date.now().toString(36)+Math.random().toString(36).slice(2,6);}
function readStore(){try{var a=JSON.parse(localStorage.getItem(MAPS_KEY)||'[]');return Array.isArray(a)?a:[];}catch(e){return [];}}
function writeStore(a){try{localStorage.setItem(MAPS_KEY,JSON.stringify(a));return true;}catch(e){alert('地图保存失败：浏览器本地存储空间不足。可以先导出不常用地图再删除。');return false;}}
function normalize(e){if(!e)e=newEncounter('冒险地图');if(!e.id)e.id=uid();if(!e.name)e.name='冒险地图';if(!e.grid)e.grid={w:20,h:20,cellSize:5};if(!e.terrain)e.terrain={};if(!Array.isArray(e.units))e.units=[];if(!e.phase)e.phase=e.started?'combat':'explore';e.active=true;return e;}
function activeId(){return localStorage.getItem(ACTIVE_KEY)||'';}
function setActive(id){localStorage.setItem(ACTIVE_KEY,id);}
function saveCurrent(){if(!COMBAT.encounter)return;var e=normalize(COMBAT.encounter),a=readStore(),i=a.findIndex(function(x){return x.id===e.id;});e.updated=Date.now();if(i>=0)a[i]=clone(e);else a.unshift(clone(e));writeStore(a);setActive(e.id);try{localStorage.setItem(DM_KEY+'_encounter',JSON.stringify(e));}catch(_){} }
function migrate(){var a=readStore();if(!a.length&&COMBAT.encounter){var e=normalize(COMBAT.encounter);a=[clone(e)];writeStore(a);setActive(e.id);}else if(a.length){var id=activeId(),m=a.find(function(x){return x.id===id;})||a[0];COMBAT.encounter=normalize(clone(m));setActive(COMBAT.encounter.id);}}
window.v13MapList=readStore;
window.v13SaveMap=function(){saveCurrent();if(typeof dmLog==='function')dmLog('地图已保存：'+COMBAT.encounter.name,'sys');v13RefreshManager();};
window.v13SwitchMap=function(id){if(!id||!confirm('切换地图？当前地图会先自动保存。'))return;saveCurrent();var m=readStore().find(function(x){return x.id===id;});if(!m)return;COMBAT.encounter=normalize(clone(m));COMBAT.selectedUnitId=null;setActive(m.id);syncEncounterToPlayers();if(typeof initMapCanvas==='function')initMapCanvas();};
window.v13NewMap=function(){var n=prompt('新地图名称','新场景');if(!n)return;saveCurrent();var e=normalize(newEncounter(n.trim()||'新场景'));e.id=uid();e.phase='explore';e.started=false;e.active=true;e.terrain={};e.units=[];COMBAT.encounter=e;setActive(e.id);saveCurrent();syncEncounterToPlayers();initMapCanvas();};
window.v13DuplicateMap=function(){if(!COMBAT.encounter)return;saveCurrent();var e=clone(COMBAT.encounter);e.id=uid();e.name=(e.name||'地图')+' 副本';e.phase='explore';e.started=false;e.currentUnitId='';e.round=1;e.created=Date.now();COMBAT.encounter=normalize(e);setActive(e.id);saveCurrent();syncEncounterToPlayers();initMapCanvas();};
window.v13DeleteMap=function(){var a=readStore();if(a.length<=1){alert('至少保留一张地图。');return;}var e=COMBAT.encounter;if(!e||!confirm('删除地图「'+e.name+'」？此操作不能撤销。'))return;a=a.filter(function(x){return x.id!==e.id;});writeStore(a);COMBAT.encounter=normalize(clone(a[0]));setActive(COMBAT.encounter.id);saveCurrent();syncEncounterToPlayers();initMapCanvas();};
function template(key){var e=normalize(newEncounter('新地图'));e.id=uid();e.phase='explore';e.started=false;e.units=[];e.terrain={};function t(x,y,k){e.terrain[x+','+y]=k;}if(key==='blank'){e.name='空白地图';e.grid={w:20,h:20,cellSize:5};}
 else if(key==='room'){e.name='石室';e.grid={w:18,h:14,cellSize:5};for(var x=2;x<=15;x++){t(x,2,'wall');t(x,11,'wall');}for(var y=2;y<=11;y++){t(2,y,'wall');t(15,y,'wall');}delete e.terrain['8,11'];t(8,11,'door');}
 else if(key==='corridor'){e.name='地牢走廊';e.grid={w:24,h:14,cellSize:5};for(var x=1;x<23;x++){t(x,4,'wall');t(x,9,'wall');}delete e.terrain['7,4'];delete e.terrain['16,9'];t(7,4,'door');t(16,9,'door');}
 else if(key==='camp'){e.name='野外营地';e.grid={w:20,h:20,cellSize:5};for(var x=2;x<18;x++)t(x,14,'difficult');t(10,10,'fire');t(9,10,'fire');t(11,10,'fire');for(var y=2;y<8;y++)t(4,y,'water');}
 return e;}
window.v13UseTemplate=function(key){if(!confirm('从模板创建一张新地图？当前地图会先保存。'))return;saveCurrent();COMBAT.encounter=template(key);setActive(COMBAT.encounter.id);saveCurrent();syncEncounterToPlayers();initMapCanvas();};
window.v13ExportMap=function(){if(!COMBAT.encounter)return;saveCurrent();var data={format:'DND_TABLETOP_MAP_V14',version:13,map:clone(COMBAT.encounter)};var blob=new Blob([JSON.stringify(data,null,2)],{type:'application/json'}),a=document.createElement('a');a.href=URL.createObjectURL(blob);a.download=(COMBAT.encounter.name||'map').replace(/[\/:*?"<>|]/g,'_')+'.dndmap.json';document.body.appendChild(a);a.click();setTimeout(function(){URL.revokeObjectURL(a.href);a.remove();},500);};
window.v13ImportMap=function(){var i=document.createElement('input');i.type='file';i.accept='.json,.dndmap.json,application/json';i.onchange=function(){var f=i.files&&i.files[0];if(!f)return;var r=new FileReader();r.onload=function(){try{var o=JSON.parse(r.result),m=o&&o.map?o.map:o;if(!m||!m.grid||!Array.isArray(m.units)){throw new Error('不是有效的地图模板');}saveCurrent();m=normalize(clone(m));m.id=uid();m.name=(m.name||f.name.replace(/\.json$/i,''))+'（导入）';m.phase='explore';m.started=false;m.currentUnitId='';m.round=1;COMBAT.encounter=m;setActive(m.id);saveCurrent();syncEncounterToPlayers();initMapCanvas();}catch(err){alert('导入失败：'+err.message);}};r.readAsText(f);};i.click();};
function managerHTML(){var a=readStore(),e=COMBAT.encounter||{},opts=a.map(function(m){return '<option value="'+esc(m.id)+'"'+(m.id===e.id?' selected':'')+'>'+esc(m.name||'未命名地图')+'</option>';}).join('');return '<div class="v13-maplib" id="v13MapLib"><div class="v13-maplib-head"><b>🗺 地图库</b><small>'+a.length+' 张 · 自动保存</small></div><div class="v13-maprow"><select onchange="v13SwitchMap(this.value)">'+opts+'</select><button onclick="v13SaveMap()">保存当前</button></div><div class="v13-mapactions"><button class="primary" onclick="v13NewMap()">＋ 新地图</button><button onclick="v13DuplicateMap()">复制</button><button onclick="v13ImportMap()">导入模板</button><button onclick="v13ExportMap()">导出模板</button></div><div class="v13-templatebar"><button onclick="v13UseTemplate(\'blank\')">空白 20×20</button><button onclick="v13UseTemplate(\'room\')">石室</button><button onclick="v13UseTemplate(\'corridor\')">地牢走廊</button><button onclick="v13UseTemplate(\'camp\')">野外营地</button><button onclick="v13DeleteMap()">删除当前</button></div><div class="v13-savehint"><strong>每张地图独立保存</strong>：地形、单位位置、探索/战斗状态都会跟随地图。切换地图前也会自动保存。</div></div>'; }
window.v13RefreshManager=function(){var x=$('v13MapLib');if(x)x.outerHTML=managerHTML();};
/* Replace single-slot persistence with multi-map persistence. */
saveEncounter=function(){saveCurrent();};
loadEncounter=function(){var a=readStore();if(a.length){var id=activeId(),m=a.find(function(x){return x.id===id;})||a[0];COMBAT.encounter=normalize(clone(m));COMBAT.active=true;}else{try{var r=localStorage.getItem(DM_KEY+'_encounter');if(r)COMBAT.encounter=normalize(JSON.parse(r));}catch(_){}migrate();}};
/* Put the library above the DM map without cluttering player view. */
var baseInit=initMapCanvas;initMapCanvas=function(){baseInit();if(DM.role==='dm'){var host=$('mapMain');if(host&&!$('v13MapLib'))host.insertAdjacentHTML('afterbegin',managerHTML());}};
/* Ensure edits and map switches survive reload. */
window.addEventListener('beforeunload',function(){try{saveCurrent();}catch(_){}});
migrate();saveCurrent();
})();
