
/* ==================== V16 · vision / rooms / markers / ruler / AOE ==================== */
var V16_TOOL={mode:'',start:null,end:null,aoeCenter:null,aoeFeet:20,aoeShape:'circle',roomStart:null,msg:''};
function v16Ensure(){
  var e=(typeof v15Ensure==='function')?v15Ensure():COMBAT.encounter;if(!e)return null;
  if(!e.vision)e.vision={autoReveal:false,defaultFeet:30};
  if(typeof e.vision.autoReveal!=='boolean')e.vision.autoReveal=false;
  if(!e.vision.defaultFeet)e.vision.defaultFeet=30;
  if(!Array.isArray(e.rooms))e.rooms=[];
  if(!Array.isArray(e.markers))e.markers=[];
  return e;
}
function v16Key(x,y){return x+','+y;}
function v16GridPointFromEvent(ev,c){var r=c.getBoundingClientRect(),x=ev.clientX-r.left,y=ev.clientY-r.top,cell=COMBAT.cellPx*COMBAT.zoom;return{x:Math.floor((x-COMBAT.panX)/cell),y:Math.floor((y-COMBAT.panY)/cell)};}
function v16Valid(g){var e=COMBAT.encounter;return !!(e&&g&&g.x>=0&&g.y>=0&&g.x<e.grid.w&&g.y<e.grid.h);}
function v16Dist(a,b){if(!a||!b)return 0;var dx=Math.abs(a.x-b.x),dy=Math.abs(a.y-b.y),sq=Math.max(dx,dy),cell=(COMBAT.encounter&&COMBAT.encounter.grid&&COMBAT.encounter.grid.cellSize)||5;return sq*cell;}
function v16LineCells(a,b){var out=[],x0=a.x,y0=a.y,x1=b.x,y1=b.y,dx=Math.abs(x1-x0),sx=x0<x1?1:-1,dy=-Math.abs(y1-y0),sy=y0<y1?1:-1,err=dx+dy;while(true){out.push({x:x0,y:y0});if(x0===x1&&y0===y1)break;var e2=2*err;if(e2>=dy){err+=dy;x0+=sx;}if(e2<=dx){err+=dx;y0+=sy;}}return out;}
function v16HasLOS(a,b){var cells=v16LineCells(a,b);for(var i=1;i<cells.length-1;i++){if(typeof v15Blocked==='function'&&v15Blocked(cells[i].x,cells[i].y))return false;}return true;}
function v16RevealVisionForUnit(u){var e=v16Ensure();if(!e||!e.fog||!u)return;var feet=Number(u.visionFeet)||Number(e.vision.defaultFeet)||30,cellFeet=(e.grid&&e.grid.cellSize)||5,r=Math.max(1,Math.ceil(feet/cellFeet)),cx=Math.floor(u.x+(u.size||1)/2-.5),cy=Math.floor(u.y+(u.size||1)/2-.5);e.fog.enabled=true;for(var y=cy-r;y<=cy+r;y++)for(var x=cx-r;x<=cx+r;x++){if(x<0||y<0||x>=e.grid.w||y>=e.grid.h)continue;var d=Math.hypot(x-cx,y-cy);if(d>r+.1)continue;if(v16HasLOS({x:cx,y:cy},{x:x,y:y}))e.fog.revealed[v16Key(x,y)]=1;}}
function v16RevealAllPlayerVision(){var e=v16Ensure();if(!e||!e.vision.autoReveal)return;(e.units||[]).forEach(function(u){if(u.ownerId||u.type==='player')v16RevealVisionForUnit(u);});}
window.v16ToggleVision=function(){var e=v16Ensure();e.vision.autoReveal=!e.vision.autoReveal;if(e.vision.autoReveal)v16RevealAllPlayerVision();v15Save();initMapCanvas();};
window.v16SetVision=function(){var e=v16Ensure(),n=prompt('默认角色视野（尺）',String(e.vision.defaultFeet||30));if(n===null)return;n=Math.max(5,Math.min(300,parseInt(n)||30));e.vision.defaultFeet=n;if(e.vision.autoReveal)v16RevealAllPlayerVision();v15Save();initMapCanvas();};
window.v16Tool=function(m){V16_TOOL.mode=(V16_TOOL.mode===m?'':m);V16_TOOL.start=null;V16_TOOL.end=null;V16_TOOL.aoeCenter=null;V16_TOOL.roomStart=null;V16_TOOL.msg='';if(window.V12_ROUTE&&V12_ROUTE.active&&V16_TOOL.mode)V12_ROUTE.active=false;initMapCanvas();};
window.v16AoeShape=function(s){V16_TOOL.aoeShape=s;V16_TOOL.mode='aoe';V16_TOOL.aoeCenter=null;initMapCanvas();};
window.v16AoeSize=function(){var n=prompt('范围尺寸（尺）',String(V16_TOOL.aoeFeet||20));if(n===null)return;V16_TOOL.aoeFeet=Math.max(5,Math.min(300,parseInt(n)||20));V16_TOOL.mode='aoe';drawMap();v16UpdateReadout();};
window.v16ClearMeasure=function(){V16_TOOL.start=null;V16_TOOL.end=null;V16_TOOL.aoeCenter=null;V16_TOOL.msg='';drawMap();v16UpdateReadout();};
function v16MarkerIcon(t){return({danger:'⚠',treasure:'◆',objective:'★',npc:'●',note:'✦'})[t]||'✦';}
window.v16DeleteMarker=function(id){var e=v16Ensure();e.markers=e.markers.filter(function(m){return m.id!==id;});v15Save();initMapCanvas();};
window.v16DeleteRoom=function(id){var e=v16Ensure();e.rooms=e.rooms.filter(function(r){return r.id!==id;});v15Save();initMapCanvas();};
window.v16RevealRoomById=function(id){var e=v16Ensure(),r=e.rooms.find(function(x){return x.id===id;});if(!r)return;e.fog.enabled=true;for(var y=r.y1;y<=r.y2;y++)for(var x=r.x1;x<=r.x2;x++)e.fog.revealed[v16Key(x,y)]=1;v15Save();initMapCanvas();};
window.v16HideRoomById=function(id){var e=v16Ensure(),r=e.rooms.find(function(x){return x.id===id;});if(!r)return;e.fog.enabled=true;for(var y=r.y1;y<=r.y2;y++)for(var x=r.x1;x<=r.x2;x++)delete e.fog.revealed[v16Key(x,y)];v15Save();initMapCanvas();};
function v16AddMarker(g){var e=v16Ensure(),label=prompt('标记名称','线索');if(!label)return;var type=(prompt('类型：note / danger / treasure / objective / npc','note')||'note').toLowerCase();if(['note','danger','treasure','objective','npc'].indexOf(type)<0)type='note';var pub=confirm('这个标记让玩家也看见吗？\n“确定”=玩家可见，“取消”=仅 DM 可见');e.markers.push({id:'mk_'+Date.now().toString(36)+Math.random().toString(36).slice(2,5),x:g.x,y:g.y,label:label.trim(),type:type,public:pub});v15Save();initMapCanvas();}
function v16FinishRoom(a,b){var e=v16Ensure(),name=prompt('房间名称','房间 '+(e.rooms.length+1));if(!name)return;var r={id:'rm_'+Date.now().toString(36)+Math.random().toString(36).slice(2,5),name:name.trim()||'房间',x1:Math.min(a.x,b.x),y1:Math.min(a.y,b.y),x2:Math.max(a.x,b.x),y2:Math.max(a.y,b.y)};e.rooms.push(r);v15Save();initMapCanvas();}
function v16RoomsHTML(){var e=v16Ensure();if(!e.rooms.length)return '<span class="v16-chip">暂无房间</span>';return e.rooms.map(function(r){return '<span class="v16-chip">⌂ '+esc(r.name)+' <a href="javascript:void(0)" onclick="v16RevealRoomById(\''+r.id+'\')" style="color:#9bd39c">显</a><a href="javascript:void(0)" onclick="v16HideRoomById(\''+r.id+'\')" style="color:#aaa090">遮</a><button onclick="v16DeleteRoom(\''+r.id+'\')">×</button></span>';}).join('');}
function v16MarkersHTML(){var e=v16Ensure();if(!e.markers.length)return '<span class="v16-chip">暂无标记</span>';return e.markers.map(function(m){return '<span class="v16-chip">'+v16MarkerIcon(m.type)+' '+esc(m.label)+(m.public?'':' · DM')+' <button onclick="v16DeleteMarker(\''+m.id+'\')">×</button></span>';}).join('');}
function v16PanelHTML(){var e=v16Ensure(),v=e.vision;return '<div class="v16-panel" id="v16Panel"><div class="v16-title"><b>🧩 桌面工具</b><small>视野 · 房间 · 标记 · 测距 · 范围</small></div><div class="v16-tools"><button class="green '+(v.autoReveal?'on':'')+'" onclick="v16ToggleVision()">◉ 自动视野</button><button class="'+(V16_TOOL.mode==='room'?'on':'')+'" onclick="v16Tool(\'room\')">⌂ 划房间</button><button class="'+(V16_TOOL.mode==='marker'?'on':'')+'" onclick="v16Tool(\'marker\')">✦ 放标记</button><button class="blue '+(V16_TOOL.mode==='ruler'?'on':'')+'" onclick="v16Tool(\'ruler\')">↔ 测距离</button><button class="blue '+(V16_TOOL.mode==='aoe'?'on':'')+'" onclick="v16Tool(\'aoe\')">◯ 范围模板</button></div><div class="v16-mini"><button onclick="v16SetVision()">视野 '+esc(String(v.defaultFeet||30))+' 尺</button><button onclick="v16AoeShape(\'circle\')">圆形 '+V16_TOOL.aoeFeet+' 尺</button><button onclick="v16AoeShape(\'square\')">方形 '+V16_TOOL.aoeFeet+' 尺</button></div><div class="v16-note"><b>划房间：</b>连续点两个角即可保存房间区域；以后可以一键揭示或重新遮盖。<br><b>自动视野：</b>角色移动后按墙和关闭的门计算视线并自动揭示。</div><details class="v16-list"><summary>房间区域</summary><div class="v16-chiprow">'+v16RoomsHTML()+'</div></details><details class="v16-list"><summary>地图标记</summary><div class="v16-chiprow">'+v16MarkersHTML()+'</div></details></div>';}
function v16PlayerToolsHTML(){return '<div class="v16-player-tools" id="v16PlayerTools"><button class="'+(V16_TOOL.mode==='ruler'?'on':'')+'" onclick="v16Tool(\'ruler\')">↔ 测距离</button><button class="'+(V16_TOOL.mode==='aoe'?'on':'')+'" onclick="v16Tool(\'aoe\')">◯ 范围模板</button></div><div class="v16-readout" id="v16Readout">点工具后直接点击地图。</div>';}
function v16UpdateReadout(){var el=$('v16Readout');if(!el)return;var s='';if(V16_TOOL.mode==='ruler'){s=V16_TOOL.start&&V16_TOOL.end?'<b>'+v16Dist(V16_TOOL.start,V16_TOOL.end)+' 尺</b> · 起点 ('+(V16_TOOL.start.x+1)+','+(V16_TOOL.start.y+1)+') → 终点 ('+(V16_TOOL.end.x+1)+','+(V16_TOOL.end.y+1)+')':'测距：依次点起点和终点。';}else if(V16_TOOL.mode==='aoe'){s='范围：<b>'+V16_TOOL.aoeShape+' · '+V16_TOOL.aoeFeet+' 尺</b>。点地图放置模板。';}else s='点工具后直接点击地图。';el.innerHTML=s;}
/* Persistent visual overlays. Anything player-visible still respects fog. */
function v16CellVisibleToPlayer(x,y){var e=COMBAT.encounter;if(DM.role==='dm'||!e||!e.fog||!e.fog.enabled)return true;return !!e.fog.revealed[v16Key(x,y)];}
function v16DrawOverlays(){var c=COMBAT.canvas,e=v16Ensure();if(!c||!e)return;var ctx=c.getContext('2d'),cell=COMBAT.cellPx*COMBAT.zoom,px=COMBAT.panX,py=COMBAT.panY;ctx.save();
  if(DM.role==='dm')e.rooms.forEach(function(r){ctx.strokeStyle='rgba(127,176,224,.58)';ctx.lineWidth=2;ctx.setLineDash([6,4]);ctx.strokeRect(px+r.x1*cell,py+r.y1*cell,(r.x2-r.x1+1)*cell,(r.y2-r.y1+1)*cell);ctx.setLineDash([]);ctx.fillStyle='rgba(12,20,28,.76)';ctx.font=Math.max(9,Math.min(12,cell*.27))+'px -apple-system,sans-serif';ctx.textAlign='left';ctx.fillText(r.name,px+r.x1*cell+4,py+r.y1*cell+12);});
  e.markers.forEach(function(m){if(DM.role!=='dm'&&!m.public)return;if(!v16CellVisibleToPlayer(m.x,m.y))return;var x=px+(m.x+.5)*cell,y=py+(m.y+.5)*cell;ctx.beginPath();ctx.fillStyle=m.public?'rgba(232,201,90,.92)':'rgba(163,122,201,.92)';ctx.arc(x,y,Math.max(8,cell*.22),0,Math.PI*2);ctx.fill();ctx.fillStyle='#17120c';ctx.font=Math.max(10,Math.min(15,cell*.34))+'px -apple-system,sans-serif';ctx.textAlign='center';ctx.textBaseline='middle';ctx.fillText(v16MarkerIcon(m.type),x,y);ctx.fillStyle='rgba(14,11,8,.82)';ctx.textBaseline='alphabetic';ctx.font=Math.max(8,Math.min(11,cell*.23))+'px -apple-system,sans-serif';ctx.fillText(m.label,x,y-Math.max(10,cell*.28));});
  /* Improved token readout: halo + HP bar. Do not paint through player fog. */
  (e.units||[]).forEach(function(u){if(u.hidden&&DM.role!=='dm')return;var ux=Math.floor(u.x),uy=Math.floor(u.y);if(!v16CellVisibleToPlayer(ux,uy))return;var cx=px+(u.x+(u.size||1)/2)*cell,cy=py+(u.y+(u.size||1)/2)*cell,r=(u.size||1)*cell*.41;if(u.id===e.currentUnitId&&e.phase==='combat'){ctx.strokeStyle='rgba(240,214,110,.78)';ctx.lineWidth=3;ctx.beginPath();ctx.arc(cx,cy,r+5,0,Math.PI*2);ctx.stroke();}if(Number(u.maxHP)>0&&Number(u.hp)>=0){var w=Math.max(18,r*1.65),h=4,ratio=Math.max(0,Math.min(1,Number(u.hp)/Number(u.maxHP)));ctx.fillStyle='rgba(7,6,5,.82)';ctx.fillRect(cx-w/2,cy+r+4,w,h);ctx.fillStyle=ratio>.5?'#79b77a':(ratio>.25?'#d1a34a':'#d65b55');ctx.fillRect(cx-w/2,cy+r+4,w*ratio,h);}});
  if(V16_TOOL.mode==='ruler'&&V16_TOOL.start){var a=V16_TOOL.start,b=V16_TOOL.end||a,ax=px+(a.x+.5)*cell,ay=py+(a.y+.5)*cell,bx=px+(b.x+.5)*cell,by=py+(b.y+.5)*cell;ctx.strokeStyle='#b8dcfa';ctx.fillStyle='#b8dcfa';ctx.lineWidth=3;ctx.setLineDash([7,5]);ctx.beginPath();ctx.moveTo(ax,ay);ctx.lineTo(bx,by);ctx.stroke();ctx.setLineDash([]);ctx.beginPath();ctx.arc(ax,ay,5,0,Math.PI*2);ctx.fill();ctx.beginPath();ctx.arc(bx,by,5,0,Math.PI*2);ctx.fill();var d=v16Dist(a,b);ctx.fillStyle='rgba(11,15,20,.88)';ctx.fillRect((ax+bx)/2-26,(ay+by)/2-14,52,22);ctx.fillStyle='#d8ecff';ctx.font='bold 11px -apple-system,sans-serif';ctx.textAlign='center';ctx.textBaseline='middle';ctx.fillText(d+' 尺',(ax+bx)/2,(ay+by)/2-3);}
  if(V16_TOOL.mode==='aoe'&&V16_TOOL.aoeCenter){var q=V16_TOOL.aoeCenter,ccx=px+(q.x+.5)*cell,ccy=py+(q.y+.5)*cell,rad=(V16_TOOL.aoeFeet/((e.grid&&e.grid.cellSize)||5))*cell;ctx.fillStyle='rgba(163,122,201,.18)';ctx.strokeStyle='rgba(201,166,224,.95)';ctx.lineWidth=2;if(V16_TOOL.aoeShape==='square'){ctx.fillRect(ccx-rad,ccy-rad,rad*2,rad*2);ctx.strokeRect(ccx-rad,ccy-rad,rad*2,rad*2);}else{ctx.beginPath();ctx.arc(ccx,ccy,rad,0,Math.PI*2);ctx.fill();ctx.stroke();}}
  if(DM.role==='dm'&&V16_TOOL.mode==='room'&&V16_TOOL.roomStart){var rs=V16_TOOL.roomStart,re=V16_TOOL.end||rs,x1=Math.min(rs.x,re.x),y1=Math.min(rs.y,re.y),x2=Math.max(rs.x,re.x),y2=Math.max(rs.y,re.y);ctx.fillStyle='rgba(127,176,224,.10)';ctx.strokeStyle='rgba(127,176,224,.95)';ctx.lineWidth=2;ctx.setLineDash([5,4]);ctx.fillRect(px+x1*cell,py+y1*cell,(x2-x1+1)*cell,(y2-y1+1)*cell);ctx.strokeRect(px+x1*cell,py+y1*cell,(x2-x1+1)*cell,(y2-y1+1)*cell);ctx.setLineDash([]);}
  ctx.restore();
}
var _v16Draw=drawMap;drawMap=function(){_v16Draw();v16DrawOverlays();};
/* Tool panels are deliberately compact and sit below the library/map capability controls. */
var _v16Init=initMapCanvas;initMapCanvas=function(){v16Ensure();_v16Init();if(DM.role==='dm'){var anchor=$('v15Panel')||$('v13MapLib');if(anchor&&!$('v16Panel'))anchor.insertAdjacentHTML('afterend',v16PanelHTML());}else{var wrap=$('mapWrap');if(wrap&&!$('v16PlayerTools'))wrap.parentElement.insertAdjacentHTML('beforeend',v16PlayerToolsHTML());}v16UpdateReadout();drawMap();};
/* Intercept only V16 tools; every other map gesture continues through V15/V12. */
var _v16Bind=bindMapEvents;bindMapEvents=function(){var m=V16_TOOL.mode;if(['ruler','aoe','marker','room'].indexOf(m)<0){_v16Bind();return;}if((m==='marker'||m==='room')&&DM.role!=='dm'){_v16Bind();return;}var c=COMBAT.canvas;if(!c)return;var down=false,moved=false,startPx=null;c.onpointerdown=function(ev){ev.preventDefault();down=true;moved=false;var r=c.getBoundingClientRect();startPx={x:ev.clientX-r.left,y:ev.clientY-r.top};};c.onpointermove=function(ev){if(!down)return;var r=c.getBoundingClientRect(),p={x:ev.clientX-r.left,y:ev.clientY-r.top};if(startPx&&Math.hypot(p.x-startPx.x,p.y-startPx.y)>7)moved=true;if(m==='room'&&V16_TOOL.roomStart){var g=v16GridPointFromEvent(ev,c);if(v16Valid(g)){V16_TOOL.end=g;drawMap();}}};c.onpointerup=function(ev){if(!down)return;down=false;if(moved&&m!=='room')return;var g=v16GridPointFromEvent(ev,c);if(!v16Valid(g))return;if(m==='ruler'){if(!V16_TOOL.start||V16_TOOL.end){V16_TOOL.start=g;V16_TOOL.end=null;}else V16_TOOL.end=g;drawMap();v16UpdateReadout();return;}if(m==='aoe'){V16_TOOL.aoeCenter=g;drawMap();v16UpdateReadout();return;}if(m==='marker'){v16AddMarker(g);return;}if(m==='room'){if(!V16_TOOL.roomStart){V16_TOOL.roomStart=g;V16_TOOL.end=g;drawMap();}else{var a=V16_TOOL.roomStart;V16_TOOL.roomStart=null;V16_TOOL.end=null;v16FinishRoom(a,g);}return;}};};
/* Auto vision updates whenever authoritative movement/state is saved. */
if(typeof v10SaveSync==='function'){var _v16SaveSync=v10SaveSync;v10SaveSync=function(){v16RevealAllPlayerVision();_v16SaveSync();};}
if(typeof v9Sync==='function'){var _v16V9Sync=v9Sync;v9Sync=function(){v16RevealAllPlayerVision();_v16V9Sync();};}
var _v16DMHandle=dmHandlePlayerData;dmHandlePlayerData=function(data,conn){_v16DMHandle(data,conn);if(data&&data.type==='player-route'){var e=v16Ensure();if(e&&e.vision.autoReveal){var u=(e.units||[]).find(function(x){return x.id===data.unitId;});if(u){v16RevealVisionForUnit(u);v15Save();if($('pgMap')&&$('pgMap').classList.contains('on'))initMapCanvas();}}}};
/* Include V16 map metadata in player sync. */
var _v16Sync=syncEncounterToPlayers;syncEncounterToPlayers=function(){var e=v16Ensure();if(!e||!P2P.ready||DM.role!=='dm')return;var terrain={};Object.keys(e.terrain||{}).forEach(function(k){if(e.terrain[k]!=='trap')terrain[k]=e.terrain[k];});var visibleMarkers=(e.markers||[]).filter(function(m){return m.public;});var visible={id:e.id,name:e.name,active:e.active,started:e.started,phase:e.phase,grid:e.grid,terrain:terrain,background:e.background,fog:e.fog,vision:{autoReveal:e.vision.autoReveal,defaultFeet:e.vision.defaultFeet},markers:visibleMarkers,rooms:[],round:e.round,currentUnitId:e.currentUnitId,units:e.units.filter(function(u){return !u.hidden;}).map(function(u){return{id:u.id,name:u.name,type:u.type,x:u.x,y:u.y,size:u.size,hidden:false,hp:u.hp,maxHP:u.maxHP,ac:u.ac,init:u.init,conditions:u.conditions,ownerId:u.ownerId,color:u.color,moveUsed:u.moveUsed,moveMax:u.moveMax,visionFeet:u.visionFeet||0};})};P2P.broadcast({type:'encounter-update',data:visible});};
try{v16Ensure();saveCurrent();}catch(_){}


// ==================== V18 · 2024 / 5R 完整升级向导 ====================
var LU18=null;
var LU18_FEAT_LEVELS={
  fighter:[4,6,8,12,14,16,19], rogue:[4,8,10,12,16,19],
  barbarian:[4,8,12,16,19],bard:[4,8,12,16,19],cleric:[4,8,12,16,19],druid:[4,8,12,16,19],
  monk:[4,8,12,16,19],paladin:[4,8,12,16,19],ranger:[4,8,12,16,19],sorcerer:[4,8,12,16,19],warlock:[4,8,12,16,19],wizard:[4,8,12,16,19]
};
var LU18_MARTIAL={fighter:1,barbarian:1,paladin:1,ranger:1,rogue:1};
function lu18PB(lv){return 2+Math.floor((Math.max(1,lv)-1)/4)}
function lu18FeatAt(cls,lv){return (LU18_FEAT_LEVELS[cls]||[4,8,12,16,19]).indexOf(lv)>=0}
function lu18Esc(v){return esc(String(v==null?'':v))}
function lu18Fixed(){var c=CLASSES[S.cls]||{hd:8};return Math.floor(c.hd/2)+1}
function lu18Con(){return modOf('con')}
function lu18Gain(){var raw=LU18.hpMode==='roll'?Number(LU18.roll||1):lu18Fixed();return Math.max(1,raw+lu18Con())}
function lu18SlotsDiff(){
  var a=getSlots(S.cls,LU18.from),b=getSlots(S.cls,LU18.to),out=[];
  for(var i=0;i<Math.max(a.length,b.length);i++){var x=a[i]||0,y=b[i]||0;if(x!==y)out.push((i+1)+'环 '+x+' → '+y)}return out;
}
function lu18FeatureHints(cls,lv){
  var a=[];
  if(lv===3)a.push('检查并记录 3 级职业/子职业选择与能力');
  if(lu18FeatAt(cls,lv))a.push(lv===19?'本级包含专长节点；19级通常可选择史诗恩惠类专长（须满足前提）':'本级包含专长节点：属性值提升或符合前提的专长');
  if([5,9,13,17].indexOf(lv)>=0)a.push('熟练加值提升，所有引用熟练加值的攻击、技能、豁免、法术攻击/DC 与资源应同步');
  if(LU18_MARTIAL[cls])a.push('检查本职业表的 Weapon Mastery 数量/可替换选择及本级武器相关能力');
  if(SPELLCASTER[cls])a.push('检查本级职业表的戏法、准备法术/已知法术及法术职业能力；法术位会由程序同步');
  a.push('核对 '+(CLASSES[cls]?CLASSES[cls].n:'当前职业')+' '+lv+' 级职业表，完成本级提供的所有选择');
  return a;
}
window.openLevelUp=function(){
  if(!S||!S.game)return; var lv=Number(S.level)||1;if(lv>=20){alert('已达到 20 级');return}
  LU18={from:lv,to:lv+1,hpMode:'fixed',roll:lu18Fixed(),featMode:'none',asi1:'',asi2:'',featName:'',featureChecks:{},masteryNote:'',spellNote:'',classNote:''};
  var b=$('lu18Back');b.classList.add('on');b.setAttribute('aria-hidden','false');lu18Render();
};
window.lu18Close=function(){var b=$('lu18Back');if(b){b.classList.remove('on');b.setAttribute('aria-hidden','true')}LU18=null};
window.lu18SetHP=function(m){LU18.hpMode=m;if(m==='fixed')LU18.roll=lu18Fixed();lu18Render()};
window.lu18RollHP=function(){var d=(CLASSES[S.cls]||{hd:8}).hd;LU18.hpMode='roll';LU18.roll=1+Math.floor(Math.random()*d);lu18Render()};
window.lu18FeatMode=function(m){LU18.featMode=m;lu18Render()};
window.lu18Set=function(k,v){if(LU18)LU18[k]=v};
window.lu18Check=function(i,v){if(LU18)LU18.featureChecks[i]=!!v};
function lu18AbilityOptions(sel){var h='<option value="">选择属性</option>';AB.forEach(function(a){h+='<option value="'+a.k+'"'+(sel===a.k?' selected':'')+'>'+a.n+' '+total(a.k)+'</option>'});return h}
function lu18Render(){
  if(!LU18)return;var cls=CLASSES[S.cls]||{n:'职业',hd:8};var gain=lu18Gain(),opb=lu18PB(LU18.from),npb=lu18PB(LU18.to),sd=lu18SlotsDiff(),feat=lu18FeatAt(S.cls,LU18.to),h='';
  $('lu18Title').textContent=(S.name||'冒险者')+' · '+LU18.from+' → '+LU18.to+' 级';
  h+='<div class="lu18-card lu18-summary"><h3>升级预览</h3><div class="lu18-kv"><span>职业</span><b>'+lu18Esc(cls.n)+'（保持本职业升级）</b></div><div class="lu18-kv"><span>生命骰</span><b>+1d'+cls.hd+'</b></div><div class="lu18-kv"><span>预计最大 HP</span><b>+'+gain+'</b></div>';
  if(npb!==opb)h+='<div class="lu18-kv"><span>熟练加值</span><b>+'+opb+' → +'+npb+'</b></div>';
  if(sd.length)h+='<div class="lu18-kv"><span>法术位</span><b>'+lu18Esc(sd.join('；'))+'</b></div>';
  h+='</div>';
  h+='<div class="lu18-card"><h3>1 · HP 与生命骰</h3><div class="lu18-row"><button class="lu18-btn '+(LU18.hpMode==='fixed'?'on':'')+'" onclick="lu18SetHP(\'fixed\')">固定值 '+lu18Fixed()+'</button><button class="lu18-btn '+(LU18.hpMode==='roll'?'on':'')+'" onclick="lu18RollHP()">掷 d'+cls.hd+'</button><span class="lu18-pill">骰值 '+LU18.roll+'</span></div><div class="lu18-note">本级增加：'+(LU18.hpMode==='roll'?LU18.roll:lu18Fixed())+' + CON '+(lu18Con()>=0?'+':'')+lu18Con()+' = <b class="lu18-good">'+gain+' HP</b>（最低 +1）。</div></div>';
  var hints=lu18FeatureHints(S.cls,LU18.to);
  h+='<div class="lu18-card"><h3>2 · 本级职业能力与选择</h3>';
  hints.forEach(function(x,i){h+='<label class="lu18-check"><input type="checkbox" '+(LU18.featureChecks[i]?'checked':'')+' onchange="lu18Check('+i+',this.checked)"><span>'+lu18Esc(x)+'</span></label>'});
  h+='<input class="lu18-input" style="width:100%;box-sizing:border-box;margin-top:8px" placeholder="记录本级获得的职业/子职能力或选择…" value="'+lu18Esc(LU18.classNote)+'" oninput="lu18Set(\'classNote\',this.value)"></div>';
  if(feat){
    h+='<div class="lu18-card"><h3>3 · 专长 / 属性值提升</h3><div class="lu18-row"><button class="lu18-btn '+(LU18.featMode==='asi'?'on':'')+'" onclick="lu18FeatMode(\'asi\')">属性值提升</button><button class="lu18-btn '+(LU18.featMode==='feat'?'on':'')+'" onclick="lu18FeatMode(\'feat\')">选择专长</button></div>';
    if(LU18.featMode==='asi')h+='<div class="lu18-row" style="margin-top:9px"><select class="lu18-select" onchange="lu18Set(\'asi1\',this.value)">'+lu18AbilityOptions(LU18.asi1)+'</select><select class="lu18-select" onchange="lu18Set(\'asi2\',this.value)">'+lu18AbilityOptions(LU18.asi2)+'</select></div><div class="lu18-note">选同一属性代表 +2；选两个不同属性代表各 +1。应用时单项属性不会由此超过 20。</div>';
    if(LU18.featMode==='feat')h+='<input class="lu18-input" style="width:100%;box-sizing:border-box;margin-top:9px" placeholder="输入所选专长名称（系统保留选择记录）" value="'+lu18Esc(LU18.featName)+'" oninput="lu18Set(\'featName\',this.value)"><div class="lu18-note">专长需满足类别与前提。背景起源专长不会被这里覆盖。</div>';
    if(LU18.featMode==='none')h+='<div class="lu18-note lu18-warn">本级有专长节点，请先选择“属性值提升”或“选择专长”。</div>';
    h+='</div>';
  }
  if(LU18_MARTIAL[S.cls])h+='<div class="lu18-card"><h3>4 · Weapon Mastery</h3><input class="lu18-input" style="width:100%;box-sizing:border-box" placeholder="记录新增/替换的武器精通选择…" value="'+lu18Esc(LU18.masteryNote)+'" oninput="lu18Set(\'masteryNote\',this.value)"><div class="lu18-note">这里记录选择并同步到角色追踪资料；具体可选数量与替换时机以当前职业表为准。</div></div>';
  if(SPELLCASTER[S.cls])h+='<div class="lu18-card"><h3>5 · 法术成长</h3><div class="lu18-kv"><span>法术位变化</span><b>'+(sd.length?lu18Esc(sd.join('；')):'本级法术位数量无变化')+'</b></div><input class="lu18-input" style="width:100%;box-sizing:border-box;margin-top:8px" placeholder="记录新学/准备/替换的法术或戏法…" value="'+lu18Esc(LU18.spellNote)+'" oninput="lu18Set(\'spellNote\',this.value)"></div>';
  h+='<div class="lu18-card"><h3>最终写入</h3><div class="lu18-note">确认后才会一次性写入等级、HP/生命骰、熟练加值相关计算、法术位、职业资源和本次升级记录。取消不会改变角色。</div></div>';
  $('lu18Body').innerHTML=h;
}
function lu18ApplyASI(){
  if(LU18.featMode!=='asi')return {conDelta:0}; if(!LU18.asi1||!LU18.asi2)return null;
  var oldCon=modOf('con');var adds={};adds[LU18.asi1]=(adds[LU18.asi1]||0)+1;adds[LU18.asi2]=(adds[LU18.asi2]||0)+1;
  for(var k in adds){var cur=total(k),room=Math.max(0,20-cur),inc=Math.min(room,adds[k]);S.base[k]=(S.base[k]||8)+inc}
  return {conDelta:modOf('con')-oldCon};
}
window.lu18Apply=function(){
  if(!S||!S.game||!LU18)return;var feat=lu18FeatAt(S.cls,LU18.to);
  if(feat&&LU18.featMode==='none'){alert('本级有专长/属性提升选择，请先完成选择。');return}
  if(feat&&LU18.featMode==='asi'&&(!LU18.asi1||!LU18.asi2)){alert('请选择属性提升的两个点数。');return}
  if(feat&&LU18.featMode==='feat'&&!LU18.featName.trim()){alert('请输入所选专长名称。');return}
  var oldMax=S.game.maxHP,oldCur=S.game.currentHP,wasFull=oldCur>=oldMax,raw=(LU18.hpMode==='roll'?Number(LU18.roll||1):lu18Fixed());
  var asiRes=lu18ApplyASI();if(asiRes===null)return;
  S.level=LU18.to;
  if(!Array.isArray(S.game.hpLevelGains))S.game.hpLevelGains=[];S.game.hpLevelGains[LU18.to-2]=raw;
  // CON 修正变化会由 calcHP 对所有等级统一重算，因此自然包含追溯增量。
  var newMax=calcHP();var delta=newMax-oldMax;S.game.maxHP=newMax;S.game.currentHP=wasFull?newMax:Math.max(0,Math.min(newMax,oldCur+Math.max(0,delta)));
  if(!S.game.hitDice)S.game.hitDice={total:S.level,used:0,die:(CLASSES[S.cls]||{hd:8}).hd};S.game.hitDice.total=S.level;S.game.hitDice.die=(CLASSES[S.cls]||{hd:8}).hd;
  var ns=getSlots(S.cls,S.level),os=S.game.spellSlots||[],mg=[];for(var i=0;i<ns.length;i++)if(ns[i]>0){var ou=0;for(var j=0;j<os.length;j++)if(os[j].level===i+1){ou=Math.min(os[j].used,ns[i]);break}mg.push({level:i+1,max:ns[i],used:ou})}S.game.spellSlots=mg;
  if(!S.game.resources)S.game.resources={};var chaMod=modOf('cha');(CLASS_RESOURCES[S.cls]||[]).forEach(function(r){if(S.level<r.lv)return;var mx=r.max(S.level,chaMod);if(!S.game.resources[r.k])S.game.resources[r.k]={n:r.n,max:mx,used:0,reset:r.reset,d:r.d,pool:!!r.pool,poolUsed:0};else S.game.resources[r.k].max=mx});
  if(!Array.isArray(S.game.advancementFeats))S.game.advancementFeats=[];
  if(feat&&LU18.featMode==='feat')S.game.advancementFeats.push({level:S.level,name:LU18.featName.trim(),time:Date.now()});
  if(!S.game.masteries)S.game.masteries={};if(LU18.masteryNote.trim())S.game.masteries['lv'+S.level]=LU18.masteryNote.trim();
  if(!Array.isArray(S.game.levelUpHistory))S.game.levelUpHistory=[];S.game.levelUpHistory.push({from:LU18.from,to:LU18.to,time:Date.now(),hpMode:LU18.hpMode,hpRaw:raw,hpGain:delta,featMode:LU18.featMode,feat:LU18.featName||'',asi:[LU18.asi1||'',LU18.asi2||''],classNote:LU18.classNote||'',spellNote:LU18.spellNote||'',masteryNote:LU18.masteryNote||''});
  saveCur();lu18Close();$('trkTitle').textContent=S.name||'追踪';renderTrk();dlg('升级完成','已升至 '+S.level+' 级。\n最大 HP：'+oldMax+' → '+newMax+'\n熟练加值：+'+lu18PB(S.level),[{l:'好',c:'p'}]);
};


// ==================== V19 · 2024 12职业 1–20级升级数据 ====================
var LU19_CLASS_TABLES={
 barbarian:{sub:'野蛮人子职',features:{1:['狂暴','无甲防御','武器精通'],2:['危险感知','鲁莽攻击'],3:['野蛮人子职','原始知识'],4:['属性值提升'],5:['额外攻击','快速移动'],6:['子职能力'],7:['野性本能','本能突进'],8:['属性值提升'],9:['残暴打击'],10:['子职能力'],11:['不屈狂暴'],12:['属性值提升'],13:['强化残暴打击'],14:['子职能力'],15:['持久狂暴'],16:['属性值提升'],17:['强化残暴打击'],18:['不屈之力'],19:['史诗恩惠'],20:['原始冠军']},track:{rage:[2,2,3,3,3,4,4,4,4,4,4,5,5,5,5,5,6,6,6,6],mastery:[2,2,2,3,3,3,3,3,3,4,4,4,4,4,4,4,4,4,4,4]}},
 bard:{sub:'吟游诗人学院',features:{1:['吟游激励','施法'],2:['专精','万事通'],3:['吟游诗人子职'],4:['属性值提升'],5:['激励之泉'],6:['子职能力'],7:['反魅惑'],8:['属性值提升'],9:['专精'],10:['魔法秘密'],11:['—'],12:['属性值提升'],13:['—'],14:['子职能力'],15:['—'],16:['属性值提升'],17:['—'],18:['卓越激励'],19:['史诗恩惠'],20:['创世之语']}},
 cleric:{sub:'神圣领域',features:{1:['施法','神圣秩序'],2:['引导神力'],3:['牧师子职'],4:['属性值提升'],5:['灼烧亡灵'],6:['子职能力'],7:['受祝打击'],8:['属性值提升'],9:['—'],10:['神圣干预'],11:['—'],12:['属性值提升'],13:['—'],14:['强化受祝打击'],15:['—'],16:['属性值提升'],17:['子职能力'],18:['强化引导神力'],19:['史诗恩惠'],20:['更强神圣干预']}},
 druid:{sub:'德鲁伊结社',features:{1:['施法','德鲁伊语','原始秩序'],2:['荒野形态','荒野伙伴'],3:['德鲁伊子职'],4:['属性值提升'],5:['荒野复苏'],6:['子职能力'],7:['元素狂怒'],8:['属性值提升'],9:['—'],10:['子职能力'],11:['—'],12:['属性值提升'],13:['—'],14:['子职能力'],15:['强化元素狂怒'],16:['属性值提升'],17:['—'],18:['野兽法术','永葆青春'],19:['史诗恩惠'],20:['大德鲁伊']}},
 fighter:{sub:'战士子职',features:{1:['战斗风格','再度振作','武器精通'],2:['动作如潮'],3:['战士子职','战术思维'],4:['属性值提升'],5:['额外攻击','战术转移'],6:['属性值提升'],7:['子职能力'],8:['属性值提升'],9:['不屈','战术大师'],10:['子职能力'],11:['两次额外攻击'],12:['属性值提升'],13:['研习攻击'],14:['属性值提升'],15:['子职能力'],16:['属性值提升'],17:['强化动作如潮','强化不屈'],18:['子职能力'],19:['史诗恩惠'],20:['三次额外攻击']}},
 monk:{sub:'武僧宗派',features:{1:['武艺','无甲防御'],2:['武僧专注','无甲移动','奇异代谢'],3:['拨挡攻击','武僧子职'],4:['属性值提升','缓落'],5:['额外攻击','震慑拳'],6:['强化打击','子职能力'],7:['闪避'],8:['属性值提升'],9:['特技移动'],10:['高度专注','自我复原'],11:['子职能力'],12:['属性值提升'],13:['拨挡能量'],14:['纪律幸存者'],15:['完美专注'],16:['属性值提升'],17:['子职能力'],18:['卓越防御'],19:['史诗恩惠'],20:['身心超凡']}},
 paladin:{sub:'圣武士誓言',features:{1:['圣疗','施法','武器精通'],2:['战斗风格','圣武士惩击'],3:['引导神力','圣武士子职'],4:['属性值提升'],5:['额外攻击','忠诚坐骑'],6:['守护灵光'],7:['子职能力'],8:['属性值提升'],9:['憎恶破除'],10:['勇气灵光'],11:['光耀打击'],12:['属性值提升'],13:['—'],14:['净化之触'],15:['子职能力'],16:['属性值提升'],17:['—'],18:['灵光扩展'],19:['史诗恩惠'],20:['子职顶点能力']}},
 ranger:{sub:'游侠子职',features:{1:['施法','宿敌','武器精通'],2:['熟练探险家','战斗风格'],3:['游侠子职'],4:['属性值提升'],5:['额外攻击'],6:['巡游者'],7:['子职能力'],8:['属性值提升'],9:['专精'],10:['不倦'],11:['子职能力'],12:['属性值提升'],13:['无情猎手'],14:['自然面纱'],15:['子职能力'],16:['属性值提升'],17:['精准猎手'],18:['野性感官'],19:['史诗恩惠'],20:['猎敌者']}},
 rogue:{sub:'游荡者子职',features:{1:['专精','偷袭','盗贼黑话','武器精通'],2:['灵巧动作'],3:['游荡者子职','稳定瞄准'],4:['属性值提升'],5:['狡猾打击','直觉闪避'],6:['专精'],7:['闪避','可靠才能'],8:['属性值提升'],9:['子职能力'],10:['属性值提升'],11:['强化狡猾打击'],12:['属性值提升'],13:['子职能力'],14:['诡诈打击'],15:['圆滑心智'],16:['属性值提升'],17:['子职能力'],18:['难以捉摸'],19:['史诗恩惠'],20:['幸运一击']}},
 sorcerer:{sub:'术士起源',features:{1:['施法','先天术法'],2:['魔力泉源','超魔法'],3:['术士子职'],4:['属性值提升'],5:['术法复原'],6:['子职能力'],7:['术法化身'],8:['属性值提升'],9:['—'],10:['超魔法'],11:['—'],12:['属性值提升'],13:['—'],14:['子职能力'],15:['—'],16:['属性值提升'],17:['超魔法'],18:['子职能力'],19:['史诗恩惠'],20:['奥术神化']}},
 warlock:{sub:'异界宗主',features:{1:['魔能祈唤','契约魔法'],2:['魔法狡计'],3:['邪术师子职'],4:['属性值提升'],5:['—'],6:['子职能力'],7:['—'],8:['属性值提升'],9:['联系宗主'],10:['子职能力'],11:['秘法奥秘'],12:['属性值提升'],13:['秘法奥秘'],14:['子职能力'],15:['秘法奥秘'],16:['属性值提升'],17:['秘法奥秘'],18:['—'],19:['史诗恩惠'],20:['魔能大师']}},
 wizard:{sub:'法师学派',features:{1:['施法','仪式专家','奥术回想'],2:['学者'],3:['法师子职'],4:['属性值提升'],5:['记忆法术'],6:['子职能力'],7:['—'],8:['属性值提升'],9:['—'],10:['子职能力'],11:['—'],12:['属性值提升'],13:['—'],14:['子职能力'],15:['—'],16:['属性值提升'],17:['—'],18:['法术精通'],19:['史诗恩惠'],20:['招牌法术']}}
};
var LU19_SUBCLASS_LEVELS={barbarian:[3,6,10,14],bard:[3,6,14],cleric:[3,6,17],druid:[3,6,10,14],fighter:[3,7,10,15,18],monk:[3,6,11,17],paladin:[3,7,15,20],ranger:[3,7,11,15],rogue:[3,9,13,17],sorcerer:[3,6,14,18],warlock:[3,6,10,14],wizard:[3,6,10,14]};
function lu19Data(cls,lv){var t=LU19_CLASS_TABLES[cls];if(!t)return null;return {features:(t.features[lv]||[]).filter(function(x){return x!=='—'}),sub:t.sub,subNode:(LU19_SUBCLASS_LEVELS[cls]||[]).indexOf(lv)>=0,track:t.track||{}}}
function lu19FeatureHints(cls,lv){var d=lu19Data(cls,lv),a=[];if(d&&d.features.length)a.push('本级职业能力：'+d.features.join('、'));if(d&&d.subNode)a.push('本级包含 '+d.sub+' 节点，请完成对应子职能力/选择');if(lu18FeatAt(cls,lv))a.push(lv===19?'本级为史诗恩惠专长节点，请选择符合前提的 Epic Boon':'本级包含属性值提升/专长节点');if([5,9,13,17].indexOf(lv)>=0)a.push('角色总等级达到熟练加值门槛时，自动更新熟练加值及其派生数值');if(LU18_MARTIAL[cls])a.push('核对 Weapon Mastery 数量与本级可调整的武器精通选择');if(SPELLCASTER[cls])a.push('核对本级准备/已知法术、戏法与法术职业能力；法术位由程序自动比较');return a.length?a:['本级没有需要额外记录的职业能力']}
lu18FeatureHints=lu19FeatureHints;
var _lu19Render=lu18Render;
lu18Render=function(){_lu19Render();if(!LU18)return;var body=$('lu18Body'),d=lu19Data(S.cls,LU18.to);if(!body||!d)return;var first=body.querySelector('.lu18-card');if(!first)return;var box=document.createElement('div');box.className='lu18-card';var chips=d.features.map(function(x){return '<span class="lu18-pill">'+lu18Esc(x)+'</span>'}).join(' ');box.innerHTML='<h3>2024 职业表 · '+LU18.to+' 级</h3><div class="lu18-row" style="align-items:flex-start">'+(chips||'<span class="lu18-note">本级无新的基础职业能力名称</span>')+'</div>'+(d.subNode?'<div class="lu18-note lu18-warn" style="margin-top:8px">本级触发 '+lu18Esc(d.sub)+' 能力节点。升级确认前请完成对应选择。</div>':'')+'<div class="lu18-note" style="margin-top:8px">升级向导现在直接读取内置 1–20 级职业表，不再只显示“请查职业表”的占位提醒。</div>';first.insertAdjacentElement('afterend',box)};

