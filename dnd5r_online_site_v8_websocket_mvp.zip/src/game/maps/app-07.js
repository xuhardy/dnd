
// ==================== V20 · Navigation self-heal ====================
(function(){
  function v191HideOverlays(){
    ['lu18Back','dbd'].forEach(function(id){var e=document.getElementById(id);if(e){e.classList.remove('on');e.setAttribute('aria-hidden','true');}});
    document.querySelectorAll('.modal.on,.overlay.on,.backdrop.on').forEach(function(e){e.classList.remove('on');});
  }
  window.v191GoHome=function(){
    try{ if(typeof saveCur==='function' && window.S) saveCur(); }catch(e){}
    try{ if(window.DM && DM.active && DM.role==='player' && typeof P2P!=='undefined' && P2P.conn){ try{P2P.conn.close();}catch(e){} } }catch(e){}
    try{ if(typeof VOICE!=='undefined' && VOICE && VOICE.enabled && typeof voiceLeave==='function') voiceLeave(); }catch(e){}
    try{ if(typeof LU18!=='undefined') LU18=null; }catch(e){}
    v191HideOverlays();
    try{ if(window.DM && DM.role==='player'){ DM.active=false; DM.role=null; } }catch(e){}
    window.S=null;
    try{ if(typeof renderHome==='function') renderHome(); }catch(e){}
    if(typeof showPage==='function') showPage('pgHome');
    else {document.querySelectorAll('.page').forEach(function(p){p.classList.remove('on')});var h=document.getElementById('pgHome');if(h)h.classList.add('on');}
    window.scrollTo(0,0);
  };
  // Tracker's "返回主页" must always mean home. Player lobby can still be entered from home.
  window.exitTrk=function(){ v191GoHome(); };
  // Wizard return path: avoid depending on any stale page/DM state.
  window.exitWiz=function(){
    if(typeof dlg==='function') dlg('返回主页','未保存的修改会丢失。',[{l:'继续编辑'},{l:'返回主页',c:'p',f:v191GoHome}]);
    else v191GoHome();
  };
  document.addEventListener('DOMContentLoaded',function(){
    var b=document.getElementById('trkBackBtn'); if(b){b.textContent='返回主页';b.onclick=v191GoHome;}
  });
})();
