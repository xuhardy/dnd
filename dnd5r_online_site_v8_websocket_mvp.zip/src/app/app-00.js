
/* V20.3: Never block application startup on a remote P2P library. */
(function(){
  var sources=['https://cdn.jsdelivr.net/npm/peerjs@1.5.0/dist/peerjs.min.js','https://unpkg.com/peerjs@1.5.0/dist/peerjs.min.js'];
  var index=0,ready=false;
  window.peerLibraryReady=function(){return typeof window.Peer==='function'};
  function status(msg){var e=document.getElementById('st');if(e&&!e.classList.contains('ok'))e.textContent=msg;}
  function load(){if(window.peerLibraryReady()){ready=true;return;}if(index>=sources.length){status('本地功能可用 · 联机服务暂不可用');return;}
    var src=sources[index++],sc=document.createElement('script'),done=false;
    var timer=setTimeout(function(){if(done)return;done=true;sc.remove();load()},6500);
    sc.src=src;sc.async=true;
    sc.onload=function(){if(done)return;done=true;clearTimeout(timer);if(window.peerLibraryReady()){ready=true;status('P2P 联机模块已就绪')}else load()};
    sc.onerror=function(){if(done)return;done=true;clearTimeout(timer);load()};
    document.head.appendChild(sc);
  }
  if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',load);else load();
})();
