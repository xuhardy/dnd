(function(){
'use strict';
window.addEventListener('error',function(e){var st=document.getElementById('st');if(st){st.style.opacity='1';st.classList.remove('ok');st.textContent='页面脚本错误：'+(e.message||'未知错误');}},false);
window.addEventListener('unhandledrejection',function(e){var st=document.getElementById('st');if(st){st.style.opacity='1';st.classList.remove('ok');st.textContent='异步错误：'+String(e.reason&&e.reason.message||e.reason||'未知错误');}},false);
})();
