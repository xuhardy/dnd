/* V5: BG-inspired step-by-step level-up presentation. Uses existing V18/V19 authoritative commit. */
(function(){
'use strict';
var step=0;
var steps=[{name:'升级总览',hint:'查看新等级、HP 与熟练加值'},{name:'生命值',hint:'选择固定生命值或掷生命骰'},{name:'职业能力',hint:'核对新获得的职业和子职业能力'},{name:'专长与属性',hint:'完成属性提升或专长选择（如适用）'},{name:'战斗与法术',hint:'检查武器精通、法术和职业资源'},{name:'最终确认',hint:'确认全部选择，再一次性保存角色'}];
function visibleCards(){var body=document.getElementById('lu18Body');return body?Array.from(body.querySelectorAll(':scope > .lu18-card')):[]}
function groupCards(){var cards=visibleCards();return [cards.filter(x=>/升级预览|职业表/.test(x.textContent.slice(0,80))),cards.filter(x=>/HP 与生命骰/.test(x.textContent.slice(0,80))),cards.filter(x=>/本级职业能力/.test(x.textContent.slice(0,80))),cards.filter(x=>/专长 \/ 属性值提升/.test(x.textContent.slice(0,80))),cards.filter(x=>/Weapon Mastery|法术成长/.test(x.textContent.slice(0,80))),cards.filter(x=>/最终写入/.test(x.textContent.slice(0,80)))];}
function paint(){var b=document.getElementById('lu18Back');if(!b||!b.classList.contains('on'))return;var body=document.getElementById('lu18Body');if(!body)return;var groups=groupCards();var nav=document.getElementById('lu5Nav');if(!nav){nav=document.createElement('div');nav.id='lu5Nav';nav.className='lu5-nav';body.parentNode.insertBefore(nav,body)}nav.innerHTML='<div class="lu5-eyebrow">角色成长 · '+(step+1)+' / '+steps.length+'</div><div class="lu5-progress">'+steps.map((s,i)=>'<button type="button" class="'+(i===step?'active':i<step?'done':'')+'" data-lu-step="'+i+'" aria-label="'+s.name+'">'+(i+1)+'</button>').join('')+'</div><h3>'+steps[step].name+'</h3><p>'+steps[step].hint+'</p>';
var selected=groups[step];visibleCards().forEach(c=>{c.style.display=selected.includes(c)?'':'none'});
if(step===2||step===4)enhanceCards(step);
if(!selected.length){var empty=document.getElementById('lu5Empty');if(!empty){empty=document.createElement('div');empty.id='lu5Empty';empty.className='lu18-card';body.appendChild(empty)}empty.style.display='';empty.innerHTML='<h3>本级无需额外选择</h3><p class="lu18-note">这一阶段没有需要处理的项目，可以继续下一步。</p>'}else{var empty=document.getElementById('lu5Empty');if(empty)empty.style.display='none'}
var foot=b.querySelector('.lu18-foot');if(foot){foot.innerHTML='<button type="button" class="lu18-btn" id="lu5Back">'+(step===0?'取消升级':'上一步')+'</button><button type="button" class="lu18-btn pri" id="lu5Next">'+(step===steps.length-1?'确认并升级':'下一步 →')+'</button>';}
}

var CLASS_CHOICES={
 fighter:['战斗风格：防护','战斗风格：箭术','战斗风格：防御','战斗风格：双武器战斗'],
 barbarian:['狂暴：核对可用次数','残暴打击：核对战斗应用'],
 rogue:['巧妙动作：核对动作选项','偷袭：核对伤害骰'],
 wizard:['法术书：记录新增法术','法术准备：核对准备数量'],
 cleric:['神圣引导：核对次数','神圣秩序：核对职业选项'],
 druid:['荒野形态：核对次数','德鲁伊子职业：核对能力'],
 bard:['吟游激励：核对骰值和次数'],
 monk:['专注点：核对上限','武术：核对伤害骰'],
 paladin:['圣疗：核对治疗池','武器精通：核对武器'],
 ranger:['猎人印记：核对职业能力','武器精通：核对武器'],
 sorcerer:['术法点：核对上限','超魔法：核对可选项'],
 warlock:['契约魔法：核对法术位','魔能祈唤：核对可选项']
};
var SPELL_SUGGESTIONS={wizard:['魔法飞弹','护盾术','法师护甲','侦测魔法','迷雾术','镜影术'],cleric:['祝福术','治疗真言','疗伤术','庇护术','援助术'],druid:['纠缠术','妖火','治疗真言','荆棘鞭'],bard:['治疗真言','妖火','睡眠术','不谐低语'],sorcerer:['魔法飞弹','护盾术','迷雾术','镜影术'],warlock:['艾嘉西斯之铠','妖火','脆弱诅咒'],paladin:['祝福术','疗伤术','命令术'],ranger:['猎人印记','疗伤术','动物交谈']};
function enhanceCards(which){
 var body=document.getElementById('lu18Body');if(!body||!window.LU18&&!window.S)return;
 var cls=window.S&&S.cls;var lv=window.LU18&&LU18.to;var target=which===2?Array.from(body.querySelectorAll('.lu18-card')).find(x=>x.textContent.includes('本级职业能力')):Array.from(body.querySelectorAll('.lu18-card')).find(x=>x.textContent.includes('法术成长'));
 if(!target||target.querySelector('.lu6-picker'))return;
 var choices=which===2?(CLASS_CHOICES[cls]||[]):(SPELL_SUGGESTIONS[cls]||[]);
 if(!choices.length)return;
 var box=document.createElement('div');box.className='lu6-picker';
 var title=document.createElement('h4');title.textContent=which===2?'职业能力核对卡':'法术选择辅助卡';box.appendChild(title);
 var tip=document.createElement('p');tip.className='lu18-note';tip.textContent='仅为常见能力/法术的快速记录提示，实际可选项、等级与前提仍需按 2024 职业表核对。点击会追加到本次升级备注，不会自动授予能力。';box.appendChild(tip);
 var grid=document.createElement('div');grid.className='lu6-grid';
 choices.forEach(function(choice){var btn=document.createElement('button');btn.type='button';btn.className='lu6-choice';btn.textContent=choice;btn.onclick=function(){if(!window.LU18)return;var key=which===2?'classNote':'spellNote';var prev=LU18[key]||'';if(prev.split('；').includes(choice))return;LU18[key]=(prev?prev+'；':'')+choice;var input=target.querySelector('input[placeholder]');if(input)input.value=LU18[key];btn.classList.add('selected')};grid.appendChild(btn)});
 box.appendChild(grid);target.appendChild(box);
}
function begin(){step=0;setTimeout(paint,0)}
function setup(){if(typeof window.openLevelUp!=='function'||typeof window.lu18Render!=='function')return false;
var open=window.openLevelUp;window.openLevelUp=function(){open.apply(this,arguments);begin()};
var render=window.lu18Render;window.lu18Render=function(){var r=render.apply(this,arguments);setTimeout(paint,0);return r};
document.addEventListener('click',function(e){var t=e.target.closest('[data-lu-step],#lu5Back,#lu5Next');if(!t)return;if(t.dataset.luStep!==undefined){step=Number(t.dataset.luStep);paint();return}if(t.id==='lu5Back'){if(step===0)window.lu18Close();else{step--;paint()}}else if(t.id==='lu5Next'){if(step<steps.length-1){step++;paint()}else window.lu18Apply()}});return true}
if(!setup())window.addEventListener('load',setup,{once:true});
})();
