/* V4: independent navigation and session controls */
(function(){'use strict';
  function safe(fn){try{return fn()}catch(e){console.error('[V4]',e);var st=document.getElementById('st');if(st){st.textContent='操作失败：'+(e.message||e);st.style.opacity='1';}return false;}}
  function home(){safe(function(){if(typeof window.lu18Close==='function')window.lu18Close();});safe(function(){if(typeof window.renderHome==='function')window.renderHome();});safe(function(){if(typeof window.showPage==='function')window.showPage('pgHome');else document.querySelectorAll('.page').forEach(function(p){p.classList.toggle('on',p.id==='pgHome')});});}
  document.addEventListener('click',function(ev){var b=ev.target.closest&&ev.target.closest('[data-v4-action]');if(!b)return;ev.preventDefault();ev.stopImmediatePropagation();var a=b.dataset.v4Action;
    if(a==='lobby')safe(function(){if(typeof window.v202OpenLobby==='function')window.v202OpenLobby();else home();});
    if(a==='close')safe(function(){if(typeof window.dmCloseRoom==='function')window.dmCloseRoom();else home();});
    if(a==='leave')safe(function(){if(typeof window.dmLeaveRoom==='function')window.dmLeaveRoom();else home();});
    if(a==='home')home();
  },true);
  function update(){var bar=document.getElementById('v202SessionBar');if(!bar)return;var btns=bar.querySelectorAll('button');if(btns[0]){btns[0].setAttribute('data-v4-action','lobby');btns[0].onclick=null;}if(btns[1]){btns[1].setAttribute('data-v4-action',window.DM&&DM.role==='dm'?'close':'leave');btns[1].onclick=null;}}
  var observer=new MutationObserver(update);document.addEventListener('DOMContentLoaded',function(){observer.observe(document.body,{childList:true,subtree:false});update();});
  window.addEventListener('unhandledrejection',function(e){console.error('[V4 async]',e.reason)});
})();
