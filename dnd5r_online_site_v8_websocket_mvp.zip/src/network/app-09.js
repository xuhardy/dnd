
/* V20.1 · interaction + connection diagnostics */
(function(){
  DM.v201Diag=''; DM.v201DiagKind='';
  function diag(msg,kind){DM.v201Diag=msg||'';DM.v201DiagKind=kind||'';try{renderDMHome()}catch(e){}}
  function peerReady(){return typeof window.Peer==='function'}
  window.v201ConnectionTest=function(){
    if(!DM.active){diag('当前没有活动房间。','bad');return}
    if(!peerReady()){diag('PeerJS 没有成功加载。请确认当前浏览器可以访问 PeerJS CDN，然后刷新页面。','bad');return}
    var t=Date.now(); P2P.lastPingSent=t;
    if(DM.role==='dm'){
      var open=(P2P.conns||[]).filter(function(c){return c&&c.open});
      if(!open.length){diag('DM 主机正常，但当前没有已连接玩家。','ok');return}
      open.forEach(function(c){try{c.send({type:'v201-ping',t:t})}catch(e){}});
      diag('已向 '+open.length+' 名玩家发送测试包，等待回应…','');
    }else{
      if(!P2P.hostConn||!P2P.hostConn.open){diag('尚未与 DM 建立数据通道。当前状态：'+dmStatusText(),'bad');return}
      try{P2P.hostConn.send({type:'v201-ping',t:t});diag('已向 DM 发送测试包，等待回应…','')}catch(e){diag('发送失败：'+e.message,'bad')}
    }
  };
  // Transport-level ping/pong, independent of the older dmPing implementation.
  var oldPlayerData=P2P.onData;
  document.addEventListener('click',function(ev){
    var b=ev.target.closest&&ev.target.closest('[data-v201]'); if(!b)return;
    ev.preventDefault();ev.stopPropagation();
    var a=b.getAttribute('data-v201');
    try{
      if(a==='ping')v201ConnectionTest();
      else if(a==='ready')v20ToggleReady();
      else if(a==='lock')v20ToggleLock();
      else if(a==='start')v20StartGame();
      else if(a==='switch')v20SwitchChar();
      else if(a==='leave')dmLeaveRoom();
      else if(a==='close')dmCloseRoom();
    }catch(e){diag('操作失败：'+(e&&e.message?e.message:String(e)),'bad')}
  },true);
  // Wrap player handler after every join, so lobby test packets always work.
  var oldJoin201=window.dmJoinRoom;
  window.dmJoinRoom=function(code,charId){
    oldJoin201(code,charId);
    var prev=P2P.onData;
    P2P.onData=function(data,conn){
      if(data&&data.type==='v201-ping'){try{P2P.send({type:'v201-pong',t:data.t})}catch(e){}return}
      if(data&&data.type==='v201-pong'){P2P.lastLatency=Math.max(0,Date.now()-Number(data.t||Date.now()));diag('连接正常 · 往返延迟约 '+P2P.lastLatency+' ms','ok');return}
      if(prev)prev(data,conn);
    };
  };
  // DM receives ping/pong through dmHandlePlayerData.
  var prevHandle201=window.dmHandlePlayerData;
  window.dmHandlePlayerData=function(data,conn){
    if(data&&data.type==='v201-ping'){try{P2P.sendTo({type:'v201-pong',t:data.t},conn)}catch(e){}return}
    if(data&&data.type==='v201-pong'){P2P.lastLatency=Math.max(0,Date.now()-Number(data.t||Date.now()));diag('连接正常 · 往返延迟约 '+P2P.lastLatency+' ms','ok');return}
    return prevHandle201(data,conn);
  };
  // Patch lobby markup after render. Uses delegated actions, avoiding fragile inline handlers on mobile Safari.
  var prevRender201=renderDMHome;
  renderDMHome=function(){
    prevRender201();
    if(!DM.active||DM.phase==='game')return;
    var root=$('dmMain'); if(!root)return;
    root.querySelectorAll('.v20-actions button').forEach(function(b){b.type='button'});
    var bs=root.querySelectorAll('.v20-actions button');
    bs.forEach(function(b){var t=b.textContent||'';
      if(t.indexOf('连接测试')>=0){b.removeAttribute('onclick');b.setAttribute('data-v201','ping')}
      else if(t.indexOf('准备')>=0){b.removeAttribute('onclick');b.setAttribute('data-v201','ready')}
      else if(t.indexOf('锁定大厅')>=0||t.indexOf('开放大厅')>=0){b.removeAttribute('onclick');b.setAttribute('data-v201','lock')}
      else if(t.indexOf('开始冒险')>=0){b.removeAttribute('onclick');b.setAttribute('data-v201','start')}
      else if(t.indexOf('切换角色')>=0){b.removeAttribute('onclick');b.setAttribute('data-v201','switch')}
      else if(t.indexOf('离开大厅')>=0){b.removeAttribute('onclick');b.setAttribute('data-v201','leave')}
      else if(t.indexOf('关闭房间')>=0){b.removeAttribute('onclick');b.setAttribute('data-v201','close')}
    });
    var old=root.querySelector('.v201-diag');if(old)old.remove();
    if(DM.v201Diag){var d=document.createElement('div');d.className='v201-diag '+(DM.v201DiagKind||'');d.textContent=DM.v201Diag;root.appendChild(d)}
  };
  // Catch UI exceptions and surface them instead of making a button appear dead.
  window.addEventListener('error',function(e){if(DM&&DM.active){DM.v201Diag='界面错误：'+(e.message||'未知错误');DM.v201DiagKind='bad'}});
})();
