
/* V20.2 · stable room/session lifecycle. Critical navigation no longer depends on lobby render state. */
(function(){
  var closing=false;
  function safe(fn){try{return fn&&fn()}catch(e){try{console.warn(e)}catch(_){}}}
  function clearSession(){
    safe(function(){if(window.VOICE&&VOICE.enabled&&typeof voiceLeave==='function')voiceLeave()});
    safe(function(){if(window.P2P)P2P.destroy()});
    if(window.DM){DM.active=false;DM.role=null;DM.roomCode=null;DM.players=[];DM.roster=[];DM.phase='lobby';DM.locked=false;DM.myReady=false;DM.statusState='off';DM.statusText='';}
  }
  function goHome(){safe(function(){var bar=document.getElementById('v202SessionBar');if(bar)bar.remove()});safe(function(){if(typeof renderHome==='function')renderHome()});safe(function(){showPage('pgHome')});}
  window.v202OpenLobby=function(){
    if(!DM||!DM.active){goHome();return}
    // Viewing the lobby is UI navigation only. It does not silently end the running adventure.
    safe(function(){showPage('pgDM')});safe(function(){renderDMHome()});safe(function(){if(typeof mountVoiceBarDM==='function')mountVoiceBarDM()});
  };
  window.v202ReturnAllToLobby=function(){
    if(!DM||DM.role!=='dm')return;
    DM.phase='lobby';DM.locked=false;
    safe(function(){P2P.broadcast({type:'lobby-return',phase:'lobby'})});
    safe(function(){showPage('pgDM')});safe(function(){renderDMHome()});
  };
  window.v202CloseRoomNow=function(){
    if(closing||!DM||DM.role!=='dm')return;closing=true;
    // Broadcast first, but local shutdown never waits for the network or a timer.
    safe(function(){P2P.broadcast({type:'room-closed'})});
    clearSession();goHome();closing=false;
  };
  window.v202LeaveRoomNow=function(){
    if(closing||!DM||DM.role!=='player')return;closing=true;
    safe(function(){P2P.send({type:'player-leave',charId:(S&&S.id)||''})});
    clearSession();goHome();closing=false;
  };
  // Replace the old dialog/timer based critical lifecycle actions.
  window.dmCloseRoom=function(){
    if(!DM||DM.role!=='dm')return;
    if(window.confirm && !confirm('关闭房间会断开所有玩家。确定关闭？'))return;
    v202CloseRoomNow();
  };
  window.dmLeaveRoom=function(){
    if(!DM||DM.role!=='player')return;
    if(window.confirm && !confirm('确定离开当前房间？'))return;
    v202LeaveRoomNow();
  };
  window.v20BackLobby=function(){v202ReturnAllToLobby()};

  // Host removes an intentional leaver immediately rather than preserving it as a reconnect seat.
  var prevHandle=window.dmHandlePlayerData;
  window.dmHandlePlayerData=function(data,conn){
    if(data&&data.type==='player-leave'){
      DM.players=(DM.players||[]).filter(function(p){return p.conn!==conn && !(data.charId&&p.data&&p.data.id===data.charId)});
      safe(function(){try{conn.close()}catch(e){}});safe(function(){broadcastParty()});safe(function(){renderDMHome()});return;
    }
    return typeof prevHandle==='function'?prevHandle(data,conn):undefined;
  };

  // Make room-closed a hard route to Home on players, regardless of which page they are viewing.
  var prevJoin=window.dmJoinRoom;
  window.dmJoinRoom=function(code,charId){
    if(typeof prevJoin!=='function')throw Error('加入房间功能未加载');
    prevJoin(code,charId);
    var prev=P2P.onData;
    P2P.onData=function(data,conn){
      if(data&&data.type==='room-closed'){
        clearSession();goHome();alert('DM 已关闭房间');return;
      }
      if(prev)prev(data,conn);
    };
  };

  function sessionBar(){
    var old=document.getElementById('v202SessionBar');if(old)old.remove();
    if(!window.DM||!DM.active)return;
    var bar=document.createElement('div');bar.id='v202SessionBar';bar.className='v202-sessionbar';
    var lobby=document.createElement('button');lobby.type='button';lobby.textContent='☰ 大厅';lobby.onclick=v202OpenLobby;bar.appendChild(lobby);
    var end=document.createElement('button');end.type='button';end.className='danger';end.textContent=DM.role==='dm'?'关闭房间':'离开房间';end.onclick=DM.role==='dm'?dmCloseRoom:dmLeaveRoom;bar.appendChild(end);
    document.body.appendChild(bar);
  }
  var oldShow=window.showPage;
  window.showPage=function(id){var r=typeof oldShow==='function'?oldShow.apply(this,arguments):undefined;setTimeout(sessionBar,0);return r};
  var oldRender=window.renderDMHome;
  window.renderDMHome=function(){var r=typeof oldRender==='function'?oldRender.apply(this,arguments):undefined;sessionBar();
    if(DM.active&&DM.role==='dm'&&DM.phase==='game'){
      var root=document.getElementById('dmMain');if(root){var box=document.createElement('div');box.className='v20-banner';box.innerHTML='冒险进行中。这里仍可作为连接大厅使用。<div class="v20-actions"><button type="button" onclick="v202ReturnAllToLobby()">↩ 全员返回大厅</button><button type="button" class="danger" onclick="dmCloseRoom()">关闭房间</button></div>';root.prepend(box)}
    }
    return r};
  document.addEventListener('DOMContentLoaded',sessionBar);
  setTimeout(sessionBar,0);
})();
